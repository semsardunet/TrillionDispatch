/* ---------- end-of-round report: CSV, PDF with proofs, ZIP ---------- */
const baseName = t => `tournee_${t.day}_${slug(t.driver_name || 'livreur') || 'livreur'}`;
const folderOf = (t, s) => `${String(stopsOf(t.id).findIndex(x => x.id === s.id) + 1).padStart(2, '0')} - ${slug(A(s).label.split(',')[0])}`;
const dec = (n, d) => n == null || isNaN(n) ? '' : Number(n).toFixed(d).replace('.', ',');
const csvCell = v => { v = v == null ? '' : String(v); return /[;"\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
const STATUT = { done: 'livré', failed: 'échec', todo: 'non tenté' };
function legKm(t, s) { let prev = t.depot; for (const x of stopsOf(t.id)) { if (x.id === s.id) break; if (hasXY(A(x))) prev = A(x); } return hasXY(A(s)) && hasXY(prev) ? dist(prev, A(s)) * ROAD / 1000 : null; }
function buildCsv(t) {
  const H = ['date', 'tournee', 'chauffeur', 'rang', 'reference', 'client', 'telephone', 'adresse', 'code_postal', 'commune', 'creneau', 'colis', 'poids_kg', 'arrivee', 'validation', 'duree_sur_place_min', 'statut', 'motif_echec', 'a_reprogrammer', 'lieu_depot', 'receptionnaire', 'photos_preuve', 'signature', 'gps_lat', 'gps_lng', 'gps_precision_m', 'remarque', 'consigne_dispatcher', 'ajouts_fiche', 'resume_fiche', 'km_depuis_precedent'];
  const rows = stopsOf(t.id).map((s, i) => {
    const a = A(s), p = s.proof || {}, f = folderOf(t, s);
    const dur = s.arrived_at && s.done_at ? Math.max(0, Math.round((new Date(s.done_at) - new Date(s.arrived_at)) / 60000)) : '';
    return [t.day, t.name, t.driver_name, i + 1, s.ref, s.client, s.phone, a.label, a.pc, a.city, winText(s), s.notes, dec(s.weight_kg, 1), fmtTime(s.arrived_at), fmtTime(s.done_at), dur,
      STATUT[s.status], s.fail_reason, s.status === 'failed' ? (s.reschedule ? 'oui' : 'non') : '', p.place, p.recipient,
      (p.photos || []).map((_, k) => `preuves/${f}/preuve-${k + 1}.jpg`).join(' | '), p.signature ? `preuves/${f}/signature.png` : '',
      p.gps ? dec(p.gps.lat, 6) : '', p.gps ? dec(p.gps.lng, 6) : '', p.gps ? p.gps.acc : '', p.note, s.driver_note, s.fiche_added || 0, summary(a.id), dec(legKm(t, s), 1)];
  });
  return '﻿' + [H, ...rows].map(r => r.map(csvCell).join(';')).join('\r\n');
}
async function imgData(path, max = 900) {
  const b = await Api.mediaBlob(path); if (!b) return null; const u = URL.createObjectURL(b);
  try {
    const img = await loadImage(u); const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return { url: c.toDataURL('image/jpeg', 0.72), w: c.width, h: c.height };
  } catch (e) { return null; } finally { URL.revokeObjectURL(u); }
}
async function buildPdf(t) {
  await loadScript(ASSETS.jspdf); const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' }); const M = 14, W = 210 - 2 * M, PH = 297;
  const Cl = { ink: [17, 24, 33], grey: [86, 98, 115], blue: [23, 71, 201], ok: [23, 112, 63], bad: [180, 35, 24], line: [198, 208, 220] };
  const txt = (s, x, y, o = {}) => { doc.setFont('helvetica', o.b ? 'bold' : 'normal'); doc.setFontSize(o.s || 10); doc.setTextColor(...(o.c || Cl.ink)); doc.text(String(s ?? ''), x, y, o.opt || {}); };
  const lines = (s, w, size) => { doc.setFontSize(size); return doc.splitTextToSize(String(s), w); };
  const ss = stopsOf(t.id), k = tourCounts(t.id); let y = M;
  doc.setFillColor(...Cl.blue); doc.rect(0, 0, 210, 4, 'F');
  txt('RAPPORT DE TOURNÉE', M, y + 7, { b: 1, s: 19 }); y += 14;
  txt(`${fmtDay(t.day)} · ${t.name} · Livreur : ${t.driver_name || '-'}`, M, y, { s: 10, c: Cl.grey }); y += 6;
  txt(`${k.done} livrés · ${k.failed} échecs · ${k.n} arrêts · départ ${fmtTime(t.started_at) || '-'} · fin ${fmtTime(t.ended_at) || '-'} · ${planInfo(t).km.toFixed(1)} km estimés`, M, y, { s: 10, c: Cl.grey }); y += 5;
  doc.setDrawColor(...Cl.line); doc.line(M, y, M + W, y); y += 7;
  for (const [i0, s] of ss.entries()) {
    const a = A(s), p = s.proof || {}, i = i0 + 1;
    const imgs = []; for (const path of (p.photos || []).slice(0, 4)) { const d = await imgData(path); if (d) imgs.push(d); }
    if (p.signature) { const d = await imgData(p.signature, 500); if (d) imgs.push(d); }
    const col = s.status === 'done' ? Cl.ok : s.status === 'failed' ? Cl.bad : Cl.grey;
    const head = s.status === 'done' ? `LIVRÉ À ${fmtTime(s.done_at)}${p.place ? ' · ' + p.place : ''}` : s.status === 'failed' ? `ÉCHEC À ${fmtTime(s.done_at)} · ${s.fail_reason}${s.reschedule ? ' · à reprogrammer' : ''}` : 'NON TENTÉ';
    const det = [];
    if (p.recipient) det.push(`Reçu par : ${p.recipient}`);
    if (s.arrived_at && s.done_at) det.push(`Arrivée ${fmtTime(s.arrived_at)} · validation ${fmtTime(s.done_at)}`);
    if (p.gps) det.push(`GPS : ${(+p.gps.lat).toFixed(5)}, ${(+p.gps.lng).toFixed(5)} (± ${p.gps.acc} m)`); else if (s.status !== 'todo') det.push('GPS : non enregistré');
    if (p.note) det.push(`Remarque : ${p.note}`);
    if (s.fiche_added) det.push(`Fiche terrain complétée (${s.fiche_added} ajout${s.fiche_added > 1 ? 's' : ''})`);
    const detL = det.flatMap(d => lines(d, W - 14, 9)), rowsImg = Math.ceil(imgs.length / 4);
    if (y + 22 + detL.length * 4.4 + rowsImg * 44 + 6 > PH - 16) { doc.addPage(); y = M; }
    doc.setFillColor(...(s.status === 'todo' ? Cl.blue : col)); doc.roundedRect(M, y, 9, 9, 1.4, 1.4, 'F');
    txt(i, M + 4.5, y + 6.3, { b: 1, s: 11, c: [255, 255, 255], opt: { align: 'center' } });
    txt(a.label.split(',')[0], M + 13, y + 4.4, { b: 1, s: 12 });
    txt([[a.pc, a.city].filter(Boolean).join(' '), s.client, s.phone, s.ref].filter(Boolean).join(' · '), M + 13, y + 9.4, { s: 9, c: Cl.grey });
    y += 15; txt(head, M + 13, y, { b: 1, s: 10, c: col }); y += 5;
    for (const l of detL) { txt(l, M + 13, y, { s: 9 }); y += 4.4; }
    let x = M + 13, rowY = y + 1;
    imgs.forEach((im, kk) => { if (kk && kk % 4 === 0) { x = M + 13; rowY += 44; } const box = 40, r = Math.min(box / im.w, box / im.h), w = im.w * r, h = im.h * r; doc.setDrawColor(...Cl.line); doc.rect(x, rowY, box, box); doc.addImage(im.url, 'JPEG', x + (box - w) / 2, rowY + (box - h) / 2, w, h); x += 44; });
    y += rowsImg * 44 + 3; doc.setDrawColor(...Cl.line); doc.line(M, y, M + W, y); y += 7;
  }
  const n = doc.getNumberOfPages();
  for (let kk = 1; kk <= n; kk++) { doc.setPage(kk); txt(`TrillionDispatch · ${baseName(t)} · page ${kk}/${n}`, M, PH - 8, { s: 8, c: Cl.grey }); }
  return doc.output('blob');
}
async function buildZip(t) {
  const csv = buildCsv(t); let pdf = null; try { pdf = await buildPdf(t); } catch (e) {}
  await loadScript(ASSETS.jszip); const zip = new window.JSZip(); const b = baseName(t);
  zip.file(b + '.csv', csv); if (pdf) zip.file(b + '.pdf', pdf);
  for (const s of stopsOf(t.id)) {
    const p = s.proof; if (!p) continue; const f = `preuves/${folderOf(t, s)}/`;
    for (let kk = 0; kk < (p.photos || []).length; kk++) { const bl = await Api.mediaBlob(p.photos[kk]); if (bl) zip.file(`${f}preuve-${kk + 1}.jpg`, bl); }
    if (p.signature) { const bl = await Api.mediaBlob(p.signature); if (bl) zip.file(`${f}signature.png`, bl); }
  }
  return zip.generateAsync({ type: 'blob' });
}
const capDownloads = IN_CLAUDE ? window.claude.use('downloads').catch(() => null) : Promise.resolve(null);
async function saveFile(filename, blob) {
  if (IN_CLAUDE) {
    const dl = await capDownloads; if (!dl) { toast("Le téléchargement n'est pas disponible dans cet aperçu."); return; }
    try { await dl.save({ filename, data: blob }); toast('Fichier enregistré'); }
    catch (e) { const c = e && e.code; if (c === 'declined') return; if (c === 'rate_limited') toast('Une confirmation est déjà ouverte.'); else if (c === 'extension_not_enabled') toast("Ce format n'est pas disponible ici. Prenez le CSV ou le PDF.", 4000); else toast('Téléchargement impossible.'); }
    return;
  }
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 8000); toast('Fichier téléchargé');
}
function canShareFiles() { try { if (IN_CLAUDE || !navigator.canShare) return false; return navigator.canShare({ files: [new File(['x'], 'test.txt', { type: 'text/plain' })] }); } catch (e) { return false; } }
const reportCache = {};
async function prepareShare(t) {
  const key = t.id + ':' + stopsOf(t.id).map(s => s.status + (s.done_at || '')).join(',');
  if (reportCache[key]) return reportCache[key];
  const csv = new File([buildCsv(t)], baseName(t) + '.csv', { type: 'text/csv' });
  let pdf = null; try { pdf = new File([await buildPdf(t)], baseName(t) + '.pdf', { type: 'application/pdf' }); } catch (e) {}
  return (reportCache[key] = reportCache[t.id] = { csv, pdf });
}
async function exportReport(id, kind) {
  const t = C.tours[id]; if (!t) return;
  try {
    if (kind === 'csv') return saveFile(baseName(t) + '.csv', new Blob([buildCsv(t)], { type: 'text/csv' }));
    toast(kind === 'pdf' ? 'Préparation du PDF…' : 'Préparation du rapport complet…', 8000);
    const blob = kind === 'pdf' ? await buildPdf(t) : await buildZip(t);
    await saveFile(baseName(t) + (kind === 'pdf' ? '.pdf' : '.zip'), blob);
  } catch (e) { toast('Export impossible. Le générateur PDF/ZIP se charge depuis internet la première fois : vérifiez la connexion.', 5000); }
}
async function shareReport(id) {
  const t = C.tours[id]; if (!t) return; const r = reportCache[t.id];
  if (!r) { toast('Préparation du rapport… touchez à nouveau dans un instant.'); prepareShare(t); return; }
  const files = [r.pdf, r.csv].filter(Boolean);
  try { if (navigator.canShare({ files })) await navigator.share({ files, title: 'Rapport de tournée', text: `Rapport de tournée du ${fmtShort(t.day)} (${t.driver_name || ''})` }); else await navigator.share({ files: [r.csv], title: 'Rapport de tournée' }); }
  catch (e) { if (e && e.name !== 'AbortError') toast('Partage impossible sur ce téléphone. Utilisez les boutons de téléchargement.'); }
}
/* ---------- geolocation notice, shown once before the first tour ---------- */
function geoNoticeSheet() {
  openSheet('Partage de position', `<p>Pendant la tournée, l'application envoie la <b>dernière position</b> de ce téléphone au dispatcher, environ toutes les minutes.</p>
    <ul class="legal-list"><li>Seulement entre « Démarrer la tournée » et « Tournée terminée ».</li><li>Aucun historique de trajet, aucun contrôle de vitesse, rien en dehors des tournées.</li><li>La position est effacée à la fin de la tournée. Celle jointe aux preuves est gardée 13 mois.</li></ul>
    <p class="small muted">Votre téléphone vous demandera l'autorisation. Vous pouvez la refuser : la tournée marche, sans heure d'arrivée précise ni rappel automatique des fiches.</p>
    <div class="btnrow"><button class="btn" data-act="legal" data-doc="geolocalisation">Lire la note complète</button></div>
    <button class="btn big primary" id="geoOk">J'ai compris, démarrer</button>`, sh => {
    $('#geoOk', sh).addEventListener('click', () => { ls.set('dm-geo-ok', TERMS_VERSION); closeSheet(); ACT.start(); });
  });
}

/* identifiant : un e-mail, ou un nom d'utilisateur sans @ (comptes créés par l'éditeur) */
const loginId = v => { v = String(v || '').trim(); return v.includes('@') ? v : v.toLowerCase() + '@trilliondispatch.invalid'; };

/* ---------- role entry ---------- */
async function enterRole() {
  if (MODE === 'supabase') {
    Api = SupaApi; await SupaApi.init();
    UI.session = await Api.session();
    if (!UI.session) { resetTo('login'); return; }
    if (!UI.name && UI.session.name) { UI.name = UI.session.name; ls.set('dm-name', UI.name); }
  } else UI.session = await Api.session();
  UI.isAdmin = await Api.isAdmin().catch(() => false);
  const tv = await Api.termsStatus().catch(() => '');
  if (tv !== TERMS_VERSION) {
    if (ls.get('dm-terms-intent') === TERMS_VERSION) { await Api.acceptTerms(TERMS_VERSION); ls.set('dm-terms-intent', null); }
    else { resetTo('terms'); return; }
  }
  if (UI.role === 'dispatcher') {
    await Promise.all([Api.listTours(), Api.listDrivers(), Api.listAddresses()]); try { await Api.listPending(); } catch (e) {}
    resetTo('dtours'); return;
  }
  if (UI.pendingCode) { resetTo('join'); if (UI.name) await doJoin(UI.pendingCode, UI.name); return; }
  if (UI.tourId) { try { const ok = await Api.loadDriverTour(UI.tourId); if (ok) { await openDriverTour(UI.tourId); return; } } catch (e) {} }
  try { await Api.driverTours(); } catch (e) {}
  resetTo(getJoined().length ? 'mytours' : 'join');
}
async function doJoin(code, name) {
  const err = $('#jErr'); const show = m => { if (err) { err.textContent = m; err.hidden = false; } else toast(m, 5000); };
  if (normCode(code).length !== 6) { show('Le code fait six caractères, par exemple K7M-4Q2.'); return; }
  if (!name) { show('Indiquez votre prénom : le dispatcher le verra sur la tournée.'); $('#jName')?.focus(); return; }
  UI.name = name; ls.set('dm-name', name);
  try { const id = await Api.joinTour(code, name); UI.pendingCode = ''; ls.set('dm-pending-code', null); await openDriverTour(id); toast('Tournée ouverte'); }
  catch (e) {
    if (e.message === 'need_login') { UI.pendingCode = normCode(code); ls.set('dm-pending-code', UI.pendingCode); resetTo('login'); return; }
    show(e.message === 'code_inconnu' ? 'Code inconnu, ou tournée pas encore envoyée. Vérifiez avec le dispatcher.' : 'Connexion impossible : ' + e.message);
  }
}
async function openDispatchTour(id, push = true) {
  try { await Api.loadTour(id); } catch (e) { toast('Chargement impossible : ' + e.message); return; }
  if (unsub) unsub(); unsub = Api.subscribe(id);
  push ? go('dtour', { id }) : resetTo('dtour', { id });
}
function smallConfirm(title, text, label, fn) {
  openSheet(title, `<p class="note">${esc(text)}</p><div class="btnrow"><button class="btn bad" id="scYes">${esc(label)}</button><button class="btn" data-act="close-sheet">Annuler</button></div>`, sh => {
    $('#scYes', sh).addEventListener('click', async e => { e.target.disabled = true; try { await fn(); } catch (err) { toast(err.message); } closeSheet(); render(); });
  });
}

/* ---------- actions ---------- */
const ACT = {
  back,
  tab: async el => { const to = el.dataset.to; UI.q = '';
    try { if (to === 'dtours') { await Api.listTours(); await Api.listPending(); } if (to === 'dcarnet') { await Api.listAddresses(); await Api.listPending(); } if (to === 'ddrivers') await Api.listDrivers(); if (to === 'mytours') await Api.driverTours(); } catch (e) {}
    resetTo(to); },
  'choose-role': async el => { UI.role = el.dataset.role; ls.set('dm-role', UI.role); try { await enterRole(); } catch (e) { toast('Connexion impossible : ' + e.message, 5000); resetTo('role'); } },
  'switch-role': () => { if (unsub) unsub(); unsub = null; keepAwake(false); stopGeo(); UI.role = null; ls.set('dm-role', null); resetTo('role'); },
  settings: () => { UI.confirmReset = false; go('settings'); },
  dsettings: () => { UI.confirmReset = false; go('dsettings'); },
  'close-sheet': closeSheet,
  'close-viewer': () => { $('#viewer').hidden = true; $('#viewer').innerHTML = ''; },
  pick: el => { el.parentElement.querySelectorAll('.pick').forEach(b => b.setAttribute('aria-pressed', b === el)); },
  'go-join': () => go('join'),
  join: () => doJoin($('#jCode').value, $('#jName').value.trim()),
  login: async () => { const e = $('#lErr'); try { UI.session = await Api.signIn(loginId($('#lEmail').value), $('#lPw').value); await enterRole(); } catch (err) { e.textContent = /invalid/i.test(err.message) ? 'E-mail ou mot de passe incorrect.' : /confirm/i.test(err.message) ? 'Confirmez d’abord votre e-mail (lien reçu par e-mail).' : err.message; e.hidden = false; } },
  signup: async () => { const e = $('#lErr'); const pw = $('#lPw').value, name = $('#lName').value.trim(); if (!name) { e.textContent = 'Indiquez votre prénom et nom pour créer le compte.'; e.hidden = false; return; } if (pw.length < 10) { e.textContent = 'Mot de passe de 10 caractères minimum.'; e.hidden = false; return; } if (!$('#lTerms').checked) { e.textContent = 'Acceptez les conditions et la politique de confidentialité pour créer un compte.'; e.hidden = false; return; } ls.set('dm-terms-intent', TERMS_VERSION); try { UI.session = await Api.signUp($('#lEmail').value.trim(), pw, name); UI.name = name; ls.set('dm-name', name); await enterRole(); } catch (err) { e.textContent = /registered|exists/i.test(err.message) ? 'Un compte existe déjà avec cet e-mail : connectez-vous.' : err.message; e.hidden = false; } },
  google: async () => { const e = $('#lErr'); try { if ($('#lTerms') && $('#lTerms').checked) ls.set('dm-terms-intent', TERMS_VERSION); if (UI.pendingCode) ls.set('dm-pending-code', UI.pendingCode); await Api.signInGoogle(); } catch (err) { e.textContent = /provider is not enabled|Unsupported provider/i.test(err.message) ? 'La connexion Google n’est pas encore activée dans Supabase (Authentication › Providers › Google).' : err.message; e.hidden = false; } },
  forgot: async () => { const e = $('#lErr'), mail = $('#lEmail').value.trim(); if (!mail) { e.textContent = 'Indiquez votre e-mail, puis touchez à nouveau « Mot de passe oublié ».'; e.hidden = false; return; } try { await Api.resetPassword(mail); toast('E-mail envoyé : suivez le lien pour choisir un nouveau mot de passe.', 4500); } catch (err) { e.textContent = err.message; e.hidden = false; } },
  logout: async () => { stopGeo(); keepAwake(false); try { await Api.signOut(); } catch (e) {} for (const k of ['dm-tour', joinedKey, 'dm-pending-code', 'dm-votes', 'dm-terms-intent']) ls.set(k, null); location.reload(); },
  legal: el => { closeSheet(); go('legal', { doc: el.dataset.doc }); },
  'accept-terms': async () => { if (!$('#tAcc').checked) { const e = $('#tErr'); e.textContent = 'Cochez la case pour accepter.'; e.hidden = false; return; } try { await Api.acceptTerms(TERMS_VERSION); await enterRole(); } catch (err) { const e = $('#tErr'); e.textContent = 'Enregistrement impossible : ' + err.message; e.hidden = false; } },
  'export-me': async () => { try { const d = await Api.exportMyData(); await saveFile(`mes-donnees-trilliondispatch_${todayIso()}.json`, new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' })); } catch (e) { toast('Export impossible : ' + e.message); } },
  'delete-ask': () => { UI.confirmDelete = true; render(); },
  'delete-no': () => { UI.confirmDelete = false; render(); },
  'delete-me': async () => {
    if (($('#delConf')?.value || '').trim().toUpperCase() !== 'SUPPRIMER') { toast('Tapez SUPPRIMER pour confirmer.'); return; }
    try { await Api.deleteMyAccount(); } catch (e) { toast(e.message === 'suppression_non_installee' ? 'La suppression de compte n’est pas encore activée sur le serveur (script à lancer dans Supabase).' : 'Suppression impossible : ' + e.message, 6000); return; }
    stopGeo(); try { localStorage.clear(); } catch (e) {} location.reload();
  },
  // driver
  'open-stop': el => { $('#banner').hidden = true; go('stop', { id: el.dataset.id }); },
  'open-dtour-driver': el => openDriverTour(el.dataset.id, true),
  start: async () => { const t = curTour(); if (!t) return;
    if (ls.get('dm-geo-ok') !== TERMS_VERSION) { geoNoticeSheet(); return; }
    try { await Api.driverStart(t.id, UI.name); } catch (e) { toast('Démarrage impossible : ' + e.message); return; } startGeo(onDriverPos); keepAwake(true); resetTo('tour'); toast('Bonne tournée. Le briefing se lance à 150 m de chaque arrêt.', 3600); },
  deliver: el => deliverSheet(el.dataset.id),
  fail: el => failSheet(el.dataset.id),
  reopen: async el => { await Api.driverUpdateStop(el.dataset.id, { status: 'todo', done_at: null, proof: null, fail_reason: null }); render(); toast('Arrêt rouvert'); },
  'go-close': () => go('close'),
  finish: async () => { const t = curTour(); if (!t) return; try { await Api.driverFinish(t.id); } catch (e) { toast(e.message === 'arrets_restants' ? 'Il reste des arrêts sans statut.' : 'Clôture impossible : ' + e.message); return; } keepAwake(false); stopGeo(); UI.stack = [{ name: 'tour' }]; UI.route = { name: 'report', id: t.id }; render(); $('#main').scrollTop = 0; toast('Tournée clôturée.', 3000); },
  simulate: el => { const s = C.stops[el.dataset.id]; if (!s) return; if (!s.arrived_at) Api.driverUpdateStop(s.id, { arrived_at: nowIso() }).catch(() => {}); showBrief(s); },
  'brief-open': el => { $('#banner').hidden = true; go('stop', { id: el.dataset.id }); },
  'brief-close': () => { $('#banner').hidden = true; try { speechSynthesis.cancel(); } catch (e) {} },
  // shared
  'open-address': async el => { closeSheet(); if (MODE === 'supabase' && UI.role === 'dispatcher') await Api.loadAddress(el.dataset.id).catch(() => {}); go(UI.role === 'dispatcher' ? 'daddress' : 'address', { id: el.dataset.id }); },
  'open-report': el => { closeSheet(); go('report', { id: el.dataset.id }); },
  export: el => exportReport(el.dataset.id, el.dataset.kind),
  share: el => shareReport(el.dataset.id),
  'add-photo': el => { const k = el.dataset.id, s = el.dataset.stop; closeSheet(); pickPhoto(f => annotateSheet(f, k, s)); },
  'add-voice': el => { const k = el.dataset.id, s = el.dataset.stop; closeSheet(); voiceSheet(k, s); },
  'add-text': el => { const k = el.dataset.id, s = el.dataset.stop; closeSheet(); textSheet(k, s); },
  vote: async el => {
    const id = el.dataset.id, d = el.dataset.dir, prev = myVotes[id]; let du = 0, dd = 0;
    if (prev === d) { d === 'up' ? du-- : dd--; delete myVotes[id]; } else { if (prev) prev === 'up' ? du-- : dd--; d === 'up' ? du++ : dd++; myVotes[id] = d; }
    saveVotes(); try { UI.role === 'dispatcher' ? await Api.vote(id, du, dd) : await Api.driverVote(id, du, dd); } catch (e) { toast('Vote impossible : ' + e.message); }
    const top = $('#main').scrollTop; render(); $('#main').scrollTop = top;
  },
  'view-media': el => { const p = el.dataset.path; Api.mediaUrl(p).then(u => u && openViewer(u, el.dataset.cap)); },
  'speak-el': el => { const e = C.elements[el.dataset.id]; if (e && !speak(e.transcript)) toast('La lecture vocale n’est pas disponible sur ce navigateur.'); },
  'speak-brief': el => { const s = C.stops[el.dataset.id]; if (s && !speak(briefingText(s))) toast('La lecture vocale n’est pas disponible sur ce navigateur.'); },
  'set-accent': el => { ls.set('dm-accent', applyAccent(el.dataset.id)); render(); toast(`Couleur : ${ACCENTS[el.dataset.id][0].toLowerCase()}`); },
  'change-pw': async () => { const i = $('#newPw'), pw = i.value; if (pw.length < 10) { toast('10 caractères minimum.'); i.focus(); return; } try { await Api.changePassword(pw); i.value = ''; toast('Mot de passe changé.'); } catch (err) { toast(/weak|pwned|leak/i.test(err.message) ? 'Mot de passe trop faible ou déjà divulgué : choisissez-en un autre.' : 'Changement impossible : ' + err.message, 4500); } },
  admin: () => { if (UI.isAdmin) { UI.adminData = null; go('admin'); } },
  'admin-refresh': () => { UI.adminData = null; render(); },
  'test-voice': () => { if (!speak("Arrêt 3. Avenue du Port 86. Consigne : clé dans la boîte grise derrière le hangar, code 1975.")) toast('La lecture vocale n’est pas disponible sur ce navigateur.'); },
  'speak-text': el => { if (!speak(el.dataset.text)) toast('La lecture vocale n’est pas disponible sur ce navigateur.'); },
  reset: () => { UI.confirmReset = true; render(); },
  'reset-no': () => { UI.confirmReset = false; render(); },
  'reset-yes': async () => { await LocalApi.reset(); UI.confirmReset = false; ls.set('dm-tour', null); ls.set(joinedKey, null); UI.tourId = null; toast('Démo réinitialisée'); await enterRole(); },
  // dispatcher
  'open-dtour': el => openDispatchTour(el.dataset.id),
  'new-tour': () => newTourSheet(),
  'new-import': () => newTourSheet({ tab: 'file' }),
  'new-scan': () => newTourSheet({ tab: 'scan' }),
  'new-from-template': () => pickTourSheet('template'),
  'new-duplicate': () => pickTourSheet('tour'),
  'pick-dup': el => { closeSheet(); duplicateSheet(el.dataset.id); },
  'use-template': el => duplicateSheet(el.dataset.id),
  'add-stops': el => addStopsSheet(el.dataset.id),
  optimize: async el => {
    const t = C.tours[el.dataset.id]; if (stopsOf(t.id).filter(s => s.status === 'todo').length < 2) { toast('Pas assez d’arrêts à réordonner.'); return; }
    const before = planInfo(t); const seq = optimizeOrder(t); await Api.reorder(t.id, seq.map(s => s.id)); const after = planInfo(C.tours[t.id]); render();
    toast(`Ordre optimisé : ${after.km.toFixed(1)} km${after.km < before.km - 0.05 ? ` au lieu de ${before.km.toFixed(1)}` : ''}${after.lateCount ? `, ${after.lateCount} hors créneau` : ', créneaux tenus'}`, 4200);
  },
  'tour-settings': el => tourSettingsSheet(el.dataset.id),
  'tour-more': el => tourMoreSheet(el.dataset.id),
  publish: async el => { const id = el.dataset.id; try { await Api.updateTour(id, { status: 'published' }); } catch (e) { toast('Envoi impossible : ' + e.message); return; } render(); shareCodeSheet(id); },
  'share-code': el => shareCodeSheet(el.dataset.id),
  'edit-stop': el => stopEditSheet(el.dataset.id),
  'open-dstop': el => go('dstop', { id: el.dataset.id }),
  'go-pending': async () => { try { await Api.listPending(); } catch (e) {} go('dpending'); },
  'add-gallery': el => { const k = el.dataset.id, s = el.dataset.stop; closeSheet(); pickGallery(fs => annotateQueue(fs, k, s)); },
  'edit-el': el => elementEditSheet(el.dataset.id),
  'approve-el': async el => { try { await Api.updateElement(el.dataset.id, { status: 'ok' }); } catch (e) { toast('Impossible : ' + e.message); return; } const top = $('#main').scrollTop; render(); $('#main').scrollTop = top; toast('Validé : visible par tous les livreurs'); },
  'reject-el': el => { const id = el.dataset.id; smallConfirm('Refuser cette proposition ?', 'Elle est effacée et ne sera vue par personne.', 'Refuser', () => Api.deleteElement(id)); },
  'el-up': el => moveEl(el.dataset.id, -1),
  'el-down': el => moveEl(el.dataset.id, 1),
  'order-mode': () => { closeSheet(); UI.orderMode = !UI.orderMode; render(); },
  'move-up': el => moveStop(el.dataset.id, -1),
  'move-down': el => moveStop(el.dataset.id, 1),
  split: el => { closeSheet(); splitSheet(el.dataset.id); },
  duplicate: el => { closeSheet(); duplicateSheet(el.dataset.id); },
  'save-template': el => { closeSheet(); duplicateSheet(el.dataset.id, { template: true }); },
  'reset-code': el => { const id = el.dataset.id; closeSheet(); smallConfirm('Changer le code ?', "L'ancien code ne marchera plus et les téléphones déjà connectés perdront l'accès. Vous enverrez le nouveau code au livreur.", 'Changer le code', async () => { const c = await Api.resetCode(id); toast('Nouveau code : ' + fmtCode(c), 4000); }); },
  unpublish: async el => { closeSheet(); await Api.updateTour(el.dataset.id, { status: 'draft' }); render(); toast('Tournée repassée en brouillon'); },
  'edit-driver': el => driverSheet(el.dataset.id),
  'edit-address': el => addressEditSheet(el.dataset.id),
  'pin-el': async el => { const e = C.elements[el.dataset.id]; await Api.updateElement(e.id, { pinned: !e.pinned }); render(); },
  'del-el': el => { const id = el.dataset.id; smallConfirm('Supprimer cet élément ?', 'Il disparaît de la fiche pour tous les livreurs.', 'Supprimer', () => Api.deleteElement(id)); },
};
async function moveEl(id, dir) {
  const e = C.elements[id]; const ids = elsOf(e.address_id).filter(x => isOk(x) && !x.pinned).sort(byStep).map(x => x.id); const i = ids.indexOf(id), j = i + dir;
  if (j < 0 || j >= ids.length) return; [ids[i], ids[j]] = [ids[j], ids[i]];
  await Api.reorderElements(e.address_id, ids); const top = $('#main').scrollTop; render(); $('#main').scrollTop = top;
}
async function moveStop(id, dir) {
  const s = C.stops[id]; const ids = stopsOf(s.tour_id).map(x => x.id); const i = ids.indexOf(id), j = i + dir;
  if (j < 0 || j >= ids.length) return; [ids[i], ids[j]] = [ids[j], ids[i]];
  await Api.reorder(s.tour_id, ids); const top = $('#main').scrollTop; render(); $('#main').scrollTop = top;
}
document.addEventListener('click', e => { const el = e.target.closest('[data-act]'); if (!el || el.disabled) return; const f = ACT[el.dataset.act]; if (f) { if (el.tagName !== 'A') e.preventDefault(); f(el, e); } });
$('#overlay').addEventListener('click', e => { if (e.target.id === 'overlay') closeSheet(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('#viewer').hidden) ACT['close-viewer'](); else closeSheet(); } if (e.key === 'Enter' && e.target.id === 'jCode') ACT.join(); });
$('#filePhoto').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f && UI.onPhoto) UI.onPhoto(f); });
$('#fileGallery').addEventListener('change', e => { const fs = e.target.files ? [...e.target.files] : []; if (fs.length && UI.onGallery) UI.onGallery(fs); });
$('#fileAudio').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f && UI.onAudio) UI.onAudio(f); });
$('#fileData').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f && UI.onData) UI.onData(f); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && UI.role === 'driver' && curTour()?.status === 'active') keepAwake(true); });

/* ---------- boot ---------- */
function readHash() {
  const err = location.hash.match(/error_description=([^&]+)/); if (err) { setTimeout(() => toast('Connexion refusée : ' + decodeURIComponent(err[1].replace(/\+/g, ' ')), 6000), 300); }
  const m = location.hash.match(/^#t-([A-Za-z0-9]{6})$/); if (!m) return false;
  UI.pendingCode = m[1].toUpperCase(); ls.set('dm-pending-code', UI.pendingCode); UI.role = 'driver'; ls.set('dm-role', 'driver');
  try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} return true;
}
UI.pendingCode = ls.get('dm-pending-code', '') || '';
window.addEventListener('hashchange', () => { if (readHash()) enterRole().catch(e => toast(e.message)); });
(async function boot() {
  if (MODE === 'local') { await LocalApi.init(); Api = LocalApi; }
  readHash();
  if (UI.role) { try { await enterRole(); } catch (e) { console.error(e); resetTo('role'); toast('Connexion impossible : ' + e.message, 5000); } }
  else resetTo('role');
  try { speechSynthesis.getVoices(); } catch (e) {}
})();
