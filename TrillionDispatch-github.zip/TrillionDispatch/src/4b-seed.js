function sketch(kind) {
  const Y = '#FFC21A', K = '#111';
  let b = '';
  if (kind === 'hangar') {
    let corr = ''; for (let y = 185; y < 305; y += 18) corr += `<path d="M48 ${y}H382" stroke="#9aa1a3" stroke-width="3"/>`;
    let bars = ''; for (let x = 440; x <= 600; x += 20) bars += `<path d="M${x} 215V310" stroke="#2a2f33" stroke-width="5"/>`;
    b = `<rect width="640" height="480" fill="#a9b6c2"/><rect y="310" width="640" height="170" fill="#4f565c"/>
<path d="M40 310V165L215 100L390 165V310Z" fill="#cfd4d2" stroke="#353b40" stroke-width="5"/>${corr}
<rect x="160" y="210" width="110" height="100" fill="#7d868c" stroke="#353b40" stroke-width="5"/>
<path d="M430 215H610M430 310H610" stroke="#2a2f33" stroke-width="5"/>${bars}
<path d="M455 455C470 390 500 330 520 262" fill="none" stroke="${K}" stroke-width="24" stroke-linecap="round"/>
<path d="M455 455C470 390 500 330 520 262" fill="none" stroke="${Y}" stroke-width="14" stroke-linecap="round"/>
<path d="M494 282L524 234L550 290Z" fill="${Y}" stroke="${K}" stroke-width="5" stroke-linejoin="round"/>`;
  } else if (kind === 'box') {
    let bricks = ''; for (let r = 0; r < 15; r++) { const y = r * 34; bricks += `<path d="M0 ${y}H640" stroke="#6f6259" stroke-width="3"/>`; for (let x = (r % 2) * 40; x < 640; x += 80) bricks += `<path d="M${x} ${y}V${y + 34}" stroke="#6f6259" stroke-width="3"/>`; }
    b = `<rect width="640" height="480" fill="#8d7f75"/>${bricks}
<rect x="250" y="140" width="140" height="180" rx="8" fill="#9aa1a6" stroke="#3b4045" stroke-width="6"/>
<rect x="296" y="196" width="48" height="58" rx="5" fill="#3b4045"/>
<g fill="#cfd4d2">${[0, 1, 2].map(r => [0, 1].map(c => `<rect x="${303 + c * 20}" y="${203 + r * 17}" width="13" height="11" rx="2"/>`).join('')).join('')}</g>
<ellipse cx="320" cy="230" rx="132" ry="142" fill="none" stroke="${K}" stroke-width="18"/>
<ellipse cx="320" cy="230" rx="132" ry="142" fill="none" stroke="${Y}" stroke-width="9"/>`;
  } else {
    let zig = 'M280 175'; for (let x = 300; x <= 600; x += 20) zig += `L${x} ${(x / 20) % 2 ? 205 : 175}`;
    b = `<rect width="640" height="480" fill="#6b7178"/><rect width="640" height="150" fill="#b9bfc4"/>
<rect x="40" y="18" width="210" height="132" fill="#e2dccf" stroke="#444" stroke-width="4"/><rect x="66" y="62" width="158" height="88" fill="#7fa7c4"/>
<text x="145" y="48" text-anchor="middle" font-family="Arial,sans-serif" font-weight="700" font-size="19" fill="#2a6e3f">PHARMACIE</text>
<path d="${zig}" fill="none" stroke="${Y}" stroke-width="6"/>
<text x="440" y="250" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="30" fill="${Y}">LIVRAISON</text>
<path d="M0 330H640" stroke="#e8e8e8" stroke-width="6" stroke-dasharray="40 30"/>
<ellipse cx="440" cy="210" rx="205" ry="72" fill="none" stroke="${K}" stroke-width="16"/>
<ellipse cx="440" cy="210" rx="205" ry="72" fill="none" stroke="${Y}" stroke-width="8"/>`;
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480">${b}<rect x="14" y="434" width="232" height="32" rx="6" fill="#000" opacity=".55"/><text x="26" y="457" font-family="Arial,sans-serif" font-size="18" font-weight="700" fill="#fff">CROQUIS D'EXEMPLE</text></svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}
const daysAgo = d => new Date(Date.now() - d * 86400000).toISOString();
function seedLocal() {
  const st = { v: 2, tours: {}, stops: {}, addresses: {}, elements: {}, drivers: {}, members: [] };
  const addr = (label, lat, lng, extra = {}) => { const p = parseAddr(label); const a = { id: newId(), key: p.key, label, pc: p.pc, city: cityOf(label), lat, lng, client: '', phone: '', visits: 0, last_visit: null, created_at: daysAgo(90), ...extra }; st.addresses[a.id] = a; return a; };
  let pos = 0; const el = (a, f) => { const e = { id: newId(), address_id: a.id, type: 'text', tag: 'Autre', body: '', transcript: '', media: null, author: '', pinned: false, up: 0, down: 0, created_at: nowIso(), sample: true, status: 'ok', position: ++pos, created_by: 'local-dispatcher', ...f }; st.elements[e.id] = e; };
  for (const d of [['Karim', '0470 00 00 11', 'Fiat Ducato', 900], ['Youssef', '0470 00 00 12', 'Renault Kangoo', 600], ['Mehdi', '0470 00 00 13', 'Vélo cargo', 120]]) { const x = { id: newId(), name: d[0], phone: d[1], vehicle: d[2], capacity_kg: d[3], skills: [], active: true }; st.drivers[x.id] = x; }
  const karim = Object.values(st.drivers)[0];
  const port = addr('Avenue du Port 86, 1000 Bruxelles', 50.8665, 4.3468, { visits: 4, last_visit: daysAgo(5), client: 'Épicerie Fine Delvaux (réserve)' });
  el(port, { type: 'text', tag: 'Clé', body: 'Clé dans la boîte grise derrière le hangar, code 1975. Refermer la boîte.', author: 'Dispatcher', created_at: daysAgo(60), up: 6, pinned: true });
  el(port, { type: 'photo', tag: 'Accès', media: sketch('hangar'), body: 'Passer par la grille à droite du hangar', author: 'Youssef', created_at: daysAgo(40), up: 4 });
  el(port, { type: 'photo', tag: 'Clé', media: sketch('box'), body: 'La boîte à clé, au mur du quai 3', author: 'Youssef', created_at: daysAgo(40), up: 3 });
  el(port, { type: 'voice', tag: 'Accès', transcript: "Tu passes par la grille à droite du hangar, tu longes le mur jusqu'au quai 3. La clé est dans la boîte grise accrochée au mur, code 1975. Les bacs vont dans la chambre froide, à gauche en entrant.", author: 'Karim', created_at: daysAgo(12), up: 2 });
  const louise = addr('Avenue Louise 143 bte 4, 1050 Ixelles', 50.8303, 4.3605, { visits: 2, last_visit: daysAgo(30) });
  el(louise, { tag: 'Interphone', body: 'Interphone n°4 en panne : appeler le client depuis le hall. Ascenseur au fond à droite, 3e étage.', author: 'Mehdi', created_at: daysAgo(120), up: 2 });
  el(louise, { tag: 'Accès', body: 'Le code de la porte d’entrée a changé : 4512.', author: 'Youssef', created_at: daysAgo(1), status: 'pending', created_by: 'other-driver' });
  const palais = addr('Rue des Palais 44, 1030 Schaerbeek', 50.8615, 4.3655, { visits: 1, last_visit: daysAgo(20) });
  el(palais, { type: 'photo', tag: 'Stationnement', media: sketch('parking'), body: 'Zone de livraison en face, devant la pharmacie', author: 'Youssef', created_at: daysAgo(20), up: 1 });
  el(palais, { tag: 'Animal', body: 'Chien dans la cour : sonner et attendre que la fleuriste ouvre.', author: 'Mehdi', created_at: daysAgo(400) });
  const others = [
    ['Chaussée de Haecht 563, 1030 Schaerbeek', 50.8693, 4.3826], ['Rue Picard 7, 1080 Molenbeek-Saint-Jean', 50.8612, 4.3420],
    ['Boulevard Général Jacques 26, 1050 Ixelles', 50.8217, 4.3812], ['Rue Vanderkindere 120, 1180 Uccle', 50.8140, 4.3535],
    ['Chaussée de Louvain 430, 1030 Schaerbeek', 50.8546, 4.3893], ['Rue Royale 236, 1210 Saint-Josse-ten-Noode', 50.8560, 4.3680],
    ['Avenue de Tervueren 12, 1040 Etterbeek', 50.8390, 4.3990], ['Rue de Flandre 50, 1000 Bruxelles', 50.8530, 4.3460],
  ].map(([l, la, ln]) => addr(l, la, ln));
  const byLabel = l => Object.values(st.addresses).find(a => a.label.startsWith(l));
  const depot = { label: 'Dépôt, Avenue Rogier 210, 1030 Schaerbeek', lat: 50.8618, lng: 4.3779 };
  const T1 = blankTour({ name: 'Tournée exemple', code: 'K7M4Q2', status: 'published', driver_id: karim.id, driver_name: 'Karim', depot, start_time: '08:00', capacity_kg: 900, created_at: daysAgo(1) });
  st.tours[T1.id] = T1;
  const rows = [
    ['Chaussée de Haecht 563', 'Garage Haecht Auto', '0470 00 00 01', '08:00', '10:00', '2 colis, pièces moteur', 14, 'CMD-24101', 0, ''],
    ['Rue des Palais 44', 'Fleurs Margaux', '0470 00 00 02', '09:00', '12:00', '1 carton fragile', 3, 'CMD-24102', 0, ''],
    ['Avenue du Port 86', 'Épicerie Fine Delvaux (réserve)', '0470 00 00 03', '07:00', '09:30', '3 bacs isothermes', 45, 'CMD-24103', 1, 'Livrer avant 9h30, chambre froide'],
    ['Rue Picard 7', 'Studio Picard', '0470 00 00 04', null, null, '1 enveloppe A4', 0.2, 'CMD-24104', 0, ''],
    ['Avenue Louise 143', 'Cabinet Moreau & Associés', '0470 00 00 05', '10:00', '12:00', '2 colis', 8, 'CMD-24105', 0, ''],
    ['Boulevard Général Jacques 26', 'Atelier Vélo Ixelles', '0470 00 00 06', null, null, '1 roue arrière emballée', 4, 'CMD-24106', 0, ''],
    ['Rue Vanderkindere 120', 'Boulangerie Saint-Job', '0470 00 00 07', '14:00', '16:00', '4 sacs de farine', 100, 'CMD-24107', 0, 'Sacs à la réserve, porte de derrière'],
    ['Chaussée de Louvain 430', 'Traiteur Al Baraka', '0470 00 00 08', null, null, '2 caisses', 22, 'CMD-24108', 0, ''],
  ];
  rows.forEach((r, i) => { const a = byLabel(r[0]); const s = blankStop({ tour_id: T1.id, address_id: a.id, rank: i + 1, raw: r[0] === 'Avenue Louise 143' ? 'Av. Louise 143/4, 1050 Bruxelles' : a.label, client: r[1], phone: r[2], win_start: r[3], win_end: r[4], notes: r[5], weight_kg: r[6], ref: r[7], priority: r[8], driver_note: r[9] }); st.stops[s.id] = s; if (!a.client) a.client = r[1]; if (!a.phone) a.phone = r[2]; });
  const T2 = blankTour({ name: 'Tournée du lundi', is_template: true, depot, start_time: '13:30', created_at: daysAgo(10) });
  st.tours[T2.id] = T2;
  ['Rue Royale 236', 'Avenue de Tervueren 12', 'Rue de Flandre 50', 'Chaussée de Louvain 430'].forEach((l, i) => { const a = byLabel(l); const s = blankStop({ tour_id: T2.id, address_id: a.id, rank: i + 1, raw: a.label, client: ['Pharmacie Royale', 'Bureau Tervueren', 'Café de Flandre', 'Traiteur Al Baraka'][i], service_min: 5 }); st.stops[s.id] = s; });
  return st;
}
