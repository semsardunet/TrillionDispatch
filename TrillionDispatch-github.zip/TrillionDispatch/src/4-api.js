/* ---------- storage: IndexedDB on this phone, memory fallback ---------- */
const Store = {
  db: null, mem: new Map(), memState: null,
  async open() {
    try {
      this.db = await new Promise((res, rej) => {
        const r = indexedDB.open('dernier-metre-v2', 1);
        r.onupgradeneeded = () => { r.result.createObjectStore('kv'); r.result.createObjectStore('blobs'); };
        r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
        setTimeout(() => rej(new Error('timeout')), 4000);
      });
    } catch (e) { this.db = null; }
  },
  tx(store, mode, fn) {
    return new Promise((res, rej) => {
      const t = this.db.transaction(store, mode); const req = fn(t.objectStore(store));
      t.oncomplete = () => res(req ? req.result : undefined); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    });
  },
  async get(k) { if (!this.db) return this.memState; try { return await this.tx('kv', 'readonly', s => s.get(k)); } catch (e) { return null; } },
  async set(k, v) { if (!this.db) { this.memState = v; return; } try { await this.tx('kv', 'readwrite', s => s.put(v, k)); } catch (e) { /* quota or private mode */ } },
  async putBlob(blob, id = uid()) { this.mem.set(id, blob); if (this.db) { try { await this.tx('blobs', 'readwrite', s => s.put(blob, id)); } catch (e) {} } return id; },
  async getBlob(id) {
    if (this.mem.has(id)) return this.mem.get(id); if (!this.db) return null;
    try { const b = await this.tx('blobs', 'readonly', s => s.get(id)); if (b) this.mem.set(id, b); return b || null; } catch (e) { return null; }
  },
  async clear() { this.mem.clear(); this.memState = null; if (this.db) { try { await this.tx('kv', 'readwrite', s => s.clear()); await this.tx('blobs', 'readwrite', s => s.clear()); } catch (e) {} } },
};

/* ---------- data access: one interface, two backends ---------- */
const listeners = new Set();
let emitT = null;
function emitChange() { clearTimeout(emitT); emitT = setTimeout(() => listeners.forEach(f => { try { f(); } catch (e) {} }), 60); }
const joinedKey = 'dm-joined';
const getJoined = () => { try { return JSON.parse(localStorage.getItem(joinedKey) || '[]'); } catch (e) { return []; } };
const addJoined = id => { try { const j = getJoined().filter(x => x !== id); j.unshift(id); localStorage.setItem(joinedKey, JSON.stringify(j.slice(0, 30))); } catch (e) {} };
const urlCache = new Map();
function blankTour(f = {}) {
  return Object.assign({ id: newId(), code: genCode(), name: 'Tournée', day: todayIso(), status: 'draft', is_template: false, driver_id: null, driver_name: '', depot: { label: 'Dépôt', lat: 50.8618, lng: 4.3779 }, start_time: '08:00', return_to_depot: true, capacity_kg: null, options: {}, started_at: null, ended_at: null, last_pos: null, created_at: nowIso(), updated_at: nowIso() }, f);
}
function blankStop(f = {}) {
  return Object.assign({ id: newId(), tour_id: null, address_id: null, rank: 0, raw: '', client: '', phone: '', ref: '', notes: '', driver_note: '', win_start: null, win_end: null, service_min: 4, priority: 0, weight_kg: null, locked: false, status: 'todo', fail_reason: '', reschedule: null, arrived_at: null, done_at: null, proof: null, fiche_added: 0, updated_at: nowIso() }, f);
}
const STOP_FIELDS = ['raw', 'client', 'phone', 'ref', 'notes', 'driver_note', 'win_start', 'win_end', 'service_min', 'priority', 'weight_kg', 'locked', 'address_id'];

/* ----- demo backend: everything in this browser (IndexedDB), tabs kept in sync ----- */
const bc = ('BroadcastChannel' in window) ? new BroadcastChannel('dm-local-v2') : null;
const LocalApi = {
  mode: 'local', st: null,
  bind() { for (const k of ['tours', 'stops', 'addresses', 'elements', 'drivers']) C[k] = this.st[k]; },
  async init() {
    await Store.open();
    this.st = await Store.get('v2');
    if (!this.st || !this.st.v) { this.st = seedLocal(); await Store.set('v2', this.st); }
    this.bind();
    if (bc) bc.onmessage = async () => { const s = await Store.get('v2'); if (s) { this.st = s; this.bind(); emitChange(); } };
  },
  async fresh() { const s = await Store.get('v2'); if (s && s.v) { this.st = s; this.bind(); } },
  async commit() { this.st.updated = Date.now(); await Store.set('v2', this.st); bc && bc.postMessage(1); emitChange(); },
  async reset() { await Store.clear(); urlCache.clear(); this.st = seedLocal(); await Store.set('v2', this.st); this.bind(); bc && bc.postMessage(1); emitChange(); },
  // session
  async dispatcherSession() { return { email: 'démo (sans compte)', name: '' }; },
  async session() { return { email: 'démo (sans compte)', name: '' }; },
  async signIn() { return true; }, async signUp() { return true; }, async signOut() { return true; },
  async signInGoogle() { throw new Error('La connexion Google marche sur la version hébergée.'); },
  async resetPassword() { throw new Error('Pas de compte en mode démo.'); },
  async termsStatus() { return ls.get('dm-terms', ''); },
  async isAdmin() { return false; },
  async acceptTerms(v) { ls.set('dm-terms', v); },
  async exportMyData() { return { mode: 'démo', exporte_le: nowIso(), donnees: this.st }; },
  async deleteMyAccount() { await this.reset(); },
  // dispatcher
  async listTours() { return Object.values(C.tours); },
  async loadTour(id) { return C.tours[id] || null; },
  async createTour(f) { await this.fresh(); const t = blankTour(f); C.tours[t.id] = t; await this.commit(); return t; },
  async updateTour(id, patch) { await this.fresh(); Object.assign(C.tours[id], patch, { updated_at: nowIso() }); await this.commit(); return C.tours[id]; },
  async deleteTour(id) { await this.fresh(); for (const s of stopsOf(id)) delete C.stops[s.id]; delete C.tours[id]; await this.commit(); },
  async resetCode(id) { await this.fresh(); C.tours[id].code = genCode(); this.st.members = (this.st.members || []).filter(m => m.tour_id !== id); await this.commit(); return C.tours[id].code; },
  async ensureAddress(f) {
    await this.fresh(); const p = parseAddr(f.label);
    let a = Object.values(C.addresses).find(x => x.key === p.key);
    if (a) { if (!hasXY(a) && f.lat != null) { a.lat = f.lat; a.lng = f.lng; } if (f.client && !a.client) a.client = f.client; if (f.phone && !a.phone) a.phone = f.phone; await this.commit(); return { addr: a, known: true }; }
    a = { id: newId(), key: p.key, label: f.label.trim(), pc: p.pc, city: cityOf(f.label), lat: f.lat ?? null, lng: f.lng ?? null, client: f.client || '', phone: f.phone || '', visits: 0, last_visit: null, created_at: nowIso() };
    C.addresses[a.id] = a; await this.commit(); return { addr: a, known: false };
  },
  async updateAddress(id, patch) { await this.fresh(); Object.assign(C.addresses[id], patch); await this.commit(); },
  async addStops(tid, list) { await this.fresh(); let r = Math.max(0, ...stopsOf(tid).map(s => s.rank)); const out = list.map(f => { const s = blankStop({ ...f, tour_id: tid, rank: ++r }); C.stops[s.id] = s; return s; }); await this.commit(); return out; },
  async updateStop(id, patch) { await this.fresh(); Object.assign(C.stops[id], patch, { updated_at: nowIso() }); await this.commit(); },
  async deleteStops(ids) { await this.fresh(); ids.forEach(id => delete C.stops[id]); await this.commit(); },
  async reorder(tid, ids) { await this.fresh(); ids.forEach((id, i) => { if (C.stops[id]) C.stops[id].rank = i + 1; }); await this.commit(); },
  async moveStops(ids, to) { await this.fresh(); let r = Math.max(0, ...stopsOf(to).map(s => s.rank)); ids.forEach(id => { C.stops[id].tour_id = to; C.stops[id].rank = ++r; }); await this.commit(); },
  async listAddresses() { return Object.values(C.addresses); },
  async loadAddress(id) { return C.addresses[id]; },
  myId() { return UI.role === 'dispatcher' ? 'local-dispatcher' : 'local-driver'; },
  async addElement(aid, el, stopId, pending = false) {
    await this.fresh(); const pos = Math.max(0, ...elsOf(aid).map(x => x.position || 0)) + 1;
    if (el.pinned) elsOf(aid).forEach(x => { x.pinned = false; });
    const e = Object.assign({ id: newId(), address_id: aid, type: 'text', tag: 'Autre', body: '', transcript: '', media: null, author: '', pinned: false, up: 0, down: 0, created_at: nowIso(), position: pos, status: pending ? 'pending' : 'ok', created_by: this.myId() }, el, pending ? { pinned: false } : {});
    C.elements[e.id] = e; if (stopId && C.stops[stopId]) C.stops[stopId].fiche_added = (C.stops[stopId].fiche_added || 0) + 1; await this.commit(); return e;
  },
  async reorderElements(aid, ids) { await this.fresh(); ids.forEach((id, i) => { if (C.elements[id]) C.elements[id].position = i + 1; }); await this.commit(); },
  async listPending() { return Object.values(C.elements).filter(e => !isOk(e)); },
  async updateElement(id, patch) { await this.fresh(); if (patch.pinned) elsOf(C.elements[id].address_id).forEach(x => { x.pinned = false; }); Object.assign(C.elements[id], patch); await this.commit(); },
  async deleteElement(id) { await this.fresh(); delete C.elements[id]; await this.commit(); },
  async vote(id, du, dd) { await this.fresh(); const e = C.elements[id]; if (!e) return; e.up = Math.max(0, (e.up || 0) + du); e.down = Math.max(0, (e.down || 0) + dd); await this.commit(); },
  async listDrivers() { return Object.values(C.drivers); },
  async saveDriver(d) { await this.fresh(); const x = Object.assign({ id: d.id || newId(), name: '', phone: '', vehicle: '', capacity_kg: null, skills: [], active: true }, C.drivers[d.id] || {}, d); C.drivers[x.id] = x; await this.commit(); return x; },
  async deleteDriver(id) { await this.fresh(); delete C.drivers[id]; await this.commit(); },
  // driver
  async ensureDriverSession() { return true; },
  async joinTour(code, name) { await this.fresh(); const c = normCode(code); const t = Object.values(C.tours).find(x => x.code === c && !x.is_template && x.status !== 'draft'); if (!t) throw new Error('code_inconnu'); addJoined(t.id); return t.id; },
  async driverTours() { return getJoined().map(id => C.tours[id]).filter(Boolean); },
  async loadDriverTour(id) { return C.tours[id] || null; },
  async driverStart(tid, name) { await this.fresh(); const t = C.tours[tid]; if (t.status === 'published' || t.status === 'active') { t.status = 'active'; t.started_at = t.started_at || nowIso(); if (name) t.driver_name = name; } await this.commit(); },
  async driverUpdateStop(id, patch) {
    await this.fresh(); const s = C.stops[id]; const before = s.status; Object.assign(s, patch, { updated_at: nowIso() }); const a = C.addresses[s.address_id];
    if (a && s.status === 'done' && before !== 'done') { a.visits = (a.visits || 0) + 1; a.last_visit = nowIso(); }
    if (a && s.status !== 'done' && before === 'done') a.visits = Math.max(0, (a.visits || 1) - 1);
    await this.commit();
  },
  async driverAddElement(aid, stopId, el) { return this.addElement(aid, el, stopId, true); },
  async driverVote(id, du, dd) { return this.vote(id, du, dd); },
  async driverFinish(tid) { await this.fresh(); if (stopsOf(tid).some(s => s.status === 'todo')) throw new Error('arrets_restants'); Object.assign(C.tours[tid], { status: 'done', ended_at: nowIso() }); await this.commit(); },
  async ping(tid, p) { const t = C.tours[tid]; if (!t || t.status !== 'active') return; t.last_pos = { lat: p.lat, lng: p.lng, acc: p.acc, at: nowIso() }; await this.commit(); },
  // media
  async upload(blob, ext) { const path = `local/${newId()}.${ext}`; await Store.putBlob(blob, path); return path; },
  async mediaUrl(path) { if (!path) return ''; if (path.startsWith('data:')) return path; if (urlCache.has(path)) return urlCache.get(path); const b = await Store.getBlob(path); if (!b) return ''; const u = URL.createObjectURL(b); urlCache.set(path, u); return u; },
  async mediaBlob(path) { if (!path) return null; if (path.startsWith('data:')) { const r = await fetch(path); return r.blob(); } return Store.getBlob(path); },
  subscribe() { return () => {}; },
};

/* ----- Supabase backend ----- */
const SupaApi = {
  mode: 'supabase', sb: null, role: null, uid: null, channels: {},
  async init() {
    if (this.sb) return;
    await loadScript(ASSETS.supabase);
    this.sb = window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: 'dm-auth' } });
    const { data } = await this.sb.auth.getSession(); this.uid = data.session?.user?.id || null;
  },
  ok(r) { if (r.error) { const e = new Error(r.error.message || 'erreur'); e.code = r.error.code; throw e; } return r.data; },
  put(table, rows) { for (const r of [].concat(rows || [])) if (r && r.id) C[table][r.id] = r; },
  // session
  async session() {
    const { data } = await this.sb.auth.getSession(); const u = data.session?.user; if (!u || u.is_anonymous) return null; this.uid = u.id;
    const md = u.user_metadata || {}; let name = md.full_name || md.name || '';
    try { const p = (await this.sb.from('profiles').select('display_name,phone').eq('id', u.id).maybeSingle()).data; if (p && p.display_name) name = p.display_name; } catch (e) {}
    return { email: u.email, name, provider: u.app_metadata?.provider || 'email' };
  },
  async dispatcherSession() { return this.session(); },
  async signIn(email, password) { this.ok(await this.sb.auth.signInWithPassword({ email, password })); return this.session(); },
  async signUp(email, password, name) { const d = this.ok(await this.sb.auth.signUp({ email, password, options: { data: { full_name: name || '' }, emailRedirectTo: location.origin + location.pathname } })); if (!d.session) throw new Error('Compte créé. Ouvrez l’e-mail de confirmation, puis connectez-vous.'); return this.session(); },
  async signInGoogle() { const r = await this.sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: location.origin + location.pathname, queryParams: { prompt: 'select_account' } } }); if (r.error) throw r.error; },
  async changePassword(pw) { this.ok(await this.sb.auth.updateUser({ password: pw })); },
  async resetPassword(email) { this.ok(await this.sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname })); },
  async isAdmin() { const r = await this.sb.rpc('is_admin'); return r.data === true; },
  async adminOverview() { return this.ok(await this.sb.rpc('admin_overview')); },
  async termsStatus() { const r = await this.sb.from('profiles').select('terms_version').eq('id', this.uid).maybeSingle(); return r.data?.terms_version || ''; },
  async acceptTerms(v) { this.ok(await this.sb.from('profiles').update({ terms_version: v, terms_accepted_at: nowIso() }).eq('id', this.uid)); },
  async exportMyData() {
    const q = async (t, col) => this.ok(await this.sb.from(t).select('*').eq(col, this.uid));
    const out = { exporte_le: nowIso(), compte: (await this.sb.auth.getUser()).data.user, profil: await q('profiles', 'id'), tournees_rejointes: await q('tour_members', 'user_id'), ajouts_aux_fiches: await q('elements', 'created_by') };
    const own = await q('tours', 'owner'); if (own.length) Object.assign(out, { tournees: own, arrets: await q('stops', 'owner'), adresses: await q('addresses', 'owner'), fiches: await q('elements', 'owner'), livreurs: await q('drivers', 'owner') });
    return out;
  },
  async deleteMyAccount() {
    for (let guard = 0; guard < 50; guard++) {                 // the person's own files first (photos, vocals, signatures)
      const r = await this.sb.storage.from('media').list(this.uid, { limit: 100 }); if (r.error || !r.data || !r.data.length) break;
      const rm = await this.sb.storage.from('media').remove(r.data.map(f => `${this.uid}/${f.name}`)); if (rm.error) break;
    }
    const r = await this.sb.rpc('delete_my_account');
    if (r.error) throw new Error(/function .*delete_my_account|Could not find/i.test(r.error.message) ? 'suppression_non_installee' : r.error.message);
    await this.sb.auth.signOut();
  },
  async saveProfile(p) { this.ok(await this.sb.from('profiles').upsert({ id: this.uid, display_name: p.name || null, phone: p.phone || null })); },
  async signOut() { await this.sb.auth.signOut(); this.uid = null; },
  // dispatcher
  async listTours() { const d = this.ok(await this.sb.from('tours').select('*').order('day', { ascending: false }).limit(200)); this.put('tours', d); const ids = d.map(t => t.id); if (ids.length) this.put('stops', this.ok(await this.sb.from('stops').select('id,tour_id,rank,status,weight_kg,address_id').in('tour_id', ids))); return d; },
  async loadTour(id) {
    const t = this.ok(await this.sb.from('tours').select('*').eq('id', id).maybeSingle()); if (!t) return null; this.put('tours', t);
    const ss = this.ok(await this.sb.from('stops').select('*').eq('tour_id', id).order('rank'));
    Object.values(C.stops).filter(s => s.tour_id === id && !ss.find(x => x.id === s.id)).forEach(s => delete C.stops[s.id]);
    this.put('stops', ss); await this.fetchAddresses([...new Set(ss.map(s => s.address_id))]); return t;
  },
  async fetchAddresses(ids) {
    if (!ids.length) return; this.put('addresses', this.ok(await this.sb.from('addresses').select('*').in('id', ids)));
    this.put('elements', this.ok(await this.sb.from('elements').select('*').in('address_id', ids)));
  },
  async createTour(f) { const t = blankTour(f); delete t.id; delete t.code; delete t.created_at; delete t.updated_at; t.owner = this.uid; const d = this.ok(await this.sb.from('tours').insert(t).select().single()); this.put('tours', d); return d; },
  async updateTour(id, patch) { const d = this.ok(await this.sb.from('tours').update({ ...patch, updated_at: nowIso() }).eq('id', id).select().single()); this.put('tours', d); return d; },
  async deleteTour(id) { this.ok(await this.sb.from('tours').delete().eq('id', id)); stopsOf(id).forEach(s => delete C.stops[s.id]); delete C.tours[id]; },
  async resetCode(id) { const c = this.ok(await this.sb.rpc('reset_tour_access', { p_tour: id })); C.tours[id].code = c; return c; },
  async ensureAddress(f) {
    const p = parseAddr(f.label);
    let a = this.ok(await this.sb.from('addresses').select('*').eq('key', p.key).eq('owner', this.uid).maybeSingle());
    if (a) { const patch = {}; if (!hasXY(a) && f.lat != null) { patch.lat = f.lat; patch.lng = f.lng; } if (f.client && !a.client) patch.client = f.client; if (f.phone && !a.phone) patch.phone = f.phone; if (Object.keys(patch).length) a = this.ok(await this.sb.from('addresses').update(patch).eq('id', a.id).select().single()); this.put('addresses', a); return { addr: a, known: true }; }
    const row = { owner: this.uid, key: p.key, label: f.label.trim(), pc: p.pc, city: cityOf(f.label), lat: f.lat ?? null, lng: f.lng ?? null, client: f.client || null, phone: f.phone || null };
    const r = await this.sb.from('addresses').insert(row).select().single();
    if (r.error && r.error.code === '23505') { a = this.ok(await this.sb.from('addresses').select('*').eq('key', p.key).eq('owner', this.uid).single()); this.put('addresses', a); return { addr: a, known: true }; }
    a = this.ok(r); this.put('addresses', a); return { addr: a, known: false };
  },
  async updateAddress(id, patch) { this.put('addresses', this.ok(await this.sb.from('addresses').update(patch).eq('id', id).select().single())); },
  async addStops(tid, list) { let r = Math.max(0, ...stopsOf(tid).map(s => s.rank)); const rows = list.map(f => { const s = blankStop({ ...f, tour_id: tid, rank: ++r }); delete s.id; s.owner = this.uid; return s; }); const d = this.ok(await this.sb.from('stops').insert(rows).select()); this.put('stops', d); return d; },
  async updateStop(id, patch) { this.put('stops', this.ok(await this.sb.from('stops').update({ ...patch, updated_at: nowIso() }).eq('id', id).select().single())); },
  async deleteStops(ids) { this.ok(await this.sb.from('stops').delete().in('id', ids)); ids.forEach(id => delete C.stops[id]); },
  async reorder(tid, ids) { ids.forEach((id, i) => { if (C.stops[id]) C.stops[id].rank = i + 1; }); this.ok(await this.sb.rpc('reorder_stops', { p_tour: tid, p_ids: ids })); },
  async moveStops(ids, to) { let r = Math.max(0, ...stopsOf(to).map(s => s.rank)); for (const id of ids) { this.put('stops', this.ok(await this.sb.from('stops').update({ tour_id: to, rank: ++r }).eq('id', id).select().single())); } },
  async listAddresses() { const d = this.ok(await this.sb.from('addresses').select('*').order('created_at', { ascending: false }).limit(2000)); this.put('addresses', d); const ids = d.map(a => a.id); for (let i = 0; i < ids.length; i += 100) this.put('elements', this.ok(await this.sb.from('elements').select('*').in('address_id', ids.slice(i, i + 100)))); return d; },
  async loadAddress(id) { await this.fetchAddresses([id]); const ss = this.ok(await this.sb.from('stops').select('*').eq('address_id', id).neq('status', 'todo').order('done_at', { ascending: false }).limit(50)); this.put('stops', ss); const tids = [...new Set(ss.map(s => s.tour_id))].filter(x => !C.tours[x]); if (tids.length) this.put('tours', this.ok(await this.sb.from('tours').select('*').in('id', tids))); return C.addresses[id]; },
  myId() { return this.uid; },
  async reorderElements(aid, ids) { ids.forEach((id, i) => { if (C.elements[id]) C.elements[id].position = i + 1; }); for (const [i, id] of ids.entries()) this.ok(await this.sb.from('elements').update({ position: i + 1 }).eq('id', id)); },
  async listPending() { const d = this.ok(await this.sb.from('elements').select('*').eq('status', 'pending').order('created_at')); this.put('elements', d); const ids = [...new Set(d.map(e => e.address_id))].filter(i => !C.addresses[i]); if (ids.length) this.put('addresses', this.ok(await this.sb.from('addresses').select('*').in('id', ids))); return d; },
  async addElement(aid, el) { const pos = Math.max(0, ...elsOf(aid).map(x => x.position || 0)) + 1; const row = { owner: this.uid, address_id: aid, type: el.type, tag: el.tag || 'Autre', body: el.body || null, transcript: el.transcript || null, media: el.media || null, author: el.author || null, pinned: !!el.pinned, status: 'ok', position: pos, created_by: this.uid }; if (row.pinned) await this.sb.from('elements').update({ pinned: false }).eq('address_id', aid); const d = this.ok(await this.sb.from('elements').insert(row).select().single()); if (row.pinned) elsOf(aid).forEach(x => { x.pinned = false; }); this.put('elements', d); return d; },
  async updateElement(id, patch) { if (patch.pinned) { const aid = C.elements[id].address_id; await this.sb.from('elements').update({ pinned: false }).eq('address_id', aid); elsOf(aid).forEach(x => { x.pinned = false; }); } this.put('elements', this.ok(await this.sb.from('elements').update(patch).eq('id', id).select().single())); },
  async deleteElement(id) { this.ok(await this.sb.from('elements').delete().eq('id', id)); delete C.elements[id]; },
  async vote(id, du, dd) { const e = C.elements[id]; this.put('elements', this.ok(await this.sb.from('elements').update({ up: Math.max(0, (e.up || 0) + du), down: Math.max(0, (e.down || 0) + dd) }).eq('id', id).select().single())); },
  async listDrivers() { const d = this.ok(await this.sb.from('drivers').select('*').order('name')); C.drivers = {}; this.put('drivers', d); return d; },
  async saveDriver(d) { const row = { name: d.name, phone: d.phone || null, vehicle: d.vehicle || null, capacity_kg: d.capacity_kg ?? null, skills: d.skills || [], active: d.active !== false }; const r = d.id ? await this.sb.from('drivers').update(row).eq('id', d.id).select().single() : await this.sb.from('drivers').insert({ ...row, owner: this.uid }).select().single(); const x = this.ok(r); this.put('drivers', x); return x; },
  async deleteDriver(id) { this.ok(await this.sb.from('drivers').delete().eq('id', id)); delete C.drivers[id]; },
  // driver
  async ensureDriverSession() { const s = await this.session(); if (!s) throw new Error('need_login'); return true; },
  async joinTour(code, name) { await this.ensureDriverSession(); const r = await this.sb.rpc('join_tour', { p_code: normCode(code), p_name: name || '' }); if (r.error) throw new Error(/code_inconnu/.test(r.error.message) ? 'code_inconnu' : r.error.message); addJoined(r.data); return r.data; },
  async driverTours() {
    await this.ensureDriverSession();
    const m = this.ok(await this.sb.from('tour_members').select('tour_id').eq('user_id', this.uid)); const ids = [...new Set([...m.map(x => x.tour_id), ...getJoined()])]; if (!ids.length) return [];
    const d = this.ok(await this.sb.from('tours').select('*').in('id', ids).order('day', { ascending: false })); this.put('tours', d);
    try { localStorage.setItem(joinedKey, JSON.stringify(d.map(t => t.id))); } catch (e) {}
    return d;
  },
  async loadDriverTour(id) { await this.ensureDriverSession(); return this.loadTour(id); },
  async driverStart(tid, name) { this.ok(await this.sb.rpc('driver_start', { p_tour: tid, p_name: name || '' })); await this.loadTour(tid); },
  async driverUpdateStop(id, patch) { this.ok(await this.sb.rpc('driver_update_stop', { p_stop: id, p: patch })); Object.assign(C.stops[id], patch); },
  async driverAddElement(aid, stopId, el) { const id = this.ok(await this.sb.rpc('driver_add_element', { p_address: aid, p_stop: stopId || null, p: el })); const e = Object.assign({ id, address_id: aid, up: 0, down: 0, pinned: false, created_at: nowIso(), status: 'pending', created_by: this.uid, position: 999 }, el); this.put('elements', e); if (stopId && C.stops[stopId]) C.stops[stopId].fiche_added = (C.stops[stopId].fiche_added || 0) + 1; return e; },
  async driverVote(id, du, dd) { this.ok(await this.sb.rpc('driver_vote', { p_element: id, d_up: du, d_down: dd })); const e = C.elements[id]; e.up = Math.max(0, (e.up || 0) + du); e.down = Math.max(0, (e.down || 0) + dd); },
  async driverFinish(tid) { const r = await this.sb.rpc('driver_finish', { p_tour: tid }); if (r.error) throw new Error(/arrets_restants/.test(r.error.message) ? 'arrets_restants' : r.error.message); await this.loadTour(tid); },
  async ping(tid, p) { await this.sb.rpc('driver_ping', { p_tour: tid, p_lat: p.lat, p_lng: p.lng, p_acc: p.acc || 0 }); },
  // media: private bucket, signed links
  async upload(blob, ext, owner) { const path = `${owner || this.uid}/${newId()}.${ext}`; this.ok(await this.sb.storage.from('media').upload(path, blob, { contentType: (blob.type || '').split(';')[0] || undefined, upsert: false, cacheControl: '3600' })); urlCache.set(path, URL.createObjectURL(blob)); return path; },
  async mediaUrl(path) {
    if (!path) return ''; if (path.startsWith('data:')) return path;
    const c = urlCache.get(path); if (c && (typeof c === 'string' || c.exp > Date.now())) return typeof c === 'string' ? c : c.url;
    const r = await this.sb.storage.from('media').createSignedUrl(path, 3600); if (r.error) return '';
    urlCache.set(path, { url: r.data.signedUrl, exp: Date.now() + 3500e3 }); return r.data.signedUrl;
  },
  async mediaBlob(path) { if (!path) return null; const u = await this.mediaUrl(path); if (!u) return null; try { const r = await fetch(u); return r.ok ? r.blob() : null; } catch (e) { return null; } },
  subscribe(tid) {
    if (this.channels[tid]) return () => {};
    const apply = (table) => async payload => {
      if (payload.eventType === 'DELETE') { if (payload.old && payload.old.id) delete C[table][payload.old.id]; }
      else { const row = payload.new; if (table === 'elements' && !C.addresses[row.address_id]) return; C[table][row.id] = Object.assign(C[table][row.id] || {}, row); if (table === 'stops' && !C.addresses[row.address_id]) await this.fetchAddresses([row.address_id]); }
      emitChange();
    };
    const ch = this.sb.channel('tour-' + tid)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stops', filter: `tour_id=eq.${tid}` }, apply('stops'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tours', filter: `id=eq.${tid}` }, apply('tours'))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'elements' }, apply('elements'))
      .subscribe();
    this.channels[tid] = ch;
    return () => { this.sb.removeChannel(ch); delete this.channels[tid]; };
  },
};
let Api = LocalApi;
async function hydrate(root = document) {
  for (const el of $$('[data-media]', root)) { if (el.dataset.done) continue; el.dataset.done = 1; const u = await Api.mediaUrl(el.dataset.media); if (u) el.src = u; }
}
