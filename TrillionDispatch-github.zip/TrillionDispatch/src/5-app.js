/* ---------- UI state, routing, shell ---------- */
const ls = { get(k, d = null) { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch (e) { return d; } }, set(k, v) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} } };
const UI = { role: ls.get('dm-role'), route: { name: 'role' }, stack: [], pos: null, q: '', tourId: ls.get('dm-tour'), name: ls.get('dm-name', ''), session: null, orderMode: false, loading: false, pendingCode: '' };
const ACCENTS = { bleu: ['Bleu', '#1747C9'], rouge: ['Rouge', '#C2183A'], or: ['Or', '#C9961A'], vert: ['Vert', '#0C7350'] };
function applyAccent(k) {
  if (!ACCENTS[k]) k = 'bleu';
  if (k === 'bleu') document.documentElement.removeAttribute('data-accent'); else document.documentElement.setAttribute('data-accent', k);
  const m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || ACCENTS[k][1]);
  return k;
}
applyAccent(ls.get('dm-accent', 'bleu'));
function themeCard() {
  const cur = ls.get('dm-accent', 'bleu');
  return `<section class="card"><span class="eyebrow">Couleur de l'appli</span><div class="swatches" role="group" aria-label="Couleur de l'appli">${Object.entries(ACCENTS).map(([k, [n, c]]) => `<button class="swatch" data-act="set-accent" data-id="${k}" aria-pressed="${cur === k}"><i style="background:${c}"></i>${n}</button>`).join('')}</div></section>`;
}
const myVotes = (() => { try { return JSON.parse(ls.get('dm-votes', '{}')); } catch (e) { return {}; } })();
const saveVotes = () => ls.set('dm-votes', JSON.stringify(myVotes));
let unsub = null;

const TABS = {
  dispatcher: [['dtours', 'Tournées', ICON.board], ['dcarnet', 'Carnet', ICON.list], ['ddrivers', 'Livreurs', ICON.users]],
  driver: [['tour', 'Tournée', ICON.truck], ['carnet', 'Carnet', ICON.list], ['mytours', 'Mes tournées', ICON.stack]],
};
const TAB_OF = { dtours: 'dtours', dtour: 'dtours', dstop: 'dtours', dpending: 'dcarnet', report: null, dsettings: 'dtours', admin: null, dcarnet: 'dcarnet', daddress: 'dcarnet', ddrivers: 'ddrivers', tour: 'tour', stop: 'tour', close: 'tour', settings: 'tour', carnet: 'carnet', address: 'carnet', mytours: 'mytours', join: 'mytours' };

function go(name, params = {}, push = true) { if (push) UI.stack.push(UI.route); UI.route = { name, ...params }; UI.orderMode = false; render(); $('#main').scrollTop = 0; }
function back() { UI.route = UI.stack.pop() || { name: UI.role === 'dispatcher' ? 'dtours' : 'tour' }; UI.orderMode = false; render(); }
function resetTo(name, params = {}) { UI.stack = []; UI.route = { name, ...params }; UI.orderMode = false; render(); $('#main').scrollTop = 0; }

function render() {
  const r = UI.route; const view = VIEWS[r.name] || VIEWS.role; let v;
  try { v = view(r); } catch (e) { console.error(e); v = { title: 'Erreur', html: `<div class="empty"><b>Cet écran n'a pas pu s'afficher.</b><span>${esc(e.message)}</span></div>` }; }
  const tb = $('#topbar');
  tb.hidden = !!v.noTop;
  tb.innerHTML = UI.stack.length && v.back !== false
    ? `<button class="iconbtn" data-act="back" aria-label="Retour">${ICON.back}</button><h1>${esc(v.title)}</h1>${v.tool || ''}`
    : `<div class="brand"><span class="brand-mark" aria-hidden="true">TD</span></div><h1>${esc(v.title)}</h1>${v.tool || ''}`;
  $('#main').innerHTML = v.raw ? v.html : `<div class="view">${v.html}</div>`;
  const ab = $('#actionbar');
  if (v.action) { ab.innerHTML = v.action; ab.className = 'actionbar' + (v.actionOne ? ' one' : ''); ab.hidden = false; } else { ab.hidden = true; ab.innerHTML = ''; }
  const tabs = $('#tabs'), list = UI.role && !v.noTabs ? TABS[UI.role] : null;
  if (list) {
    tabs.hidden = false; tabs.className = 'tabs';
    tabs.innerHTML = list.map(([to, label, ic]) => `<button class="tab" data-act="tab" data-to="${to}" ${TAB_OF[r.name] === to ? 'aria-current="page"' : ''}>${ic}${label}</button>`).join('');
  } else tabs.hidden = true;
  hydrate($('#main')); hydrate(ab);
  v.mount && v.mount();
}
listeners.add(() => { const ae = document.activeElement; if ($('#overlay').hidden && !(ae && /INPUT|TEXTAREA|SELECT/.test(ae.tagName))) render(); });

/* ---------- shared fragments ---------- */
const street = a => esc(String(a.label || '').split(',')[0]);
const pcCity = a => esc([a.pc, a.city].filter(Boolean).join(' '));
const badgeCls = s => s.status === 'done' ? 'ok' : s.status === 'failed' ? 'bad' : '';
function statusChip(s, eta) {
  if (s.status === 'done') return `<span class="chip ok">Livré ${fmtTime(s.done_at)}</span>`;
  if (s.status === 'failed') return `<span class="chip bad">Échec · ${esc(s.fail_reason)}</span>`;
  let h = '';
  if (eta) h += `<span class="chip num">Vers ${fromMin(eta.eta)}</span>`;
  const w = winText(s); if (w) h += `<span class="chip ${eta && eta.late > 0.5 ? 'late' : ''} num">${eta && eta.late > 0.5 ? 'Retard · ' : ''}${esc(w)}</span>`;
  return h;
}
function ficheChips(a) {
  const fc = ficheCount(a.id); let h = '';
  if (fc.all) h += `<span class="chip fiche">Fiche · ${fc.all}</span>`;
  if (a.visits) h += `<span class="chip">Déjà venu ×${a.visits}</span>`;
  if (a.id && !hasXY(a)) h += `<span class="chip warn">Position inconnue</span>`;
  return h;
}
function progressBar(tid) {
  const k = tourCounts(tid), n = k.n || 1;
  return `<div class="progress" role="img" aria-label="${k.done} livrés, ${k.failed} échecs sur ${k.n}"><i class="p-ok" style="width:${k.done / n * 100}%"></i><i class="p-bad" style="width:${k.failed / n * 100}%"></i></div>`;
}
function mapSvg(t) {
  const W = 340, H = 210, pad = 24, ss = stopsOf(t.id);
  const stopsXY = ss.filter(s => hasXY(A(s)));
  const pts = [t.depot, ...stopsXY.map(A)].filter(hasXY); const me = UI.role === 'driver' ? UI.pos : t.last_pos; if (hasXY(me)) pts.push(me);
  if (pts.length < 2) return '<div class="empty">Ajoutez des arrêts localisés pour voir le plan.</div>';
  const lat0 = pts.reduce((m, p) => m + p.lat, 0) / pts.length, kx = Math.cos(lat0 * Math.PI / 180);
  const X = p => p.lng * kx, Yv = p => -p.lat; const xs = pts.map(X), ys = pts.map(Yv);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const sc = Math.min((W - 2 * pad) / ((maxX - minX) || 1e-6), (H - 2 * pad) / ((maxY - minY) || 1e-6));
  const ox = (W - (maxX - minX) * sc) / 2, oy = (H - (maxY - minY) * sc) / 2;
  const P = p => [(X(p) - minX) * sc + ox, (Yv(p) - minY) * sc + oy].map(v => +v.toFixed(1));
  let grid = ''; for (let x = 20; x < W; x += 40) grid += `<path class="grid" d="M${x} 0V${H}"/>`; for (let y = 15; y < H; y += 40) grid += `<path class="grid" d="M0 ${y}H${W}"/>`;
  const chainPts = [t.depot, ...stopsXY.map(A)].filter(hasXY).map(P);
  const route = `<polyline class="route" points="${chainPts.map(p => p.join(',')).join(' ')}"/>`;
  const d0 = hasXY(t.depot) ? P(t.depot) : null, last = chainPts[chainPts.length - 1];
  const ret = d0 && t.return_to_depot !== false ? `<path class="route-back" d="M${last.join(' ')}L${d0.join(' ')}"/>` : '';
  const dots = stopsXY.map(s => { const [x, y] = P(A(s)); return `<circle class="dot ${badgeCls(s)}" cx="${x}" cy="${y}" r="11"/><text x="${x}" y="${(y + 4.2).toFixed(1)}" text-anchor="middle">${ss.indexOf(s) + 1}</text>`; }).join('');
  const depot = d0 ? `<rect class="depot" x="${d0[0] - 10}" y="${d0[1] - 10}" width="20" height="20" rx="3"/><text class="depot-t" x="${d0[0]}" y="${(d0[1] + 4.2).toFixed(1)}" text-anchor="middle">D</text>` : '';
  const meDot = hasXY(me) ? (() => { const [x, y] = P(me); return `<circle class="me" cx="${x}" cy="${y}" r="7"/>`; })() : '';
  return `<svg class="map" viewBox="0 0 ${W} ${H}" role="img" aria-label="Plan schématique de la tournée">${grid}${ret}${route}${depot}${dots}${meDot}</svg>`;
}
/* real map on the hosted version (OpenStreetMap through Leaflet), schematic plan otherwise */
let leafletReady = null;
function loadLeaflet() {
  if (IN_CLAUDE) return Promise.reject(new Error('preview'));
  if (!leafletReady) leafletReady = new Promise((res, rej) => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = ASSETS.leafletCss; document.head.appendChild(l); loadScript(ASSETS.leafletJs).then(res, rej); });
  return leafletReady;
}
function mapBlock(t) { return `<figure class="card" style="margin:0;padding:10px"><div class="mapbox" id="mapbox" data-tour="${t.id}">${mapSvg(t)}</div><figcaption class="small muted" style="padding:0 4px">${IN_CLAUDE ? 'Plan schématique. La vraie carte s’affiche sur la version hébergée.' : 'Carte © contributeurs OpenStreetMap. La navigation se fait dans Waze ou Google Maps.'}</figcaption></figure>`; }
async function mountMap() {
  const box = $('#mapbox'); if (!box) return; const t = C.tours[box.dataset.tour]; if (!t) return;
  try { await loadLeaflet(); } catch (e) { return; }
  if (!document.body.contains(box)) return;
  const L = window.L; box.innerHTML = ''; box.style.height = '280px';
  const m = L.map(box, { zoomControl: true, attributionControl: true });
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(m);
  const ss = stopsOf(t.id), pts = [];
  const icon = (txt, cls) => L.divIcon({ className: '', html: `<div class="badge ${cls}" style="width:30px;height:30px;font-size:16px">${txt}</div>`, iconSize: [30, 30], iconAnchor: [15, 15] });
  if (hasXY(t.depot)) { L.marker([t.depot.lat, t.depot.lng], { icon: L.divIcon({ className: '', html: '<div class="badge" style="width:30px;height:30px;font-size:15px;background:#111821">D</div>', iconSize: [30, 30], iconAnchor: [15, 15] }) }).addTo(m); pts.push([t.depot.lat, t.depot.lng]); }
  ss.forEach((s, i) => { const a = A(s); if (!hasXY(a)) return; pts.push([a.lat, a.lng]); L.marker([a.lat, a.lng], { icon: icon(i + 1, badgeCls(s)) }).addTo(m).bindPopup(`<b>${i + 1}. ${street(a)}</b><br>${esc(s.client || '')}`); });
  if (pts.length > 1) L.polyline(pts, { color: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#1747C9', weight: 4, opacity: .8 }).addTo(m);
  const me = UI.role === 'driver' ? UI.pos : t.last_pos;
  if (hasXY(me)) { L.circleMarker([me.lat, me.lng], { radius: 9, color: '#111', weight: 2, fillColor: '#FFC21A', fillOpacity: 1 }).addTo(m); pts.push([me.lat, me.lng]); }
  if (pts.length) m.fitBounds(pts, { padding: [24, 24], maxZoom: 15 }); else m.setView([50.85, 4.35], 12);
}
function navLinks(a) {
  const q = hasXY(a) ? `${a.lat},${a.lng}` : a.label;
  const gm = 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=' + encodeURIComponent(q);
  const wz = hasXY(a) ? `https://waze.com/ul?ll=${a.lat},${a.lng}&navigate=yes` : 'https://waze.com/ul?q=' + encodeURIComponent(a.label) + '&navigate=yes';
  return `<div class="btnrow"><a class="btn" href="${wz}" target="_blank" rel="noopener">${ICON.nav} Waze</a><a class="btn" href="${gm}" target="_blank" rel="noopener">${ICON.nav} Google Maps</a></div>`;
}
function briefBox(a, s) {
  const sum = summary(a.id); const near = !sum && nearbyFiche(a);
  if (!sum && !a.visits && !near && !(s && s.driver_note)) return '';
  const head = a.visits ? `Déjà livré ici ${a.visits} fois` : 'Fiche terrain';
  let body = '';
  if (s && s.driver_note) body += `<p><b>Consigne du dispatcher :</b> ${esc(s.driver_note)}</p>`;
  body += sum ? `<p class="brief-sum">${esc(sum)}</p>`
    : near ? `<p>Même immeuble que <b>${street(near)}</b>, à quelques mètres. Sa fiche peut servir.</p><div><button class="btn" data-act="open-address" data-id="${near.id}">Voir sa fiche</button></div>`
    : `<p>Aucune note laissée sur cette adresse.</p>`;
  const listen = s ? `<div><button class="btn" data-act="speak-brief" data-id="${s.id}">${ICON.speaker} Écouter le briefing</button></div>` : '';
  return `<div class="brief"><div class="stripe" aria-hidden="true"></div><div class="brief-body"><span class="eyebrow">${head}</span>${body}${listen}</div></div>`;
}
function elBody(e) {
  if (e.type === 'photo') return `<button class="photo" data-act="view-media" data-path="${esc(e.media)}" data-cap="${esc(e.tag + (e.body ? ' · ' + e.body : ''))}"><img alt="${esc(e.body || 'Photo de la fiche')}" ${e.media && e.media.startsWith('data:') ? `src="${e.media}"` : `data-media="${esc(e.media)}"`}>${e.body ? `<span class="cap">${esc(e.body)}</span>` : ''}</button>`;
  if (e.type === 'voice') return `<div class="voice">${e.media ? `<audio controls preload="metadata" data-media="${esc(e.media)}"></audio>` : `<div><button class="btn" data-act="speak-el" data-id="${e.id}">${ICON.speaker} Écouter (voix de synthèse)</button></div>`}${e.transcript ? `<p class="el-text">« ${esc(e.transcript)} »</p>` : '<p class="hint">Pas de transcription.</p>'}</div>`;
  return `<p class="el-text ${e.pinned ? 'pinned' : ''}">${esc(e.body)}</p>`;
}
function elHtml(a, e, label, tools = '') {
  const stale = daysOld(e.created_at) > 365, wrong = elScore(e) <= -2, mv = myVotes[e.id], pending = !isOk(e), D = UI.role === 'dispatcher';
  let meta = label ? `<span class="chip ${pending ? 'warn' : e.pinned ? 'ok' : 'step'}">${label}</span>` : '';
  meta += `<span class="chip">${esc(e.tag)}</span>`;
  if (stale && !pending) meta += `<span class="chip warn">À vérifier</span>`;
  if (wrong) meta += `<span class="chip bad">Jugé faux</span>`;
  else if (D && e.down) meta += `<span class="chip bad">Signalé faux ×${e.down}</span>`;
  meta += `<span>${esc(e.author || '')} · ${ago(e.created_at)}${e.sample ? ' · exemple' : ''}</span>`;
  if (!D && !pending) meta += `<span class="spacer"></span><span class="votes"><button class="vote" data-act="vote" data-dir="up" data-id="${e.id}" aria-label="Info juste" aria-pressed="${mv === 'up'}">${ICON.up}${e.up || 0}</button><button class="vote" data-act="vote" data-dir="down" data-id="${e.id}" aria-label="Info fausse" aria-pressed="${mv === 'down'}">${ICON.down}${e.down || 0}</button></span>`;
  return `<div class="el ${wrong ? 'stale' : ''}"><div class="el-meta">${meta}</div>${elBody(e)}${tools}</div>`;
}
function dTools(e, i, n) {
  if (!isOk(e)) return `<div class="eltools"><button class="btn ok" data-act="approve-el" data-id="${e.id}">Valider</button><button class="btn" data-act="edit-el" data-id="${e.id}">${ICON.edit} Modifier</button><button class="btn bad" data-act="reject-el" data-id="${e.id}">Refuser</button></div>`;
  return `<div class="eltools">${e.pinned ? '' : `<button class="btn" data-act="el-up" data-id="${e.id}" aria-label="Monter" ${i === 0 ? 'disabled' : ''}>${ICON.up}</button><button class="btn" data-act="el-down" data-id="${e.id}" aria-label="Descendre" ${i === n - 1 ? 'disabled' : ''}>${ICON.down}</button>`}<button class="btn" data-act="edit-el" data-id="${e.id}">${ICON.edit} Modifier</button></div>`;
}
function ficheBlock(a, stopId = '') {
  const D = UI.role === 'dispatcher';
  const ok = elsOf(a.id).filter(isOk).sort(byStep), pins = ok.filter(e => e.pinned), steps = ok.filter(e => !e.pinned);
  const pend = pendingEls(a.id).filter(e => D || e.created_by === Api.myId());
  const fc = ficheCount(a.id);
  const counts = [fc.photo && `${fc.photo} photo${fc.photo > 1 ? 's' : ''}`, fc.voice && `${fc.voice} vocal${fc.voice > 1 ? 's' : ''}`, fc.text && `${fc.text} note${fc.text > 1 ? 's' : ''}`].filter(Boolean).join(' · ');
  const add = D
    ? `<div class="add-row four"><button class="btn" data-act="add-photo" data-id="${a.id}" data-stop="${stopId}">${ICON.camera}Photo</button><button class="btn" data-act="add-gallery" data-id="${a.id}" data-stop="${stopId}">${ICON.upload}Galerie</button><button class="btn" data-act="add-voice" data-id="${a.id}" data-stop="${stopId}">${ICON.mic}Vocal</button><button class="btn" data-act="add-text" data-id="${a.id}" data-stop="${stopId}">${ICON.note}Note</button></div>`
    : `<div class="add-row"><button class="btn" data-act="add-photo" data-id="${a.id}" data-stop="${stopId}">${ICON.camera}Photo</button><button class="btn" data-act="add-voice" data-id="${a.id}" data-stop="${stopId}">${ICON.mic}Vocal</button><button class="btn" data-act="add-text" data-id="${a.id}" data-stop="${stopId}">${ICON.note}Note</button></div><p class="hint">Vos ajouts partent au dispatcher, qui les valide avant que les autres livreurs les voient.</p>`;
  let body = '';
  if (D && pend.length) body += `<div class="pendbox"><span class="eyebrow">À valider · proposé par les livreurs</span>${pend.map(e => elHtml(a, e, 'À valider', dTools(e))).join('')}</div>`;
  if (pins.length) body += pins.map(e => elHtml(a, e, 'Consigne', D ? dTools(e, 0, 1) : '')).join('');
  if (steps.length) body += steps.map((e, i) => elHtml(a, e, `Étape ${i + 1}`, D ? dTools(e, i, steps.length) : '')).join('');
  if (!D && pend.length) body += pend.map(e => elHtml(a, e, 'En attente de validation')).join('');
  if (!ok.length && !(D && pend.length) && !(!D && pend.length)) body = D
    ? `<div class="empty"><b>Fiche vide.</b><span>Montrez le chemin en étapes : une photo pour aller à l'arrière, une photo de la boîte, dix secondes de voix. Le livreur les verra dans l'ordre, et la fiche revient toute seule à chaque livraison à cette adresse.</span></div>`
    : `<div class="empty"><b>Pas encore de fiche pour cette adresse.</b><span>Si vous trouvez l'accès, une photo ou dix secondes de voix aideront le prochain livreur.</span></div>`;
  return `<section class="card" aria-label="Fiche terrain">
    <div class="fiche-head"><h3 class="h3">Fiche terrain</h3><span class="small muted">${counts || 'vide'}</span></div>
    ${D ? '<p class="small muted">Rattachée à l’adresse : elle revient automatiquement dans chaque tournée qui passe ici.</p>' : ''}
    ${add}
    <div class="els">${body}</div>
  </section>`;
}
function proofThumbs(s) {
  const p = s.proof; if (!p) return '';
  const ph = (p.photos || []).map((path, i) => `<button class="photo" data-act="view-media" data-path="${esc(path)}" data-cap="${esc('Preuve ' + (i + 1) + ' · ' + A(s).label.split(',')[0])}"><img alt="Preuve ${i + 1}" data-media="${esc(path)}"></button>`).join('');
  const sig = p.signature ? `<button class="photo" data-act="view-media" data-path="${esc(p.signature)}" data-cap="Signature"><img alt="Signature" data-media="${esc(p.signature)}" style="background:#fff;object-fit:contain"></button>` : '';
  return ph || sig ? `<div class="proofs">${ph}${sig}</div>` : '';
}
function proofLine(s) {
  const p = s.proof || {};
  if (s.status === 'done') return `<p><b>Livré à ${fmtTime(s.done_at)}</b>${p.place ? ' · ' + esc(p.place) : ''}${p.recipient ? ' · reçu par ' + esc(p.recipient) : ''}</p>${p.gps ? `<p class="small muted num">GPS ${(+p.gps.lat).toFixed(5)}, ${(+p.gps.lng).toFixed(5)} (± ${p.gps.acc} m)</p>` : '<p class="small muted">Position non enregistrée</p>'}${p.note ? `<p class="small">${esc(p.note)}</p>` : ''}`;
  if (s.status === 'failed') return `<p><b>Échec à ${fmtTime(s.done_at)}</b> · ${esc(s.fail_reason)}${s.reschedule ? ' · à reprogrammer' : ''}</p>${p.note ? `<p class="small">${esc(p.note)}</p>` : ''}`;
  return '<p class="muted">Pas encore de statut.</p>';
}
function toursChip(t) { const c = { draft: '', published: 'warn', active: 'live', done: 'ok' }[t.status]; return t.is_template ? '<span class="chip prio">Modèle</span>' : `<span class="chip ${c}">${STATUS_LABEL[t.status]}</span>`; }

const VIEWS = {};
/* ---------- legal ---------- */
const legalLinks = () => `<p class="small muted legal-links"><button class="linkbtn" data-act="legal" data-doc="cgu">Conditions</button> · <button class="linkbtn" data-act="legal" data-doc="confidentialite">Confidentialité</button> · <button class="linkbtn" data-act="legal" data-doc="mentions">Mentions légales</button> · <button class="linkbtn" data-act="legal" data-doc="geolocalisation">Géolocalisation</button> · <button class="linkbtn" data-act="legal" data-doc="sous-traitance">Sous-traitance</button></p>`;
VIEWS.legal = r => { const d = LEGAL[r.doc] || LEGAL.cgu; return { title: d.title, noTabs: true, html: `<article class="card legal">${d.html}</article>${legalLinks()}` }; };
VIEWS.terms = () => ({
  title: 'Conditions', noTabs: true,
  html: `<section class="card"><span class="eyebrow">Avant de commencer</span><h2 class="h2">Conditions d'utilisation</h2>
    <p>Pour utiliser TrillionDispatch, acceptez les conditions générales et la politique de confidentialité${UI.role === 'driver' ? ', et prenez connaissance de la note sur la géolocalisation pendant les tournées' : ''}.</p>
    <div class="btnrow"><button class="btn" data-act="legal" data-doc="cgu">Lire les conditions</button><button class="btn" data-act="legal" data-doc="confidentialite">Lire la confidentialité</button></div>
    ${UI.role === 'driver' ? '<div class="btnrow"><button class="btn" data-act="legal" data-doc="geolocalisation">Lire la note géolocalisation</button></div>' : ''}
    <label class="switch" for="tAcc"><span>J'accepte les conditions générales et la politique de confidentialité, et je confirme agir à titre professionnel.</span><input type="checkbox" id="tAcc"></label>
    <div class="warnbox" id="tErr" hidden></div>
    <button class="btn big primary" data-act="accept-terms">Accepter et continuer</button>
    <button class="btn ghost" data-act="logout">Refuser et me déconnecter</button></section>`,
});

/* ---------- entry: role choice, driver code, dispatcher login ---------- */
VIEWS.role = () => ({
  title: 'TrillionDispatch', noTabs: true, noTop: true, raw: true,
  html: `${MODE === 'local' ? `<div class="demo-band">Mode démo : tout reste sur cet appareil${IN_CLAUDE ? ' (aperçu Claude)' : ''}.</div>` : ''}
  <div class="role-screen">
    <div class="role-hero"><span class="brand-mark" aria-hidden="true">TD</span><h1>TrillionDispatch</h1><p class="muted">Tournées de livraison et fiches terrain.</p></div>
    <button class="role-card hi" data-act="choose-role" data-role="driver"><span class="ico">${ICON.truck}</span><span><b>Livreur</b><span>J'ai un code ou un lien de tournée.</span></span></button>
    <button class="role-card" data-act="choose-role" data-role="dispatcher"><span class="ico">${ICON.board}</span><span><b>Dispatcher</b><span>Je crée, j'envoie et je suis les tournées.</span></span></button>
    ${MODE === 'local' ? '<p class="note">Démo : passez par Dispatcher pour créer ou modifier une tournée, puis par Livreur avec le code <b class="num">K7M-4Q2</b>. Vous pouvez changer de rôle dans les réglages.</p>' : ''}
    ${legalLinks()}
  </div>`,
});
VIEWS.join = () => {
  const code = UI.pendingCode || '';
  return {
    title: 'Ouvrir une tournée', noTabs: !getJoined().length,
    tool: `<button class="iconbtn" data-act="settings" aria-label="Réglages">${ICON.gear}</button>`,
    html: `<section class="card"><span class="eyebrow">Code de tournée</span>
      <p class="muted small">Le dispatcher vous l'envoie par WhatsApp ou SMS. Six caractères.</p>
      <div class="codebox"><input id="jCode" inputmode="text" autocomplete="one-time-code" autocapitalize="characters" maxlength="7" placeholder="K7M-4Q2" value="${esc(fmtCode(normCode(code)))}" aria-label="Code de tournée"></div>
      <div class="field"><label for="jName">Votre prénom</label><input class="input" id="jName" value="${esc(UI.name)}" autocomplete="given-name" placeholder="Ex. : Karim"></div>
      <div class="warnbox" id="jErr" hidden></div>
      <button class="btn big primary" data-act="join">Ouvrir la tournée</button></section>
      ${MODE === 'local' ? '<p class="note">Code de démonstration : <b class="num">K7M-4Q2</b>.</p>' : ''}`,
    mount() {
      const i = $('#jCode'); i.addEventListener('input', () => { const c = normCode(i.value).slice(0, 6); i.value = c.length > 3 ? fmtCode(c) : c; });
      if (!code) setTimeout(() => i.focus(), 80);
    },
  };
};
VIEWS.login = () => {
  const drv = UI.role === 'driver', code = UI.pendingCode;
  return {
    title: drv ? 'Livreur' : 'Dispatcher', noTabs: true,
    tool: `<button class="iconbtn" data-act="switch-role" aria-label="Changer de rôle">${ICON.logout}</button>`,
    html: `<section class="card"><span class="eyebrow">${drv ? 'Compte livreur' : 'Compte dispatcher'}</span>
      ${code ? `<p>Connectez-vous pour ouvrir la tournée <b class="num">${fmtCode(normCode(code))}</b>.</p>` : `<p class="muted small">${drv ? 'Votre compte garde vos tournées, vos livraisons et vos ajouts aux fiches, sur tous vos téléphones.' : 'Un seul compte pour créer les tournées, suivre les livreurs et gérer les fiches.'}</p>`}
      <button class="btn big primary" data-act="google">Continuer avec Google</button>
      <p class="hint">Avec Google, vous accepterez les conditions à la première connexion.</p>
      <div class="section-title"><span class="eyebrow">Ou avec un e-mail</span></div>
      <div class="field"><label for="lName">Prénom et nom</label><input class="input" id="lName" autocomplete="name" placeholder="Seulement pour créer un compte"></div>
      <div class="field"><label for="lEmail">E-mail</label><input class="input" id="lEmail" type="email" autocomplete="email" inputmode="email"></div>
      <div class="field"><label for="lPw">Mot de passe</label><input class="input" id="lPw" type="password" autocomplete="current-password" minlength="10"><span class="hint">10 caractères minimum pour un nouveau compte.</span></div>
      <label class="switch" for="lTerms"><span>J'accepte les <button class="linkbtn" data-act="legal" data-doc="cgu">conditions</button> et la <button class="linkbtn" data-act="legal" data-doc="confidentialite">politique de confidentialité</button>. Obligatoire pour créer un compte.</span><input type="checkbox" id="lTerms"></label>
      <div class="warnbox" id="lErr" hidden></div>
      <div class="btnrow"><button class="btn primary" data-act="login">Se connecter</button><button class="btn" data-act="signup">Créer un compte</button></div>
      <button class="btn ghost" data-act="forgot">Mot de passe oublié</button></section>${legalLinks()}`,
  };
};
