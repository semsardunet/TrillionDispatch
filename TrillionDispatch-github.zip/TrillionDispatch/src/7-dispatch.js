/* ---------- dispatcher screens ---------- */
const dTool = `<button class="iconbtn" data-act="dsettings" aria-label="Réglages">${ICON.gear}</button>`;
function tourRow(t) {
  const k = tourCounts(t.id), drv = t.driver_name || (t.driver_id && C.drivers[t.driver_id]?.name) || '';
  return `<button class="row" data-act="open-dtour" data-id="${t.id}"><div class="row-body"><span class="row-title">${esc(t.name)}</span>
    <span class="small muted">${t.is_template ? `Départ ${hm(t.start_time) || '—'}` : esc(fmtDay(t.day))}${drv ? ' · ' + esc(drv) : ''} · ${k.n} arrêt${k.n > 1 ? 's' : ''}${t.status !== 'draft' && !t.is_template ? ` · ${k.done} livrés` : ''}</span>
    <div class="chips">${toursChip(t)}${t.status !== 'draft' && !t.is_template ? `<span class="chip num">${fmtCode(t.code)}</span>` : ''}${t.status === 'active' && t.last_pos ? `<span class="chip">Position ${ago(t.last_pos.at)}</span>` : ''}</div></div>${ICON.chev}</button>`;
}
VIEWS.dtours = () => {
  const all = Object.values(C.tours), today = todayIso();
  const real = all.filter(t => !t.is_template);
  const sec = (title, list, empty) => list.length ? `<div class="section-title"><h3 class="h3">${title}</h3><span class="small muted">${list.length}</span></div><div class="list">${list.map(tourRow).join('')}</div>` : (empty ? `<div class="section-title"><h3 class="h3">${title}</h3></div><div class="empty">${empty}</div>` : '');
  const todayT = real.filter(t => t.day === today && t.status !== 'draft');
  const kToday = todayT.reduce((m, t) => { const k = tourCounts(t.id); m.n += k.n; m.done += k.done; m.failed += k.failed; return m; }, { n: 0, done: 0, failed: 0 });
  const html = `<section class="card"><span class="eyebrow">${esc(fmtDay(today))}</span><h2 class="h2">Tableau de bord</h2>
      <div class="kpis"><div class="stat"><b>${todayT.length}</b><span>tournées</span></div><div class="stat"><b>${kToday.n}</b><span>arrêts</span></div><div class="stat"><b>${kToday.done}</b><span>livrés</span></div><div class="stat"><b>${kToday.failed}</b><span>échecs</span></div></div></section>
    ${pendingCard()}
    <div class="fab-row">
      <button class="btn primary" data-act="new-tour">${ICON.plus}Nouvelle tournée</button>
      <button class="btn" data-act="new-from-template">${ICON.stack}Depuis un modèle</button>
      <button class="btn" data-act="new-scan">${ICON.camera}Photo d'un document</button>
      <button class="btn" data-act="new-import">${ICON.upload}Importer un fichier</button>
      <button class="btn" data-act="new-duplicate">${ICON.copy}Dupliquer une tournée</button>
    </div>
    ${sec("Aujourd'hui", todayT.sort((a, b) => a.name.localeCompare(b.name)), 'Aucune tournée envoyée pour aujourd’hui.')}
    ${sec('Brouillons', real.filter(t => t.status === 'draft').sort((a, b) => a.day.localeCompare(b.day)))}
    ${sec('À venir', real.filter(t => t.day > today && t.status !== 'draft').sort((a, b) => a.day.localeCompare(b.day)))}
    ${sec('En cours (autres jours)', real.filter(t => t.day < today && (t.status === 'active' || t.status === 'published')))}
    ${sec('Terminées', real.filter(t => t.status === 'done' && t.day !== today).sort((a, b) => b.day.localeCompare(a.day)).slice(0, 15))}
    ${sec('Modèles', all.filter(t => t.is_template), 'Enregistrez une tournée comme modèle pour la recréer en un geste.')}`;
  return { title: 'Tournées', tool: dTool, html };
};
VIEWS.dtour = r => {
  const t = C.tours[r.id]; if (!t) return { title: 'Tournée', html: '<div class="empty">Tournée introuvable.</div>' };
  const ss = stopsOf(t.id), k = tourCounts(t.id), pi = planInfo(t);
  const noXY = ss.filter(s => !hasXY(A(s))).length, cap = +t.capacity_kg || null;
  const drv = t.driver_name || (t.driver_id && C.drivers[t.driver_id]?.name) || '';
  let html = `<section class="card"><span class="eyebrow">${t.is_template ? 'Modèle de tournée' : esc(fmtDay(t.day))} · ${STATUS_LABEL[t.status]}</span>
    <h2 class="h2">${esc(t.name)}</h2>
    <p class="muted small">${drv ? 'Livreur : ' + esc(drv) : 'Pas de livreur attribué'} · départ ${hm(t.start_time) || '—'} de ${esc((t.depot?.label || 'dépôt').split(',')[0])}${t.return_to_depot !== false ? ', retour au dépôt' : ''}</p>
    ${t.status !== 'draft' && !t.is_template ? progressBar(t.id) : ''}
    <div class="kpis"><div class="stat"><b>${k.n}</b><span>arrêts</span></div><div class="stat"><b>${pi.km.toFixed(1)}</b><span>km</span></div><div class="stat"><b>${fmtDur(pi.durMin)}</b><span>${t.status === 'active' ? 'restant' : 'durée'}</span></div><div class="stat"><b>${Math.round(k.kg)}</b><span>${cap ? `/ ${cap} kg` : 'kg'}</span></div></div>
    ${pi.lateCount ? `<div class="warnbox">${pi.lateCount} arrêt${pi.lateCount > 1 ? 's' : ''} hors créneau avec l'ordre actuel. Essayez « Optimiser ».</div>` : ''}
    ${noXY ? `<div class="warnbox">${noXY} adresse${noXY > 1 ? 's' : ''} sans position : placées en fin de tournée. Ouvrez l'arrêt pour corriger.</div>` : ''}
    ${cap && k.kg > cap ? `<div class="warnbox">Charge ${Math.round(k.kg)} kg pour une capacité de ${cap} kg. Répartissez la tournée.</div>` : ''}
    <div class="btnrow"><button class="btn" data-act="add-stops" data-id="${t.id}">${ICON.plus} Ajouter</button><button class="btn" data-act="optimize" data-id="${t.id}">${ICON.flag} Optimiser</button></div>
    <div class="btnrow"><button class="btn" data-act="tour-settings" data-id="${t.id}">${ICON.edit} Réglages</button><button class="btn" data-act="tour-more" data-id="${t.id}">${ICON.list} Plus</button></div></section>`;
  if (t.status !== 'draft' && !t.is_template) {
    html += `<section class="card"><div class="section-title"><span class="eyebrow">Code du livreur</span>${t.status === 'active' ? '<span class="chip live">En cours</span>' : ''}</div>
      <div class="code-big">${fmtCode(t.code)}</div>
      <div class="btnrow"><button class="btn" data-act="share-code" data-id="${t.id}">${ICON.share} Envoyer au livreur</button></div>
      ${t.last_pos ? `<p class="small muted">Dernière position du livreur ${ago(t.last_pos.at)} (${fmtTime(t.last_pos.at)}).</p>` : t.status === 'active' ? '<p class="small muted">Position du livreur pas encore reçue.</p>' : '<p class="small muted">Le livreur n’a pas encore démarré.</p>'}
      ${t.status === 'done' ? `<div class="btnrow"><button class="btn primary" data-act="open-report" data-id="${t.id}">${ICON.file} Rapport et preuves</button></div>` : ''}</section>`;
  }
  if (ss.length) html += mapBlock(t);
  html += `<div class="section-title"><h3 class="h3">Arrêts</h3>${ss.length > 1 ? `<button class="btn ghost" data-act="order-mode">${UI.orderMode ? 'Terminer' : 'Réordonner'}</button>` : ''}</div>`;
  html += ss.length ? `<div class="stops">${ss.map((s, i) => { const a = A(s), eta = pi.etas[s.id];
    const chips = `${statusChip(s, eta)}${+s.priority ? '<span class="chip prio">Prioritaire</span>' : ''}${s.locked ? '<span class="chip lock">Position fixée</span>' : ''}${s.weight_kg ? `<span class="chip num">${esc(s.weight_kg)} kg</span>` : ''}${s.driver_note ? '<span class="chip prio">Consigne</span>' : ''}${ficheChips(a)}`;
    const tools = UI.orderMode ? `<div class="ordertools"><button data-act="move-up" data-id="${s.id}" aria-label="Monter" ${i === 0 ? 'disabled' : ''}>${ICON.up}</button><button data-act="move-down" data-id="${s.id}" aria-label="Descendre" ${i === ss.length - 1 ? 'disabled' : ''}>${ICON.down}</button></div>` : ICON.chev;
    return `<div class="stop editable"><div class="badge ${badgeCls(s)}">${i + 1}</div><button class="stop-body" style="border:0;background:none;padding:0;text-align:left" data-act="open-dstop" data-id="${s.id}"><span class="stop-addr">${street(a)}</span><span class="small muted">${pcCity(a)}${s.client ? ' · ' + esc(s.client) : ''}</span><span class="chips">${chips}</span></button>${tools}</div>`; }).join('')}</div>`
    : `<div class="empty"><b>Aucun arrêt.</b><span>Saisissez, collez une liste, importez un fichier Excel ou CSV, ou reprenez des adresses du carnet.</span><button class="btn primary" data-act="add-stops" data-id="${t.id}">${ICON.plus} Ajouter des arrêts</button></div>`;
  let action = null;
  if (t.is_template) action = `<button class="btn big primary" data-act="use-template" data-id="${t.id}">Créer une tournée avec ce modèle</button>`;
  else if (t.status === 'draft') action = `<button class="btn big primary" data-act="publish" data-id="${t.id}" ${ss.length ? '' : 'disabled'}>Envoyer au livreur</button>`;
  else if (t.status === 'done') action = `<button class="btn big primary" data-act="open-report" data-id="${t.id}">Rapport et preuves</button>`;
  return { title: t.is_template ? 'Modèle' : 'Tournée', html, action, actionOne: true, mount: mountMap };
};
VIEWS.dcarnet = () => {
  const q = UI.q.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const all = Object.values(C.addresses).filter(a => !q || (a.label + ' ' + a.key + ' ' + (a.client || '')).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(q));
  all.sort((x, y) => (ficheCount(y.id).all > 0) - (ficheCount(x.id).all > 0) || String(y.last_visit || '').localeCompare(String(x.last_visit || '')) || x.label.localeCompare(y.label));
  const n = Object.keys(C.addresses).length, withF = Object.values(C.addresses).filter(a => ficheCount(a.id).all).length;
  return { title: "Carnet d'adresses", tool: dTool, html: `${pendingCard()}<p class="note">${n} adresses, dont ${withF} avec une fiche. Une adresse déjà connue est reconnue à l'import, même écrite autrement, et sa fiche suit.</p>
    <label class="search">${ICON.search}<input id="q" type="search" placeholder="Rue, client, commune…" value="${esc(UI.q)}" aria-label="Rechercher une adresse"></label>
    <div class="list">${all.length ? all.slice(0, 300).map(a => addrRow(a)).join('') : '<div class="empty">Aucune adresse ne correspond.</div>'}</div>`, mount: bindSearch };
};
VIEWS.daddress = r => VIEWS.address(r);
VIEWS.ddrivers = () => {
  const ds = Object.values(C.drivers).sort((a, b) => a.name.localeCompare(b.name)), today = todayIso();
  return { title: 'Livreurs', tool: dTool, html: `<div class="btnrow"><button class="btn primary" data-act="edit-driver">${ICON.plus} Ajouter un livreur</button></div>
    ${ds.length ? `<div class="list">${ds.map(d => { const tt = Object.values(C.tours).filter(t => t.driver_id === d.id && t.day === today && !t.is_template);
      return `<button class="row" data-act="edit-driver" data-id="${d.id}"><div class="row-body"><span class="row-title">${esc(d.name)}</span><span class="small muted">${[d.vehicle, d.capacity_kg ? d.capacity_kg + ' kg' : '', d.phone].filter(Boolean).map(esc).join(' · ')}</span><div class="chips">${d.active === false ? '<span class="chip">Inactif</span>' : ''}${tt.map(t => `<span class="chip ${t.status === 'active' ? 'live' : ''}">${esc(t.name)} · ${STATUS_LABEL[t.status]}</span>`).join('')}</div></div>${ICON.chev}</button>`; }).join('')}</div>` : '<div class="empty">Ajoutez vos livreurs pour leur attribuer des tournées et leur envoyer le code en un geste.</div>'}
    <p class="note">Les livreurs n'ont pas de compte : chaque tournée a son code, que vous leur envoyez.</p>` };
};
VIEWS.dsettings = () => ({
  title: 'Réglages', html: settingsCommon(),
  mount: bindVoiceCard,
});

function pendingCard() {
  const n = Object.values(C.elements).filter(e => !isOk(e)).length; if (!n) return '';
  return `<button class="pending-card" data-act="go-pending"><span class="ico" style="width:44px;height:44px;border-radius:10px;display:grid;place-items:center;background:var(--hi);color:var(--hi-fg);flex:none">${ICON.note}</span><span style="flex:1;min-width:0"><b>${n} proposition${n > 1 ? 's' : ''} à valider</b><br><span class="small muted">Photos, vocaux ou notes envoyés par les livreurs depuis le terrain.</span></span>${ICON.chev}</button>`;
}
VIEWS.dstop = r => {
  const s = C.stops[r.id]; if (!s) return { title: 'Arrêt', html: '<div class="empty">Cet arrêt a été retiré.</div>' };
  const t = C.tours[s.tour_id], ss = stopsOf(t.id), i = ss.findIndex(x => x.id === s.id), a = A(s), eta = planInfo(t).etas[s.id];
  let html = `<div class="addr-hero"><div class="badge lg ${badgeCls(s)}">${i + 1}</div><div class="stop-body"><span class="eyebrow">${esc(t.name)} · arrêt ${i + 1} sur ${ss.length}</span><h2 class="h2">${street(a)}</h2><span class="muted">${pcCity(a)}</span><div class="chips">${statusChip(s, eta)}${+s.priority ? '<span class="chip prio">Prioritaire</span>' : ''}${s.locked ? '<span class="chip lock">Position fixée</span>' : ''}${!hasXY(a) ? '<span class="chip warn">Position inconnue</span>' : ''}</div></div></div>`;
  if (s.raw && a.label && s.raw.trim() !== a.label.trim()) html += `<p class="hint">Adresse reconnue dans le carnet. Saisie d'origine : « ${esc(s.raw)} ».</p>`;
  html += `<section class="card"><div class="section-title"><span class="eyebrow">Livraison</span></div><dl class="kv">
    <dt>Client</dt><dd>${esc(s.client || '—')}</dd>
    ${s.phone ? `<dt>Téléphone</dt><dd class="num">${esc(s.phone)}</dd>` : ''}
    <dt>Créneau</dt><dd class="num">${esc(winText(s) || 'libre')}${eta ? ` · arrivée prévue ${fromMin(eta.eta)}` : ''}</dd>
    <dt>Sur place</dt><dd>${esc(s.service_min ?? 4)} min</dd>
    ${s.weight_kg ? `<dt>Poids</dt><dd>${esc(s.weight_kg)} kg</dd>` : ''}
    ${s.ref ? `<dt>Référence</dt><dd class="num">${esc(s.ref)}</dd>` : ''}
    ${s.notes ? `<dt>Colis</dt><dd>${esc(s.notes)}</dd>` : ''}
    ${s.driver_note ? `<dt>Consigne du jour</dt><dd>${esc(s.driver_note)}</dd>` : ''}
  </dl><div class="btnrow"><button class="btn" data-act="edit-stop" data-id="${s.id}">${ICON.edit} Modifier la livraison</button></div></section>`;
  if (s.status !== 'todo') html += `<section class="card"><span class="eyebrow">${s.status === 'done' ? 'Preuve de livraison' : 'Échec'}</span>${proofLine(s)}${proofThumbs(s)}</section>`;
  html += ficheBlock(a, s.id);
  return { title: `Arrêt ${i + 1}`, html };
};
VIEWS.dpending = () => {
  const pend = Object.values(C.elements).filter(e => !isOk(e));
  const by = {}; pend.forEach(e => { (by[e.address_id] = by[e.address_id] || []).push(e); });
  const html = pend.length ? Object.entries(by).map(([aid, els]) => { const a = C.addresses[aid] || { id: aid, label: 'Adresse' };
    return `<section class="card"><div class="section-title"><div><h3 class="h3">${street(a)}</h3><span class="small muted">${pcCity(a)}</span></div><button class="btn ghost" data-act="open-address" data-id="${aid}">Voir la fiche</button></div>${summary(aid) ? `<p class="small muted">Fiche actuelle : ${esc(summary(aid))}</p>` : '<p class="small muted">Fiche actuelle vide.</p>'}${els.sort(byStep).map(e => elHtml(a, e, 'À valider', dTools(e))).join('')}</section>`; }).join('')
    : '<div class="empty"><b>Rien à valider.</b><span>Les photos, vocaux et notes proposés par les livreurs arrivent ici.</span></div>';
  return { title: 'À valider', html: `<p class="note">Ce que les livreurs ont proposé depuis le terrain. Validez pour l'ajouter à la fiche, modifiez avant si besoin, ou refusez.</p>${html}` };
};
