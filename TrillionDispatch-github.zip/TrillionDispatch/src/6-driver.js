/* ---------- driver screens ---------- */
const curTour = () => C.tours[UI.tourId] || null;
async function openDriverTour(id, push = false) {
  UI.tourId = id; ls.set('dm-tour', id);
  try { await Api.loadDriverTour(id); } catch (e) { toast('Tournée introuvable ou accès retiré.'); resetTo('join'); return; }
  if (unsub) unsub(); unsub = Api.subscribe(id);
  const t = C.tours[id]; if (t && t.status === 'active') { startGeo(onDriverPos); keepAwake(true); }
  push ? go('tour', {}) : resetTo('tour');
}
let lastPing = 0;
function onDriverPos(p) {
  const t = curTour(); if (!t || t.status !== 'active') return;
  if (Date.now() - lastPing > 60000) { lastPing = Date.now(); Api.ping(t.id, p).catch(() => {}); }
  const next = stopsOf(t.id).find(s => s.status === 'todo'); if (!next) return;
  const a = A(next); if (!hasXY(a) || UI.briefed?.[next.id]) return;
  if (dist(p, a) < 150) { UI.briefed = { ...(UI.briefed || {}), [next.id]: 1 }; if (!next.arrived_at) Api.driverUpdateStop(next.id, { arrived_at: nowIso() }).catch(() => {}); showBrief(next); }
}
VIEWS.tour = () => {
  const t = curTour();
  const tool = `<button class="iconbtn" data-act="settings" aria-label="Réglages">${ICON.gear}</button>`;
  if (!t) return { title: 'Tournée', tool, html: `<div class="empty"><b>Aucune tournée ouverte.</b><span>Entrez le code envoyé par le dispatcher.</span><button class="btn primary" data-act="go-join">${ICON.key} Entrer un code</button></div>` };
  const ss = stopsOf(t.id), k = tourCounts(t.id), next = ss.find(s => s.status === 'todo'), pi = planInfo(t);
  let html = `<section class="card"><span class="eyebrow">${esc(fmtDay(t.day))} · ${esc(t.name)}</span>
    <h2 class="h2">Tournée de ${esc(t.driver_name || UI.name || 'livreur')}</h2>${progressBar(t.id)}
    <div class="stats"><div class="stat"><b>${k.done}/${k.n}</b><span>livrés</span></div><div class="stat"><b>${pi.km.toFixed(1)}</b><span>km estimés</span></div><div class="stat"><b>${fmtDur(pi.durMin)}</b><span>${t.status === 'active' ? 'restant' : 'durée estimée'}</span></div></div>
    ${t.status === 'published' ? `<p class="small muted">Départ prévu à ${hm(t.start_time) || '—'} depuis ${esc(t.depot?.label || 'le dépôt')}. L'ordre des arrêts est fixé par le dispatcher.</p>` : ''}
  </section>`;
  if (t.status === 'active' && next) {
    const a = A(next);
    html += `<section class="card" aria-label="Prochain arrêt"><span class="eyebrow">Prochain arrêt</span>
      <div class="addr-hero"><div class="badge lg">${ss.indexOf(next) + 1}</div><div class="stop-body"><h3 class="h2" style="font-size:24px">${street(a)}</h3><span class="muted">${pcCity(a)} · ${esc(next.client)}</span><div class="chips">${statusChip(next, pi.etas[next.id])}</div></div></div>
      ${briefBox(a, next)}
      <div class="btnrow"><button class="btn primary" data-act="open-stop" data-id="${next.id}">Ouvrir l'arrêt</button><button class="btn" data-act="simulate" data-id="${next.id}">Simuler l'arrivée</button></div>${navLinks(a)}</section>`;
  }
  if (t.status === 'active' && !next) html += `<section class="card"><span class="eyebrow">Tous les arrêts ont un statut</span><p>${k.done} livrés, ${k.failed} en échec. Vous pouvez clôturer.</p></section>`;
  if (t.status === 'done') html += `<section class="card"><span class="eyebrow">Tournée terminée à ${fmtTime(t.ended_at)}</span><div class="btnrow"><button class="btn primary" data-act="open-report" data-id="${t.id}">${ICON.file} Voir le rapport</button></div></section>`;
  html += ss.length ? mapBlock(t) : '';
  html += ss.length ? `<div class="stops">${ss.map((s, i) => { const a = A(s);
    return `<button class="stop ${s === next && t.status === 'active' ? 'next' : ''}" data-act="open-stop" data-id="${s.id}"><div class="badge ${badgeCls(s)}">${i + 1}</div><div class="stop-body"><div class="stop-addr">${street(a)}</div><div class="small muted">${pcCity(a)}${s.client ? ' · ' + esc(s.client) : ''}</div><div class="chips">${statusChip(s, pi.etas[s.id])}${s.driver_note ? '<span class="chip prio">Consigne</span>' : ''}${ficheChips(a)}</div></div>${ICON.chev}</button>`; }).join('')}</div>`
    : '<div class="empty"><b>Le dispatcher n’a pas encore ajouté d’arrêts.</b><span>La liste se met à jour toute seule.</span></div>';
  let action = null, one = true;
  if (t.status === 'published') action = `<button class="btn big primary" data-act="start">Démarrer la tournée</button>`;
  else if (t.status === 'active' && !next) action = `<button class="btn big hi" data-act="go-close">Clôturer la tournée</button>`;
  else if (t.status === 'active') { action = `<button class="btn" data-act="go-close">Clôturer</button><button class="btn big primary" data-act="open-stop" data-id="${next.id}">Arrêt ${ss.indexOf(next) + 1}</button>`; one = false; }
  return { title: 'Tournée', tool, html, action, actionOne: one, mount: mountMap };
};
VIEWS.stop = r => {
  const s = C.stops[r.id]; if (!s) return { title: 'Arrêt', html: '<div class="empty">Cet arrêt a été retiré par le dispatcher.</div>' };
  const t = C.tours[s.tour_id], ss = stopsOf(t.id), i = ss.indexOf(s), a = A(s), eta = planInfo(t).etas[s.id];
  let html = `<div class="addr-hero"><div class="badge lg ${badgeCls(s)}">${i + 1}</div><div class="stop-body"><span class="eyebrow">Arrêt ${i + 1} sur ${ss.length}</span><h2 class="h2">${street(a)}</h2><span class="muted">${pcCity(a)}</span><div class="chips">${statusChip(s, eta)}${+s.priority ? '<span class="chip prio">Prioritaire</span>' : ''}</div></div></div>`;
  if (s.raw && a.label && s.raw.trim() !== a.label.trim()) html += `<p class="hint">Adresse reconnue dans le carnet. Saisie d'origine : « ${esc(s.raw)} ».</p>`;
  html += briefBox(a, s);
  html += `<section class="card"><dl class="kv">
    ${s.client ? `<dt>Client</dt><dd>${esc(s.client)}</dd>` : ''}
    ${s.phone ? `<dt>Téléphone</dt><dd><span class="sel num">${esc(s.phone)}</span> · <a href="tel:${esc(String(s.phone).replace(/\s/g, ''))}">appeler</a></dd>` : ''}
    ${winText(s) ? `<dt>Créneau</dt><dd class="num">${esc(winText(s))}</dd>` : ''}
    ${s.ref ? `<dt>Commande</dt><dd class="num">${esc(s.ref)}</dd>` : ''}
    ${s.notes ? `<dt>Colis</dt><dd>${esc(s.notes)}${s.weight_kg ? ` · ${esc(s.weight_kg)} kg` : ''}</dd>` : ''}
  </dl>${navLinks(a)}</section>`;
  if (s.status !== 'todo') html += `<section class="card"><span class="eyebrow">${s.status === 'done' ? 'Preuve de livraison' : 'Échec'}</span>${proofLine(s)}${proofThumbs(s)}${t.status === 'active' ? `<div><button class="btn ghost" data-act="reopen" data-id="${s.id}">Rouvrir l'arrêt</button></div>` : ''}</section>`;
  html += ficheBlock(a, s.id);
  let action = null, one = false;
  if (t.status === 'active' && s.status === 'todo') action = `<button class="btn big bad" data-act="fail" data-id="${s.id}">Échec</button><button class="btn big ok" data-act="deliver" data-id="${s.id}">Livré</button>`;
  else if (t.status === 'published') { action = `<button class="btn big primary" data-act="start">Démarrer la tournée</button>`; one = true; }
  return { title: `Arrêt ${i + 1}`, html, action, actionOne: one };
};
VIEWS.close = () => {
  const t = curTour(); if (!t) return VIEWS.tour();
  const ss = stopsOf(t.id), done = ss.filter(s => s.status === 'done'), failed = ss.filter(s => s.status === 'failed'), todo = ss.filter(s => s.status === 'todo');
  const reasons = {}; failed.forEach(s => { reasons[s.fail_reason] = (reasons[s.fail_reason] || 0) + 1; });
  const added = ss.reduce((m, s) => m + (s.fiche_added || 0), 0), real = t.started_at ? Math.round((Date.now() - new Date(t.started_at)) / 60000) : 0;
  let html = `<section class="card"><span class="eyebrow">Récapitulatif avant clôture</span><h2 class="h2">${esc(fmtDay(t.day))}</h2>
    <div class="stats"><div class="stat"><b>${done.length}</b><span>livrés</span></div><div class="stat"><b>${failed.length}</b><span>échecs</span></div><div class="stat"><b>${planInfo(t).km.toFixed(1)}</b><span>km estimés</span></div></div>
    <div class="stats"><div class="stat"><b>${fmtDur(real)}</b><span>durée réelle</span></div><div class="stat"><b>${fmtTime(nowIso())}</b><span>heure de fin</span></div><div class="stat"><b>${added}</b><span>ajouts aux fiches</span></div></div>
    ${failed.length ? `<p class="small">Échecs : ${Object.entries(reasons).map(([k, v]) => `${esc(k)} (${v})`).join(', ')}</p>` : ''}</section>`;
  if (todo.length) html += `<section class="card"><div class="warnbox">${todo.length} arrêt${todo.length > 1 ? 's' : ''} sans statut. Marquez-les livrés ou en échec pour clôturer.</div><div class="stops">${todo.map(s => `<button class="stop" data-act="open-stop" data-id="${s.id}"><div class="badge">${ss.indexOf(s) + 1}</div><div class="stop-body"><div class="stop-addr">${street(A(s))}</div><div class="small muted">${esc(s.client)}</div></div>${ICON.chev}</button>`).join('')}</div></section>`;
  else html += `<p class="note">En validant, la tournée passe en « terminée » chez le dispatcher${MODE === 'supabase' ? ', avec toutes les preuves déjà reçues' : ''}. Le rapport (CSV, PDF avec les photos, .zip) reste disponible ici pour l'envoyer.</p>`;
  return { title: 'Clôture', html, action: `<button class="btn big hi" data-act="finish" ${todo.length ? 'disabled' : ''}>Tournée terminée</button>`, actionOne: true };
};
VIEWS.carnet = () => {
  const t = curTour(); const ids = new Set(); for (const s of Object.values(C.stops)) if (getJoined().includes(s.tour_id)) ids.add(s.address_id);
  const q = UI.q.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const all = [...ids].map(id => C.addresses[id]).filter(Boolean).filter(a => !q || (a.label + ' ' + a.key).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(q));
  all.sort((x, y) => (ficheCount(y.id).all > 0) - (ficheCount(x.id).all > 0) || x.label.localeCompare(y.label));
  return { title: "Carnet d'adresses", html: `<p class="note">Les adresses de vos tournées, avec leurs fiches. Ce que vous ajoutez ici est visible du dispatcher et des prochains livreurs.</p>
    <label class="search">${ICON.search}<input id="q" type="search" placeholder="Rue, numéro, commune…" value="${esc(UI.q)}" aria-label="Rechercher une adresse"></label>
    <div class="list">${all.length ? all.map(a => addrRow(a)).join('') : '<div class="empty">Aucune adresse.</div>'}</div>`, mount: bindSearch };
};
function addrRow(a, act = 'open-address') { const sum = summary(a.id); return `<button class="row" data-act="${act}" data-id="${a.id}"><div class="row-body"><span class="row-title">${street(a)}</span><span class="small muted">${pcCity(a)}${a.client ? ' · ' + esc(a.client) : ''}</span>${sum ? `<span class="small">${esc(sum)}</span>` : ''}<div class="chips">${ficheChips(a)}</div></div>${ICON.chev}</button>`; }
function bindSearch() { const i = $('#q'); if (!i) return; i.addEventListener('input', () => { UI.q = i.value; const pos = i.selectionStart; render(); const j = $('#q'); j.focus(); try { j.setSelectionRange(pos, pos); } catch (e) {} }); }
VIEWS.address = r => {
  const a = C.addresses[r.id]; if (!a) return { title: 'Adresse', html: '<div class="empty">Adresse introuvable.</div>' };
  const visits = Object.values(C.stops).filter(s => s.address_id === a.id && s.status !== 'todo').sort((x, y) => String(y.done_at).localeCompare(String(x.done_at)));
  let html = `<div class="addr-hero"><div class="stop-body"><span class="eyebrow">Carnet</span><h2 class="h2">${street(a)}</h2><span class="muted">${pcCity(a)}${a.client ? ' · ' + esc(a.client) : ''}</span><div class="chips">${ficheChips(a)}${a.last_visit ? `<span class="chip">Dernier passage ${ago(a.last_visit)}</span>` : ''}</div></div></div>`;
  const sum = summary(a.id);
  if (sum) html += `<div class="brief"><div class="stripe" aria-hidden="true"></div><div class="brief-body"><span class="eyebrow">Résumé</span><p class="brief-sum">${esc(sum)}</p><div><button class="btn" data-act="speak-text" data-text="${esc(sum)}">${ICON.speaker} Écouter</button></div></div></div>`;
  html += `<section class="card">${navLinks(a)}${UI.role === 'dispatcher' ? `<div class="btnrow"><button class="btn" data-act="edit-address" data-id="${a.id}">${ICON.edit} Modifier l'adresse</button></div>` : ''}</section>`;
  html += ficheBlock(a, '');
  html += `<h3 class="h3">Livraisons à cette adresse</h3>` + (visits.length ? `<div class="list">${visits.map(s => { const t = C.tours[s.tour_id]; return `<div class="report-stop"><span class="small muted">${esc(t ? fmtDay(t.day) : '')} · ${esc(t?.driver_name || '')}</span>${proofLine(s)}${proofThumbs(s)}</div>`; }).join('')}</div>` : `<p class="note">Aucune livraison enregistrée pour l'instant${a.visits ? ` (${a.visits} passage${a.visits > 1 ? 's' : ''} dans l'historique d'exemple)` : ''}.</p>`);
  return { title: 'Adresse', html };
};
VIEWS.mytours = () => {
  const ts = getJoined().map(id => C.tours[id]).filter(Boolean);
  return { title: 'Mes tournées', html: `<div class="btnrow"><button class="btn primary" data-act="go-join">${ICON.key} Entrer un nouveau code</button></div>
    ${ts.length ? `<div class="list">${ts.map(t => { const k = tourCounts(t.id); return `<button class="row" data-act="open-dtour-driver" data-id="${t.id}"><div class="row-body"><span class="row-title">${esc(fmtDay(t.day))}</span><span class="small muted">${esc(t.name)} · ${k.n} arrêts · ${k.done} livrés</span><div class="chips">${toursChip(t)}<span class="chip num">${fmtCode(t.code)}</span></div></div>${ICON.chev}</button>`; }).join('')}</div>` : '<div class="empty">Aucune tournée ouverte sur ce téléphone.</div>'}` };
};
VIEWS.settings = () => ({
  title: 'Réglages', html: `<section class="card"><div class="field"><label for="sName">Votre nom (vu par le dispatcher)</label><input class="input" id="sName" value="${esc(UI.name)}" autocomplete="given-name"></div>
    <label class="switch" for="voiceOn"><span>Lire la fiche à voix haute à l'arrivée</span><input type="checkbox" id="voiceOn" ${ls.get('dm-voice', '1') === '1' ? 'checked' : ''}></label></section>
    ${settingsCommon()}`,
  mount() { bindVoiceCard(); $('#sName').addEventListener('change', e => { UI.name = e.target.value.trim(); ls.set('dm-name', UI.name); if (Api.saveProfile) Api.saveProfile({ name: UI.name }).catch(() => {}); toast('Nom enregistré'); }); $('#voiceOn').addEventListener('change', e => ls.set('dm-voice', e.target.checked ? '1' : '0')); },
});
function voiceCard() {
  const vs = loadVoices(), cur = pickVoice();
  return `<section class="card"><span class="eyebrow">Voix de lecture</span>
    ${vs.length ? `<div class="field"><label for="vVoice">Voix française</label><select class="input" id="vVoice">${vs.sort((a, b) => voiceScore(b) - voiceScore(a)).map(v => `<option value="${esc(v.name)}" ${cur && cur.name === v.name ? 'selected' : ''}>${esc(v.name)} (${esc(v.lang)})</option>`).join('')}</select></div>`
      : `<p class="note">Aucune voix française trouvée sur ce téléphone. Sur Android : Paramètres › Synthèse vocale › installer le français. Sur iPhone : Réglages › Accessibilité › Contenu énoncé › Voix › Français.</p>`}
    <div class="btnrow"><button class="btn" data-act="test-voice">${ICON.speaker} Tester la voix</button></div></section>`;
}
function bindVoiceCard() { const s = $('#vVoice'); if (s) s.addEventListener('change', () => { ls.set('dm-voice-name', s.value); speak('Voix choisie. Arrêt 3, avenue Louise 143 boîte 4.'); }); }
function accountCard() {
  const head = MODE === 'supabase' && UI.session ? `<p>${esc(UI.session.name || '')}</p><p class="small muted">${esc(UI.session.email || '')}${UI.session.provider === 'google' ? ' · connecté avec Google' : ''}</p><div class="btnrow"><button class="btn" data-act="logout">${ICON.logout} Se déconnecter</button></div>` : '<p class="small muted">Mode démo : pas de compte, les données restent sur cet appareil.</p>';
  return `<section class="card"><span class="eyebrow">Mon compte et mes données</span>${head}
    ${MODE === 'supabase' && UI.session && UI.session.provider !== 'google' ? `<div class="field"><label for="newPw">Nouveau mot de passe</label><input class="input" id="newPw" type="password" autocomplete="new-password" minlength="10" placeholder="10 caractères minimum"></div><div class="btnrow"><button class="btn" data-act="change-pw">${ICON.lock} Changer le mot de passe</button></div>` : ''}
    <div class="btnrow"><button class="btn" data-act="export-me">${ICON.file} Télécharger mes données</button></div>
    ${UI.confirmDelete ? `<div class="inline-confirm"><b>Supprimer définitivement votre compte ?</b><span>${UI.role === 'dispatcher' ? 'Vos tournées, arrêts, adresses, fiches, livreurs, photos et preuves seront effacés.' : 'Votre compte et vos accès aux tournées seront effacés. Vos ajouts aux fiches restent, anonymisés ; les preuves de livraison restent chez l’entreprise qui organise la tournée.'} Tapez SUPPRIMER pour confirmer.</span><input class="input" id="delConf" autocomplete="off" aria-label="Tapez SUPPRIMER"><div class="btnrow"><button class="btn bad" data-act="delete-me">Supprimer mon compte</button><button class="btn" data-act="delete-no">Annuler</button></div></div>` : `<button class="btn ghost" data-act="delete-ask">${ICON.trash} Supprimer mon compte</button>`}
    ${legalLinks()}</section>`;
}
function settingsCommon() {
  return `${UI.isAdmin ? `<section class="card"><span class="eyebrow">Administration</span><div class="btnrow"><button class="btn primary" data-act="admin">${ICON.lock} Ouvrir l'administration</button></div></section>` : ''}${accountCard()}${themeCard()}${voiceCard()}<section class="card"><span class="eyebrow">Ce téléphone</span>
    <p class="note">${MODE === 'supabase' ? 'Connecté au serveur : les tournées et les preuves sont partagées entre le dispatcher et les livreurs.' : IN_CLAUDE ? "Aperçu Claude en mode démo : les données restent dans ce navigateur, et le micro et le GPS y sont bloqués. La version hébergée lève ces limites." : 'Mode démo : les données restent dans ce navigateur. Branchez Supabase pour partager entre téléphones.'}</p>
    <p class="small muted">Position : ${UI.pos ? `${UI.pos.lat.toFixed(4)}, ${UI.pos.lng.toFixed(4)} (± ${UI.pos.acc} m)` : 'indisponible'}</p>
    <div class="btnrow"><button class="btn" data-act="switch-role">${ICON.logout} Changer de rôle</button></div></section>
    ${MODE === 'local' ? `<section class="card"><span class="eyebrow">Démo</span>${UI.confirmReset ? `<div class="inline-confirm"><b>Tout effacer et recharger l'exemple ?</b><span>Tournées, fiches, photos et vocaux de cet appareil seront supprimés.</span><div class="btnrow"><button class="btn bad" data-act="reset-yes">Effacer</button><button class="btn" data-act="reset-no">Annuler</button></div></div>` : `<button class="btn" data-act="reset">Réinitialiser la démo</button>`}</section>` : ''}`;
}
VIEWS.report = r => {
  const t = C.tours[r.id]; if (!t) return { title: 'Rapport', html: '<div class="empty">Rapport introuvable.</div>' };
  const ss = stopsOf(t.id), k = tourCounts(t.id), real = t.started_at && t.ended_at ? Math.round((new Date(t.ended_at) - new Date(t.started_at)) / 60000) : 0;
  const html = `<section class="card"><span class="eyebrow">${esc(fmtDay(t.day))} · ${esc(t.name)}</span><h2 class="h2">Rapport de ${esc(t.driver_name || 'tournée')}</h2>
    <div class="stats"><div class="stat"><b>${k.done}/${k.n}</b><span>livrés</span></div><div class="stat"><b>${k.failed}</b><span>échecs</span></div><div class="stat"><b>${fmtDur(real)}</b><span>durée</span></div></div>
    <p class="small muted">${t.ended_at ? `Clôturée à ${fmtTime(t.ended_at)}.` : 'Tournée pas encore clôturée.'}</p></section>
    <section class="card"><span class="eyebrow">Exporter le rapport</span>
    <div class="btnrow"><button class="btn primary" data-act="export" data-kind="zip" data-id="${t.id}">${ICON.file} Rapport complet (.zip)</button></div>
    <div class="btnrow"><button class="btn" data-act="export" data-kind="csv" data-id="${t.id}">Tableau (.csv)</button><button class="btn" data-act="export" data-kind="pdf" data-id="${t.id}">PDF avec photos</button></div>
    ${canShareFiles() ? `<div class="btnrow"><button class="btn" data-act="share" data-id="${t.id}">${ICON.share} Partager (WhatsApp, e-mail…)</button></div>` : ''}
    <p class="note">Le .zip contient le tableau, le PDF et un dossier par adresse avec les photos de preuve et la signature. Le CSV s'ouvre dans Excel (séparateur point-virgule).</p></section>
    <h3 class="h3">Preuves par adresse</h3>
    <div class="list">${ss.map((s, i) => `<div class="report-stop"><div class="addr-hero"><div class="badge ${badgeCls(s)}">${i + 1}</div><div class="stop-body"><div class="stop-addr">${street(A(s))}</div><div class="small muted">${pcCity(A(s))}${s.client ? ' · ' + esc(s.client) : ''}</div></div></div>${proofLine(s)}${proofThumbs(s)}</div>`).join('')}</div>`;
  return { title: 'Rapport', html, mount() { if (canShareFiles()) prepareShare(t); } };
};

VIEWS.admin = () => {
  if (!UI.isAdmin) return { title: 'Réglages', html: '<div class="empty">Accès réservé.</div>' };
  const o = UI.adminData;
  if (!o) { Api.adminOverview().then(r => { UI.adminData = r; render(); }).catch(() => { UI.isAdmin = false; toast('Accès refusé.'); back(); }); return { title: 'Administration', html: '<div class="empty">Chargement…</div>' }; }
  const d = v => v ? new Date(v).toLocaleDateString('fr-BE', { day: 'numeric', month: 'short', year: '2-digit' }) : '—';
  const q = normH(UI.adminQ || '');
  const acc = (o.accounts || []).filter(a => !q || normH(`${a.name || ''} ${a.email || ''}`).includes(q));
  return { title: 'Administration', html: `<section class="card"><span class="eyebrow">Vue d'ensemble</span>
      <div class="kpis"><div class="stat"><b>${o.users}</b><span>comptes</span></div><div class="stat"><b>${o.users_7d}</b><span>nouveaux 7 j</span></div><div class="stat"><b>${o.active_30d}</b><span>actifs 30 j</span></div><div class="stat"><b>${o.tours}</b><span>tournées</span></div></div>
      <div class="kpis"><div class="stat"><b>${o.tours_30d}</b><span>tournées 30 j</span></div><div class="stat"><b>${o.stops}</b><span>arrêts</span></div><div class="stat"><b>${o.delivered_30d}</b><span>livrés 30 j</span></div><div class="stat"><b>${o.addresses}</b><span>adresses</span></div></div>
      <div class="btnrow"><button class="btn" data-act="admin-refresh">${ICON.undo} Actualiser</button></div></section>
    <label class="search">${ICON.search}<input id="admQ" type="search" placeholder="Rechercher un compte" aria-label="Rechercher un compte" value="${esc(UI.adminQ || '')}"></label>
    <div class="list">${acc.map(a => `<div class="row"><div class="row-body"><span class="row-title">${esc(a.name || '(sans nom)')}${a.admin ? ' · admin' : ''}</span><span class="small muted">${esc(a.email || '')} · ${a.provider === 'google' ? 'Google' : 'e-mail'}${a.confirmed ? '' : ' · non confirmé'}</span>
      <span class="small muted">Créé le ${d(a.created_at)} · dernière connexion ${d(a.last_sign_in_at)}</span><div class="chips"><span class="chip">${a.tours} tournée${a.tours > 1 ? 's' : ''}</span><span class="chip">${a.stops} arrêts</span>${a.drivers_joined ? `<span class="chip">livreur sur ${a.drivers_joined}</span>` : ''}</div></div></div>`).join('') || '<div class="empty">Aucun compte.</div>'}</div>
    <p class="small muted">Vue limitée aux comptes et aux volumes : le contenu des tournées des clients n'est pas affiché ici.</p>` ,
    mount() { const i = $('#admQ'); i.addEventListener('input', () => { UI.adminQ = i.value; const p = i.selectionStart; render(); const n = $('#admQ'); n.focus(); n.setSelectionRange(p, p); }); } };
};
