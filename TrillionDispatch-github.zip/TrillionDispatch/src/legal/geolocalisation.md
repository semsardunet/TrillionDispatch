# Note d'information : géolocalisation pendant les tournées

À remettre aux livreurs avant leur première tournée. Version du 10 octobre 2026.

## Ce que l'application enregistre

- La position de votre téléphone, **uniquement** entre le moment où vous touchez « Démarrer la tournée » et « Tournée terminée ».
- Seulement la **dernière position**, mise à jour environ toutes les minutes. Aucun historique de trajet n'est conservé.
- La position au moment d'une preuve de livraison (photo, signature), jointe à cette preuve.

## Pourquoi

- Calculer les heures d'arrivée et informer les destinataires.
- Permettre au dispatcher de voir où en est la tournée.
- Vous lire la fiche d'accès à l'approche d'une adresse.
- Prouver qu'une livraison a été faite à la bonne adresse.

## Ce qui est exclu

- Aucun suivi en dehors des tournées, des heures de travail, des pauses ou des trajets domicile–travail.
- Aucun contrôle de la vitesse.
- Aucune surveillance permanente ni historique de vos déplacements.

## Qui y a accès et combien de temps

- Le dispatcher de l'entreprise qui organise la tournée, pour cette tournée seulement.
- La dernière position est effacée à la fin de la tournée.
- La position jointe aux preuves est supprimée après 13 mois.

## Vos droits

Vous pouvez demander l'accès à ces données, leur rectification ou leur effacement auprès de votre employeur ou donneur d'ordre, responsable du traitement, ou auprès de [privacy@domaine.be]. Vous pouvez saisir l'Autorité de protection des données, rue de la Presse 35, 1000 Bruxelles.

## Pour l'employeur

Avant d'utiliser la géolocalisation avec des travailleurs salariés, l'employeur doit :

- les informer par écrit, au moyen d'une politique claire qui précise les finalités, l'étendue et la durée du suivi ;
- consulter le conseil d'entreprise ou la délégation syndicale lorsqu'ils existent ;
- vérifier la proportionnalité du suivi ;
- réaliser une analyse d'impact relative à la protection des données lorsque le suivi est systématique ;
- respecter les limites rappelées par l'Autorité de protection des données.
