# Accord de sous-traitance (article 28 RGPD)

Version du 10 octobre 2026. Annexe aux conditions générales.

## 1. Parties et objet

Le Client, responsable du traitement, confie au Prestataire, sous-traitant, le traitement des données personnelles nécessaires à la préparation, à l'exécution et à la preuve de ses tournées de livraison au moyen du Service.

## 2. Description du traitement

- **Durée** : celle du contrat, puis 30 jours pour l'export et 90 jours au plus pour l'effacement des sauvegardes.
- **Nature** : hébergement, stockage, consultation, transmission aux livreurs, calcul d'itinéraires et d'heures d'arrivée, génération de rapports.
- **Personnes concernées** : destinataires des livraisons, livreurs et dispatchers du Client, réceptionnaires.
- **Données** : adresses, noms, téléphones, créneaux, contenu des colis, photos, signatures, noms des réceptionnaires, positions pendant la tournée et au moment des preuves, notes, vocaux et photos des fiches terrain.
- **Données sensibles** : aucune n'est attendue. Le Client veille à ce qu'aucune ne soit saisie.

## 3. Engagements du Prestataire

Le Prestataire s'engage à :

1. ne traiter les données que sur instruction documentée du Client, ces conditions et le paramétrage du Service valant instruction ;
2. informer le Client si une instruction lui paraît contraire au RGPD ;
3. garantir la confidentialité des personnes autorisées à traiter les données ;
4. appliquer les mesures de sécurité décrites en annexe ;
5. respecter les conditions de recours aux sous-traitants ultérieurs (article 4) ;
6. aider le Client à répondre aux demandes d'exercice des droits, notamment par les fonctions d'export et de suppression ;
7. aider le Client pour la sécurité, les notifications de violation et les analyses d'impact, compte tenu des informations dont il dispose ;
8. notifier au Client toute violation de données le concernant dans les 48 heures après en avoir pris connaissance ;
9. au terme du contrat, restituer les données par export puis les supprimer, sauf obligation légale de conservation ;
10. mettre à disposition les informations nécessaires pour démontrer le respect de ces obligations et permettre un audit, au plus une fois par an, avec un préavis de 30 jours et aux frais du Client.

## 4. Sous-traitants ultérieurs

Le Client autorise le recours aux sous-traitants suivants :

| Sous-traitant | Rôle | Localisation |
|---|---|---|
| Supabase Inc. | Base de données, stockage des fichiers, authentification | Francfort, Union européenne |
| Fondation OpenStreetMap | Fonds de carte et recherche des coordonnées d'une adresse | Royaume-Uni (décision d'adéquation) |
| [Hébergeur web] | Diffusion des fichiers de l'application | [pays] |

Tout nouveau sous-traitant est annoncé au moins 30 jours à l'avance. Le Client peut s'y opposer pour un motif légitime et, à défaut d'accord, résilier sans frais. Le Prestataire impose à chaque sous-traitant ultérieur des obligations équivalentes et reste responsable envers le Client.

## 5. Transferts hors Union européenne

Aucun transfert n'a lieu hors de l'Espace économique européen, sauf vers des pays reconnus adéquats ou sous les garanties de l'article 46 du RGPD.

## 6. Obligations du Client

Le Client :

- garantit la licéité de ses traitements ;
- informe les personnes concernées, en particulier ses livreurs sur la géolocalisation ;
- réalise l'analyse d'impact lorsqu'elle est requise ;
- règle les droits d'accès de ses dispatchers et de ses livreurs.

## Annexe : mesures techniques et organisationnelles

- Échanges chiffrés (HTTPS, TLS 1.2 ou plus).
- Données au repos chiffrées par l'hébergeur.
- Mots de passe hachés, connexion Google possible, sessions à durée limitée.
- Cloisonnement par Client appliqué par des règles de sécurité au niveau de chaque ligne de la base.
- Aucune écriture directe des livreurs dans les tables : chaque action passe par une fonction qui vérifie son droit d'accès à la tournée.
- Accès d'un livreur lié au code de la tournée et retiré dès que le code change.
- Limitation à 10 tentatives de code erronées par heure et par compte, et à 100 propositions de fiche par jour et par livreur.
- Fichiers dans un espace privé, servis par des liens temporaires, limités à 10 Mo et aux formats image et audio.
- Contrôle que chaque preuve ne référence que des fichiers de l'entreprise concernée.
- Limitation de la taille de toutes les saisies.
- Position du livreur limitée à la dernière connue, effacée en fin de tournée.
- Effacement automatique des données de sécurité après deux jours et des positions jointes aux preuves après 13 mois.
- Politique de sécurité du navigateur, en-têtes de sécurité HTTP, bibliothèques hébergées avec l'application.
- Sauvegardes de l'hébergeur selon la formule souscrite (quotidiennes en formule Pro).
- Console d'hébergement réservée à l'éditeur et protégée par double authentification ; vue d'administration de l'application limitée aux comptes et aux volumes, sans accès au contenu des tournées.
- Lecture des documents photographiés effectuée sur le téléphone, sans envoi ni conservation de l'image.
