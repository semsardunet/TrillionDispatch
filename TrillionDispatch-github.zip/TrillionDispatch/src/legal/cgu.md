# Conditions générales d'utilisation et de vente

Version du 10 octobre 2026. En vigueur à partir du [date de mise en ligne].

## 1. Objet

Les présentes conditions régissent l'accès à l'application TrillionDispatch (le « Service »), éditée par [NOM DE LA SOCIÉTÉ] (le « Prestataire »). Le Service permet de préparer des tournées de livraison, de les transmettre à des livreurs, de documenter l'accès aux adresses (« fiches terrain ») et d'enregistrer des preuves de livraison.

## 2. Réservé aux professionnels

Le Service est destiné exclusivement aux professionnels agissant dans le cadre de leur activité : entreprises qui organisent des livraisons (les « Clients »), leurs dispatchers et leurs livreurs salariés ou sous-traitants, et les livreurs indépendants. Il n'est pas proposé aux consommateurs. En créant un compte, l'utilisateur déclare agir à titre professionnel et être âgé d'au moins 18 ans.

## 3. Comptes

Chaque personne utilise un compte personnel, créé avec une adresse e-mail ou un compte Google. L'utilisateur garde ses identifiants confidentiels et prévient le Prestataire sans délai en cas d'usage frauduleux. Un Client est responsable des comptes qu'il invite dans ses tournées et des droits qu'il leur donne.

Le code d'une tournée donne accès à cette seule tournée. Le Client peut le changer à tout moment, ce qui retire l'accès aux livreurs déjà connectés.

## 4. Formules, prix et facturation

Les formules et leurs prix sont indiqués dans l'application au moment de la souscription. Les prix sont exprimés en euros hors TVA.

- Les abonnements sont mensuels, payables d'avance, et renouvelés tacitement chaque mois.
- L'usage au-delà du volume inclus (arrêts, messages envoyés aux destinataires) est facturé le mois suivant au tarif affiché.
- Les factures sont émises par voie électronique structurée (réseau Peppol), conformément à l'obligation belge applicable depuis le 1er janvier 2026.
- Toute facture impayée à l'échéance porte de plein droit, sans mise en demeure, l'intérêt prévu par la loi du 2 août 2002 concernant la lutte contre le retard de paiement dans les transactions commerciales, ainsi qu'une indemnité forfaitaire pour frais de recouvrement selon cette même loi.
- Après une mise en demeure restée sans effet pendant quinze jours, le Prestataire peut suspendre l'accès jusqu'au paiement complet.
- Le Prestataire peut modifier ses prix moyennant un préavis de trente jours. Le Client qui refuse la modification peut résilier avant son entrée en vigueur.

## 5. Durée et résiliation

Le Client peut résilier à tout moment depuis l'application ; la résiliation prend effet à la fin de la période payée, sans remboursement de la période entamée. Le Prestataire peut résilier moyennant un préavis de trente jours, ou sans préavis en cas de manquement grave (usage illicite, atteinte à la sécurité, impayé persistant).

À la fin du contrat, le Client dispose de trente jours pour exporter ses données (tableaux CSV, rapports PDF, archives avec les preuves). Elles sont ensuite supprimées, au plus tard quatre-vingt-dix jours après la fin du contrat pour les copies de sauvegarde.

## 6. Usage acceptable et contenus

L'utilisateur s'engage à :

- n'utiliser le Service que pour organiser et documenter des livraisons ;
- ne pas photographier de personnes, de plaques d'immatriculation ni l'intérieur d'un logement, et ne pas enregistrer de conversation avec un tiers sans son accord ;
- ne saisir dans les fiches que les informations utiles à l'accès (chemin, code, stationnement, consignes), sans donnée sensible ;
- ne pas tenter de contourner les protections du Service, d'accéder aux données d'un autre Client ou de deviner des codes de tournée.

Les ajouts proposés par les livreurs sont soumis à la validation du dispatcher avant d'être visibles par les autres livreurs. Le Prestataire peut retirer tout contenu manifestement illicite qui lui est signalé ; il en informe l'auteur en indiquant les motifs, sauf interdiction légale. L'auteur peut contester cette décision en répondant au message reçu.

## 7. Géolocalisation

La position du téléphone du livreur n'est transmise que pendant une tournée démarrée, entre « Démarrer la tournée » et « Tournée terminée », et seule la dernière position est conservée ; elle est effacée à la fin de la tournée. Le Client qui fait travailler des livreurs salariés reste seul responsable du respect des règles applicables à la surveillance des travailleurs : information préalable, politique écrite, consultation des organes compétents et, le cas échéant, analyse d'impact. La note d'information jointe l'y aide.

## 8. Données personnelles

Le traitement des données personnelles est décrit dans la politique de confidentialité. Pour les données des tournées (destinataires, adresses, preuves, positions), le Client est responsable du traitement et le Prestataire agit comme sous-traitant, dans les conditions de l'accord de sous-traitance, qui fait partie intégrante des présentes conditions.

## 9. Disponibilité et assistance

Le Prestataire met en œuvre les moyens raisonnables pour assurer l'accès au Service sept jours sur sept, avec une disponibilité visée de 99 % par mois, hors maintenance annoncée. L'application conserve la tournée en cours sur le téléphone pour limiter l'effet d'une coupure de réseau. L'assistance est assurée par e-mail les jours ouvrables.

## 10. Responsabilité

Le Prestataire est tenu d'une obligation de moyens. Il ne répond pas :

- des itinéraires proposés par les services de navigation tiers (Waze, Google Maps) ni des conditions de circulation ;
- de l'exactitude des informations saisies par les utilisateurs dans les fiches et les tournées ;
- de l'exécution des livraisons elles-mêmes, des colis ni des relations entre le Client, ses livreurs et ses destinataires ;
- des dommages indirects, tels que perte de chiffre d'affaires, de clientèle ou de données qui auraient pu être exportées.

Sauf faute intentionnelle ou dol, la responsabilité totale du Prestataire est limitée au montant payé par le Client au cours des douze mois précédant le fait générateur.

## 11. Force majeure

Aucune partie n'est responsable d'un manquement causé par un événement échappant raisonnablement à son contrôle, notamment une panne majeure d'un fournisseur d'infrastructure ou de réseau, pendant la durée de cet événement.

## 12. Propriété intellectuelle

Le Prestataire concède au Client un droit d'utilisation non exclusif et non transférable du Service pendant la durée du contrat. Le Client reste propriétaire de ses données et autorise le Prestataire à les traiter uniquement pour fournir le Service.

## 13. Modification des conditions

Le Prestataire peut modifier les présentes conditions. Les modifications substantielles sont annoncées dans l'application au moins trente jours à l'avance et doivent être acceptées pour continuer à utiliser le Service. Le Client qui refuse peut résilier sans frais avant leur entrée en vigueur.

## 14. Droit applicable et litiges

Les présentes conditions sont soumises au droit belge. Les parties cherchent d'abord une solution amiable. À défaut, les tribunaux francophones de l'arrondissement judiciaire de Bruxelles sont seuls compétents.
