# Mentions légales

Version du 10 octobre 2026.

## Éditeur du service

L'application TrillionDispatch est éditée par :

- **Dénomination** : [NOM DE LA SOCIÉTÉ], [forme juridique]
- **Siège** : [rue et numéro], [code postal] [commune], Belgique
- **Numéro d'entreprise (BCE)** : [0xxx.xxx.xxx]
- **Numéro de TVA** : [BE 0xxx.xxx.xxx]
- **E-mail** : [contact@domaine.be]
- **Téléphone** : [+32 …]
- **Responsable de la publication** : [prénom et nom]

## Hébergement

- **Application et données** : Supabase Inc., infrastructure située à Francfort (Allemagne, Union européenne).
- **Fichiers de l'application** : [nom de l'hébergeur web, adresse].

## Contact pour les autorités et les signalements

Point de contact unique (règlement européen sur les services numériques, art. 11 et 12) : [contact@domaine.be], en français, néerlandais ou anglais. Tout contenu illicite peut être signalé à cette adresse en précisant l'adresse concernée, le contenu visé et la raison du signalement.

## Propriété intellectuelle

L'application, son code, son nom et sa présentation appartiennent à l'éditeur. Les données saisies par les clients (adresses, tournées, fiches, photos, preuves) restent leur propriété.

Les cartes et la recherche d'adresses utilisent les données © contributeurs OpenStreetMap, sous licence ODbL.
