# Politique de confidentialité

Version du 10 octobre 2026.

## 1. Qui est responsable de vos données ?

[NOM DE LA SOCIÉTÉ], [adresse du siège], numéro d'entreprise [0xxx.xxx.xxx], joignable à [privacy@domaine.be] (le « Prestataire »).

Deux situations coexistent :

- **Votre compte** (identité, e-mail, connexion, acceptation des conditions) : le Prestataire est responsable du traitement.
- **Les données des tournées** (adresses et destinataires, preuves de livraison, positions pendant la tournée, fiches terrain) : l'entreprise cliente qui organise la tournée est responsable du traitement. Le Prestataire les traite pour son compte, comme sous-traitant. Pour ces données, adressez-vous d'abord à cette entreprise.

## 2. Quelles données, pourquoi, sur quelle base ?

| Données | Pourquoi | Base légale |
|---|---|---|
| Nom, e-mail, mot de passe chiffré ou identifiant Google, photo de profil Google | Créer et sécuriser le compte | Exécution du contrat (art. 6.1.b RGPD) |
| Date et version des conditions acceptées | Prouver l'acceptation | Obligation et intérêt légitime de preuve (art. 6.1.c et f) |
| Tentatives de code de tournée | Bloquer les essais en série | Intérêt légitime de sécurité (art. 6.1.f) |
| Adresses de livraison, nom et téléphone du destinataire, créneaux, contenu des colis | Préparer et réaliser les tournées | Pour le compte du client |
| Position du téléphone du livreur, pendant la tournée uniquement | Heures d'arrivée, suivi par le dispatcher, rappel de la fiche à l'arrivée | Pour le compte du client |
| Photos, signature, nom du réceptionnaire, position au moment de la preuve | Prouver la livraison | Pour le compte du client |
| Photos, notes et vocaux des fiches terrain | Indiquer l'accès aux adresses aux livreurs suivants | Pour le compte du client |

Aucune donnée n'est vendue, utilisée pour de la publicité ou pour du profilage.

## 3. La position du livreur

- Elle n'est envoyée qu'entre « Démarrer la tournée » et « Tournée terminée ».
- Seule la dernière position est conservée, jamais un historique de trajet.
- Elle est effacée dès la fin de la tournée.
- La position enregistrée avec une preuve de livraison est supprimée après 13 mois.
- Elle n'est pas utilisée pour contrôler la vitesse ni en dehors des heures de travail.

## 4. Combien de temps ?

| Données | Durée |
|---|---|
| Compte | Jusqu'à sa suppression par l'utilisateur, ou 30 jours après la fin du contrat du client |
| Dernière position pendant la tournée | Effacée à la fin de la tournée |
| Position jointe aux preuves | 13 mois |
| Preuves, tournées, fiches | Le temps choisi par le client ; supprimées au plus tard 90 jours après la fin de son contrat |
| Tentatives de code | 2 jours |
| Copies de sauvegarde | Au plus 90 jours |

## 5. Qui y a accès ?

- L'entreprise cliente et ses dispatchers, pour ses propres tournées.
- Les livreurs, pour les seules tournées qu'ils ont ouvertes avec un code valide.
- L'éditeur, pour l'assistance et la sécurité : la liste des comptes (nom, e-mail, dates de création et de connexion) et les volumes d'utilisation, sans le contenu des tournées.
- Les sous-traitants techniques du Prestataire :
  - **Supabase** (base de données, stockage, connexion), serveurs à Francfort, Union européenne ;
  - **Google** (seulement si vous choisissez « Continuer avec Google ») ; Google LLC est certifiée au cadre de protection des données UE–États-Unis ;
  - **Fondation OpenStreetMap** (fonds de carte et recherche des coordonnées d'une adresse saisie), au Royaume-Uni, pays reconnu adéquat par la Commission européenne ;
  - **[hébergeur web]**, qui sert les fichiers de l'application.

Les liens Waze et Google Maps n'envoient une adresse à ces services que lorsque le livreur choisit de lancer la navigation.

## 6. Reconnaissance vocale et lecture de documents

La transcription des notes vocales est faite par la fonction de dictée du navigateur du téléphone. Selon le navigateur, l'enregistrement peut être traité par le fournisseur de ce navigateur. Le texte transcrit peut toujours être corrigé ou effacé avant l'envoi.

La lecture d'un document photographié (bon de livraison, liste d'adresses) se fait entièrement sur le téléphone. La photo n'est ni envoyée ni conservée ; seules les adresses que vous validez sont ajoutées à la tournée.

## 7. Sécurité

- Chiffrement des échanges (HTTPS).
- Mots de passe stockés chiffrés.
- Cloisonnement des données par entreprise, appliqué par la base de données elle-même.
- Photos et vocaux dans un espace privé, accessibles uniquement par des liens temporaires.
- Accès des livreurs limité aux tournées dont ils ont le code, retiré dès que le code change.
- Limitation des tentatives de code.
- Contrôle de la taille et du type des fichiers.

En cas de violation de données présentant un risque, l'Autorité de protection des données est notifiée dans les 72 heures et les personnes concernées sont informées lorsque la loi l'exige.

## 8. Vos droits

Vous pouvez demander l'accès à vos données, leur rectification, leur effacement, la limitation du traitement, leur portabilité, et vous opposer à un traitement fondé sur l'intérêt légitime.

- Dans l'application, menu Réglages : **Télécharger mes données** et **Supprimer mon compte**.
- Par e-mail : [privacy@domaine.be]. Réponse dans un délai d'un mois.
- Pour les données d'une tournée, la demande est transmise à l'entreprise cliente concernée.

Vous pouvez introduire une réclamation auprès de l'**Autorité de protection des données**, rue de la Presse 35, 1000 Bruxelles, contact@apd-gba.be, www.autoriteprotectiondonnees.be.

## 9. Stockage sur votre téléphone

L'application garde sur votre téléphone votre session de connexion, vos préférences (voix, nom affiché) et la tournée en cours. Ce stockage est strictement nécessaire au fonctionnement ; il n'y a ni cookie publicitaire ni outil de mesure d'audience. La déconnexion efface ces informations.

## 10. Modifications

Toute modification importante de cette politique est annoncée dans l'application avant son entrée en vigueur.
