/* ---------- bottom sheets ---------- */
let sheetOnClose = null;
function openSheet(title, html, mount, onClose) {
  const o = $('#overlay');
  o.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="grab" aria-hidden="true"></div><div class="sheet-head"><h2 class="h3">${esc(title)}</h2><button class="iconbtn" data-act="close-sheet" aria-label="Fermer">${ICON.close}</button></div>${html}</div>`;
  o.hidden = false; sheetOnClose = onClose || null;
  const sh = $('.sheet', o); mount && mount(sh); hydrate(o);
}
function closeSheet() { const o = $('#overlay'); if (o.hidden) return; o.hidden = true; o.innerHTML = ''; const f = sheetOnClose; sheetOnClose = null; f && f(); }
const picker = (name, items, sel) => `<div class="picks" data-pick="${name}">${items.map(t => `<button type="button" class="pick" data-act="pick" aria-pressed="${t === sel}" data-val="${esc(t)}">${esc(t)}</button>`).join('')}</div>`;
const getPick = (root, name) => root.querySelector(`[data-pick="${name}"] [aria-pressed="true"]`)?.dataset.val || '';
const tagField = sel => `<div class="field"><span class="label">Étiquette</span>${picker('tag', TAGS, sel)}</div>`;

async function addEl(aid, el, stopId, opts = {}) {
  const a = C.addresses[aid]; if (!a) return;
  try {
    if (el.blob) { const t = C.tours[UI.tourId] || (stopId && C.tours[C.stops[stopId]?.tour_id]); el.media = await Api.upload(el.blob, el.ext, UI.role === 'dispatcher' ? undefined : (t && t.owner)); }
    delete el.blob; delete el.ext;
    if (opts.editId) {
      const patch = {}; for (const k of ['media', 'body', 'tag', 'transcript', 'pinned', 'status']) if (el[k] !== undefined) patch[k] = el[k];
      await Api.updateElement(opts.editId, patch); closeSheet(); render(); toast('Fiche mise à jour'); return;
    }
    el.author = UI.role === 'dispatcher' ? 'Dispatcher' : (UI.name || 'Livreur');
    if (UI.role === 'dispatcher') { await Api.addElement(aid, el); closeSheet(); render(); toast(`Ajouté à la fiche : ${a.label.split(',')[0]}`); }
    else { await Api.driverAddElement(aid, stopId || null, el); closeSheet(); render(); toast('Envoyé au dispatcher. Visible des autres livreurs après validation.', 3800); }
  } catch (e) { toast('Enregistrement impossible : ' + (e.message || 'erreur réseau')); const b = $('.sheet .btn.primary[disabled]'); if (b) b.disabled = false; }
}
/* photo + annotation (arrow, circle, cross) */
function pickPhoto(cb) { UI.onPhoto = cb; const i = $('#filePhoto'); i.value = ''; i.click(); }
function pickGallery(cb) { UI.onGallery = cb; const i = $('#fileGallery'); i.value = ''; i.click(); }
async function annotateQueue(files, key, ctx) { const list = [...files].filter(f => /^image\//.test(f.type) || /\.(jpe?g|png|webp|heic|gif)$/i.test(f.name)); for (let i = 0; i < list.length; i++) { const r = await annotateSheet(list[i], key, ctx, { counter: list.length > 1 ? `${i + 1}/${list.length}` : '' }); if (r === 'cancel' && i < list.length - 1) { toast('Import des photos interrompu'); break; } } }
async function annotateSheet(file, key, ctx, opts = {}) {
  let img; try { img = await fileToImage(file); } catch (e) { toast("Cette image n'a pas pu être ouverte."); return 'error'; }
  const pre = opts.el || {}; let saved = false; let done; const finished = new Promise(r => { done = r; });
  const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
  const W = Math.round(img.naturalWidth * k), H = Math.round(img.naturalHeight * k);
  const shapes = []; let tool = 'arrow', live = null;
  openSheet(opts.editId ? 'Réannoter la photo' : `Photo pour la fiche${opts.counter ? ' · ' + opts.counter : ''}`, `
    <div class="canvas-wrap"><canvas id="annot" width="${W}" height="${H}" aria-label="Photo à annoter"></canvas></div>
    <div class="tools" role="toolbar" aria-label="Outils d'annotation">
      <button class="tool" data-tool="arrow" aria-pressed="true">${ICON.arrow}Flèche</button>
      <button class="tool" data-tool="circle" aria-pressed="false">${ICON.circle}Cercle</button>
      <button class="tool" data-tool="cross" aria-pressed="false">${ICON.cross}Croix</button>
      <button class="tool" data-tool="undo" aria-pressed="false">${ICON.undo}Annuler</button>
    </div>
    <p class="hint">Glissez le doigt sur la photo pour tracer. Montrez le chemin, entourez la boîte. Ni personnes, ni plaques, ni intérieur de logement.</p>
    <div class="field"><label for="cap">Légende</label><input class="input" id="cap" placeholder="Ex. : passer par la grille à droite du hangar" maxlength="160" value="${esc(pre.body || '')}"></div>
    ${tagField(pre.tag || 'Accès')}
    <button class="btn big primary" id="savePhoto">${opts.editId ? 'Enregistrer' : UI.role === 'dispatcher' ? 'Ajouter à la fiche' : 'Proposer au dispatcher'}</button>`, sh => {
    const c = $('#annot', sh), g = c.getContext('2d');
    const L = Math.max(6, W * 0.011);
    const stroke = (fn) => { g.lineCap = 'round'; g.lineJoin = 'round'; g.strokeStyle = '#111'; g.lineWidth = L + 7; g.beginPath(); fn(); g.stroke(); g.strokeStyle = '#FFC21A'; g.lineWidth = L; g.beginPath(); fn(); g.stroke(); };
    const drawShape = s => {
      if (s.t === 'arrow') { const ang = Math.atan2(s.b.y - s.a.y, s.b.x - s.a.x), h = Math.max(28, W * 0.045);
        stroke(() => { g.moveTo(s.a.x, s.a.y); g.lineTo(s.b.x, s.b.y); g.moveTo(s.b.x, s.b.y); g.lineTo(s.b.x - h * Math.cos(ang - 0.5), s.b.y - h * Math.sin(ang - 0.5)); g.moveTo(s.b.x, s.b.y); g.lineTo(s.b.x - h * Math.cos(ang + 0.5), s.b.y - h * Math.sin(ang + 0.5)); }); }
      if (s.t === 'circle') { const r = Math.hypot(s.b.x - s.a.x, s.b.y - s.a.y); if (r > 4) stroke(() => g.arc(s.a.x, s.a.y, r, 0, Math.PI * 2)); }
      if (s.t === 'cross') { const d = Math.max(22, W * 0.035); stroke(() => { g.moveTo(s.a.x - d, s.a.y - d); g.lineTo(s.a.x + d, s.a.y + d); g.moveTo(s.a.x + d, s.a.y - d); g.lineTo(s.a.x - d, s.a.y + d); }); }
    };
    const draw = () => { g.drawImage(img, 0, 0, W, H); shapes.forEach(drawShape); if (live) drawShape(live); };
    draw();
    const pt = e => { const r = c.getBoundingClientRect(); return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height }; };
    c.addEventListener('pointerdown', e => { e.preventDefault(); c.setPointerCapture(e.pointerId); const p = pt(e); if (tool === 'cross') { shapes.push({ t: 'cross', a: p }); draw(); return; } live = { t: tool, a: p, b: p }; });
    c.addEventListener('pointermove', e => { if (!live) return; live.b = pt(e); draw(); });
    const end = () => { if (live && Math.hypot(live.b.x - live.a.x, live.b.y - live.a.y) > 12) shapes.push(live); live = null; draw(); };
    c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end);
    sh.querySelectorAll('.tool').forEach(b => b.addEventListener('click', () => {
      if (b.dataset.tool === 'undo') { shapes.pop(); draw(); return; }
      tool = b.dataset.tool; sh.querySelectorAll('.tool').forEach(x => x.setAttribute('aria-pressed', x === b));
    }));
    $('#savePhoto', sh).addEventListener('click', async e => {
      e.target.disabled = true; live = null; draw();
      const blob = await canvasBlob(c, 'image/jpeg', 0.8); saved = true;
      addEl(key, { type: 'photo', blob, ext: 'jpg', tag: getPick(sh, 'tag') || 'Autre', body: $('#cap', sh).value.trim() }, ctx, opts);
    });
  }, () => done(saved ? 'saved' : 'cancel'));
  return finished;
}

/* voice note: hold to talk, or tap to start / tap to stop */
function voiceSheet(key, ctx, opts = {}) {
  let stream = null, rec = null, chunks = [], blob = null, t0 = 0, timer = null, sr = null, transcript = '', tapMode = false, downAt = 0, starting = false;
  const cleanup = () => { clearInterval(timer); try { rec && rec.state !== 'inactive' && rec.stop(); } catch (e) {} try { sr && sr.stop(); } catch (e) {} stream && stream.getTracks().forEach(tr => tr.stop()); stream = null; };
  openSheet(opts.editId ? 'Réenregistrer la note vocale' : 'Note vocale', `
    <div class="rec" id="recZone"><button class="rec-btn" id="recBtn" aria-label="Maintenir pour enregistrer">${ICON.mic}</button>
      <div class="rec-time" id="recTime">0:00</div><p class="hint" id="recHint" style="text-align:center">Maintenez le bouton et parlez, relâchez pour terminer. Ou touchez une fois pour démarrer, une fois pour arrêter.</p></div>
    <div id="recFallback" hidden><div class="warnbox">${IN_CLAUDE ? "L'aperçu Claude bloque le micro. Ouvrez la version hébergée pour enregistrer en direct, ou importez un enregistrement fait avec le téléphone." : "Le micro n'est pas autorisé. Autorisez-le dans le navigateur, ou importez un enregistrement."}</div>
      <div class="btnrow"><button class="btn" id="recImport">${ICON.file} Importer un audio</button><button class="btn" id="recType">${ICON.note} Écrire la note</button></div></div>
    <div id="recAfter" hidden style="display:flex;flex-direction:column;gap:14px">
      <audio controls id="recAudio" style="width:100%"></audio>
      <div class="field"><label for="recText">Transcription</label><textarea class="input" id="recText" placeholder="Ce que vous avez dit, en une ou deux phrases. C'est ce texte que le prochain livreur lira en arrivant."></textarea></div>
      ${tagField('Accès')}
      <button class="btn big primary" id="recSave">${opts.editId ? 'Remplacer le vocal' : UI.role === 'dispatcher' ? 'Ajouter à la fiche' : 'Proposer au dispatcher'}</button>
      <button class="btn ghost" id="recRedo">Recommencer</button></div>`, sh => {
    const btn = $('#recBtn', sh), time = $('#recTime', sh), hint = $('#recHint', sh);
    const fallback = () => { cleanup(); $('#recZone', sh).hidden = true; $('#recFallback', sh).hidden = false; };
    const showAfter = (b, text) => {
      blob = b; $('#recZone', sh).hidden = true; $('#recFallback', sh).hidden = true; const after = $('#recAfter', sh); after.hidden = false; after.style.display = 'flex';
      $('#recAudio', sh).src = URL.createObjectURL(b); $('#recText', sh).value = text || '';
    };
    const stop = () => { if (rec && rec.state === 'recording') { rec.stop(); btn.classList.remove('on'); clearInterval(timer); try { sr && sr.stop(); } catch (e) {} } };
    const start = async () => {
      if (starting || (rec && rec.state === 'recording')) return;
      if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return fallback();
      starting = true;
      try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
      catch (e) { starting = false; return fallback(); }
      const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/ogg;codecs=opus', 'audio/webm'].find(m => { try { return MediaRecorder.isTypeSupported(m); } catch (e) { return false; } });
      try { rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined); } catch (e) { starting = false; return fallback(); }
      chunks = []; rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      rec.onstop = () => { stream && stream.getTracks().forEach(tr => tr.stop()); const b = new Blob(chunks, { type: rec.mimeType || mime || 'audio/webm' }); if (b.size > 800) showAfter(b, transcript.trim()); else { hint.textContent = 'Trop court. Maintenez le bouton pendant que vous parlez.'; time.textContent = '0:00'; } };
      rec.start(250); starting = false; t0 = Date.now(); btn.classList.add('on');
      if (!downAt || Date.now() - downAt < 450) tapMode = true;
      hint.textContent = tapMode ? 'Enregistrement… touchez pour arrêter.' : 'Enregistrement… relâchez pour terminer.';
      timer = setInterval(() => { const s = Math.floor((Date.now() - t0) / 1000); time.textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; if (s >= 90) stop(); }, 250);
      const SRC = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SRC) { try { sr = new SRC(); sr.lang = 'fr-FR'; sr.continuous = true; sr.interimResults = true;
        sr.onresult = e => { let txt = ''; for (const r of e.results) txt += r[0].transcript; transcript = txt; hint.textContent = '« ' + txt + ' »'; }; sr.onerror = () => {}; sr.start(); } catch (e) { sr = null; } }
    };
    btn.addEventListener('pointerdown', e => { e.preventDefault(); if (rec && rec.state === 'recording') { stop(); return; } downAt = Date.now(); tapMode = false; start(); });
    btn.addEventListener('pointerup', () => { if (rec && rec.state === 'recording' && !tapMode && Date.now() - downAt > 450) stop(); else if (Date.now() - downAt < 450) tapMode = true; });
    btn.addEventListener('contextmenu', e => e.preventDefault());
    $('#recImport', sh).addEventListener('click', () => { UI.onAudio = f => showAfter(f, ''); const i = $('#fileAudio'); i.value = ''; i.click(); });
    $('#recType', sh).addEventListener('click', () => { closeSheet(); textSheet(key, ctx); });
    $('#recRedo', sh).addEventListener('click', () => { closeSheet(); voiceSheet(key, ctx, opts); });
    $('#recSave', sh).addEventListener('click', async e => {
      if (!blob) return; e.target.disabled = true;
      const ext = /mp4|m4a|aac/.test(blob.type) ? 'm4a' : /ogg/.test(blob.type) ? 'ogg' : /mpeg|mp3/.test(blob.type) ? 'mp3' : 'webm';
      addEl(key, { type: 'voice', blob, ext, transcript: $('#recText', sh).value.trim(), tag: getPick(sh, 'tag') || 'Autre' }, ctx, opts);
    });
  }, cleanup);
}

function textSheet(key, ctx, preset = {}) {
  openSheet(preset.title || 'Note pour la fiche', `
    ${preset.lead ? `<p class="note">${esc(preset.lead)}</p>` : ''}
    <div class="field"><label for="noteText">Note</label><textarea class="input" id="noteText" placeholder="Ex. : la clé se trouve sous le caillou à gauche de la porte du garage."></textarea></div>
    ${tagField(preset.tag || 'Accès')}
    ${UI.role === 'dispatcher' ? '<label class="switch" for="notePin"><span>Consigne officielle du client (affichée en premier)</span><input type="checkbox" id="notePin"></label>' : ''}
    <button class="btn big primary" id="noteSave">${UI.role === 'dispatcher' ? 'Ajouter à la fiche' : 'Proposer au dispatcher'}</button>`, sh => {
    const ta = $('#noteText', sh); setTimeout(() => ta.focus(), 50);
    $('#noteSave', sh).addEventListener('click', e => {
      const text = ta.value.trim(); if (!text) { ta.focus(); toast('Écrivez la note avant de l’ajouter.'); return; }
      const pin = !!($('#notePin', sh) && $('#notePin', sh).checked); e && e.target && (e.target.disabled = true);
      addEl(key, { type: 'text', body: text, tag: getPick(sh, 'tag') || 'Autre', pinned: pin }, ctx);
    });
  });
}

/* proof of delivery */
const PLACES = ['En main propre', 'Boîte aux lettres', 'Devant la porte', 'Chez un voisin', 'Lieu indiqué par la fiche', 'Accueil / réception'];
const REASONS = ['Client absent', 'Adresse introuvable', 'Accès impossible', 'Refusé par le client', 'Colis endommagé', 'Hors créneau', 'Autre'];
function photoTiles(list, idPrefix) {
  return `<div class="thumbs">${list.map((p, i) => `<div class="thumb"><img alt="Preuve ${i + 1}" src="${p.url}"><button type="button" data-rm="${i}" aria-label="Retirer la photo ${i + 1}">×</button></div>`).join('')}${list.length < 4 ? `<button type="button" class="thumb add" id="${idPrefix}Add" aria-label="Prendre une photo">${ICON.camera}</button>` : ''}</div>`;
}
function sigPad(c) {
  const dpr = Math.max(1, window.devicePixelRatio || 1); const r = c.getBoundingClientRect();
  c.width = Math.round(r.width * dpr); c.height = Math.round(r.height * dpr);
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.lineWidth = 2.6 * dpr; g.lineCap = 'round'; g.strokeStyle = '#0b1530';
  let down = false, last = null; const pad = { signed: false, clear() { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); pad.signed = false; } };
  const p = e => { const b = c.getBoundingClientRect(); return { x: (e.clientX - b.left) * dpr, y: (e.clientY - b.top) * dpr }; };
  c.addEventListener('pointerdown', e => { e.preventDefault(); c.setPointerCapture(e.pointerId); down = true; last = p(e); });
  c.addEventListener('pointermove', e => { if (!down) return; const q = p(e); g.beginPath(); g.moveTo(last.x, last.y); g.lineTo(q.x, q.y); g.stroke(); last = q; pad.signed = true; });
  const up = () => { down = false; }; c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
  return pad;
}
const rankOf = s => stopsOf(s.tour_id).findIndex(x => x.id === s.id) + 1;
async function uploadAll(list, ext, owner) { const out = []; for (const b of list) out.push(await Api.upload(b, ext, owner)); return out; }
function deliverSheet(id) {
  const s = C.stops[id]; if (!s) return; const t = C.tours[s.tour_id];
  const arrived = s.arrived_at || nowIso();
  const photos = []; let gps = null, pad = null;
  openSheet(`Livré · arrêt ${rankOf(s)}`, `
    <div class="field"><span class="label">Où est le colis ?</span>${picker('place', PLACES, '')}</div>
    <div class="field"><span class="label">Photos de preuve</span><div id="pPhotos">${photoTiles(photos, 'p')}</div><span class="hint">Photographiez le colis à l'endroit où vous le laissez, avec la porte ou la boîte visible. Évitez les personnes et les plaques.</span></div>
    <div class="field"><label for="pName">Reçu par</label><input class="input" id="pName" placeholder="Nom du réceptionnaire" autocomplete="off"></div>
    <label class="switch" for="pSignOn"><span>Faire signer le client</span><input type="checkbox" id="pSignOn"></label>
    <div id="pSignBox" hidden style="flex-direction:column;gap:8px"><canvas class="sig" id="pSig" aria-label="Zone de signature"></canvas><div><button type="button" class="btn ghost" id="pSigClear">Effacer la signature</button></div></div>
    <div class="field"><label for="pNote">Remarque</label><input class="input" id="pNote" placeholder="Facultatif"></div>
    <p class="small muted num" id="pGps">Recherche de la position…</p>
    <div class="warnbox" id="pWarn" hidden></div>
    <button class="btn big ok" id="pSave">Valider la livraison</button>`, sh => {
    const refresh = () => { $('#pPhotos', sh).innerHTML = photoTiles(photos, 'p'); bind(); };
    const bind = () => {
      const add = $('#pAdd', sh); add && add.addEventListener('click', () => pickPhoto(async f => { const b = await shrink(f, 1600); photos.push({ blob: b, url: URL.createObjectURL(b) }); refresh(); }));
      sh.querySelectorAll('#pPhotos [data-rm]').forEach(b => b.addEventListener('click', () => { photos.splice(+b.dataset.rm, 1); refresh(); }));
    };
    bind();
    currentPos().then(p => { gps = p; const el = $('#pGps', sh); if (el) el.textContent = p ? `Position enregistrée : ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)} (± ${p.acc} m)` : `Position indisponible${IN_CLAUDE ? " dans l'aperçu Claude" : ''}. La livraison sera enregistrée sans GPS.`; });
    $('#pSignOn', sh).addEventListener('change', e => { const box = $('#pSignBox', sh); box.hidden = !e.target.checked; box.style.display = e.target.checked ? 'flex' : ''; if (e.target.checked && !pad) pad = sigPad($('#pSig', sh)); });
    $('#pSigClear', sh).addEventListener('click', () => pad && pad.clear());
    $('#pSave', sh).addEventListener('click', async e => {
      const place = getPick(sh, 'place'), name = $('#pName', sh).value.trim(), signed = !!(pad && pad.signed);
      const warn = $('#pWarn', sh); let msg = '';
      if (!place) msg = 'Indiquez où vous avez laissé le colis.';
      else if (!photos.length && !signed && !(place === 'En main propre' && name)) msg = place === 'En main propre' ? 'Ajoutez une photo, une signature ou le nom de la personne.' : 'Ajoutez au moins une photo du colis déposé.';
      if (msg) { warn.textContent = msg; warn.hidden = false; return; }
      e.target.disabled = true; e.target.textContent = 'Envoi…';
      try {
        const paths = await uploadAll(photos.map(p => p.blob), 'jpg', t.owner);
        const sig = signed ? (await uploadAll([await canvasBlob($('#pSig', sh), 'image/png')], 'png', t.owner))[0] : null;
        const proof = { place, photos: paths, signature: sig, recipient: name, note: $('#pNote', sh).value.trim(), gps: gps ? { lat: gps.lat, lng: gps.lng, acc: gps.acc } : null, at: nowIso() };
        await Api.driverUpdateStop(s.id, { status: 'done', done_at: nowIso(), arrived_at: arrived, proof });
        closeSheet(); afterStop(s, true);
      } catch (err) { e.target.disabled = false; e.target.textContent = 'Valider la livraison'; warn.textContent = 'Envoi impossible : ' + (err.message || 'réseau') + '. Réessayez quand le réseau revient.'; warn.hidden = false; }
    });
  });
}
function failSheet(id) {
  const s = C.stops[id]; if (!s) return; const t = C.tours[s.tour_id];
  const arrived = s.arrived_at || nowIso(); const photos = []; let gps = null;
  openSheet(`Échec · arrêt ${rankOf(s)}`, `
    <div class="field"><span class="label">Motif</span>${picker('reason', REASONS, '')}</div>
    <div class="field"><span class="label">Photo (porte, boîte, avis de passage)</span><div id="fPhotos">${photoTiles(photos, 'f')}</div></div>
    <div class="field"><label for="fNote">Remarque</label><input class="input" id="fNote" placeholder="Ex. : avis de passage laissé dans la boîte"></div>
    <label class="switch" for="fRes"><span>À reprogrammer</span><input type="checkbox" id="fRes" checked></label>
    <div class="warnbox" id="fWarn" hidden></div>
    <button class="btn big bad" id="fSave">Enregistrer l'échec</button>`, sh => {
    const refresh = () => { $('#fPhotos', sh).innerHTML = photoTiles(photos, 'f'); bind(); };
    const bind = () => {
      const add = $('#fAdd', sh); add && add.addEventListener('click', () => pickPhoto(async f => { const b = await shrink(f, 1600); photos.push({ blob: b, url: URL.createObjectURL(b) }); refresh(); }));
      sh.querySelectorAll('#fPhotos [data-rm]').forEach(b => b.addEventListener('click', () => { photos.splice(+b.dataset.rm, 1); refresh(); }));
    };
    bind(); currentPos().then(p => { gps = p; });
    $('#fSave', sh).addEventListener('click', async e => {
      const reason = getPick(sh, 'reason'), w = $('#fWarn', sh); if (!reason) { w.textContent = 'Choisissez un motif.'; w.hidden = false; return; }
      e.target.disabled = true;
      try {
        const paths = await uploadAll(photos.map(p => p.blob), 'jpg', t.owner);
        await Api.driverUpdateStop(s.id, { status: 'failed', fail_reason: reason, reschedule: $('#fRes', sh).checked, done_at: nowIso(), arrived_at: arrived, proof: { photos: paths, note: $('#fNote', sh).value.trim(), gps: gps ? { lat: gps.lat, lng: gps.lng, acc: gps.acc } : null, at: nowIso() } });
        closeSheet(); afterStop(s, false);
      } catch (err) { e.target.disabled = false; w.textContent = 'Envoi impossible : ' + (err.message || 'réseau'); w.hidden = false; }
    });
  });
}
function afterStop(s, ok) {
  const a = A(s), had = visibleEls(a.id).length;
  resetTo('tour'); toast(`Arrêt ${rankOf(s)} ${ok ? 'livré' : 'en échec'}`);
  if (ok && had) {
    openSheet('La fiche était juste ?', `<p class="note">Vos réponses gardent les fiches à jour pour les autres livreurs.</p><p class="brief-sum">${esc(summary(a.id))}</p>
      <div class="btnrow"><button class="btn ok" id="fbYes">Oui, c'était juste</button><button class="btn bad" id="fbNo">Non, à corriger</button></div>
      <button class="btn ghost" data-act="close-sheet">Plus tard</button>`, sh => {
      $('#fbYes', sh).addEventListener('click', async () => { closeSheet(); for (const e of visibleEls(a.id)) if (!myVotes[e.id]) { myVotes[e.id] = 'up'; await Api.driverVote(e.id, 1, 0).catch(() => {}); } saveVotes(); render(); toast('Merci, fiche confirmée'); });
      $('#fbNo', sh).addEventListener('click', () => { closeSheet(); textSheet(a.id, s.id, { title: 'Corriger la fiche', lead: "Qu'est-ce qui a changé ? Votre note passe en premier. Votez « faux » sur l'ancienne info si elle ne vaut plus rien.", tag: 'Autre' }); });
    });
  } else if (ok && !had) {
    openSheet('Laisser une info pour la prochaine fois ?', `<p class="note">Cette adresse n'a pas encore de fiche. Dix secondes suffisent : code, entrée, place pour se garer.</p>
      <div class="add-row"><button class="btn" data-act="add-photo" data-id="${a.id}" data-stop="${s.id}">${ICON.camera}Photo</button><button class="btn" data-act="add-voice" data-id="${a.id}" data-stop="${s.id}">${ICON.mic}Vocal</button><button class="btn" data-act="add-text" data-id="${a.id}" data-stop="${s.id}">${ICON.note}Note</button></div>
      <button class="btn ghost" data-act="close-sheet">Pas maintenant</button>`);
  }
}

/* arrival banner */
function showBrief(s) {
  const a = A(s); const b = $('#banner');
  b.innerHTML = `<div class="brief" role="alert"><div class="stripe" aria-hidden="true"></div><div class="brief-body"><span class="eyebrow">Arrivée · arrêt ${rankOf(s)} · ${street(a)}</span>${s.driver_note ? `<p><b>Consigne :</b> ${esc(s.driver_note)}</p>` : ''}<p class="brief-sum">${esc(summary(a.id) || "Pas de fiche pour cette adresse. Pensez à en laisser une.")}</p>
    <div class="btnrow"><button class="btn primary" data-act="brief-open" data-id="${s.id}">Voir la fiche</button><button class="btn" data-act="brief-close">Fermer</button></div></div></div>`;
  b.hidden = false; clearTimeout(showBrief.t); showBrief.t = setTimeout(() => { b.hidden = true; }, 25000);
  if (ls.get('dm-voice', '1') === '1') speak(briefingText(s));
}
function openViewer(src, cap) {
  const v = $('#viewer');
  v.innerHTML = `<img alt="${esc(cap || 'Photo')}" src="${src}"><div class="viewer-bar"><span style="flex:1;min-width:0">${esc(cap || '')}</span><button class="iconbtn" data-act="close-viewer" aria-label="Fermer">${ICON.close}</button></div>`;
  v.hidden = false;
}
/* ---------- dispatcher sheets ---------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
const driverOptions = sel => `<option value="">Aucun livreur</option>${Object.values(C.drivers).filter(d => d.active !== false || d.id === sel).sort((a, b) => a.name.localeCompare(b.name)).map(d => `<option value="${d.id}" ${d.id === sel ? 'selected' : ''}>${esc(d.name)}${d.vehicle ? ' · ' + esc(d.vehicle) : ''}</option>`).join('')}`;
function parseCoords(s) {
  const m = String(s || '').match(/(-?\d{1,2}\.\d+)\s*[,; ]\s*(-?\d{1,3}\.\d+)/); if (!m) return null;
  const lat = +m[1], lng = +m[2]; return Math.abs(lat) <= 90 && Math.abs(lng) <= 180 ? { lat, lng } : null;
}
function parseWindow(s) {
  s = String(s || '').trim(); if (!s) return [null, null];
  const f = (h, mm) => `${String(+h).padStart(2, '0')}:${mm || '00'}`;
  let m = s.match(/(\d{1,2})\s*[h:.]\s*(\d{2})?\s*(?:-|–|—|à|a|>|\/)\s*(\d{1,2})\s*[h:.]?\s*(\d{2})?/i); if (m) return [f(m[1], m[2]), f(m[3], m[4])];
  m = s.match(/avant\s*(\d{1,2})\s*[h:.]?\s*(\d{2})?/i); if (m) return [null, f(m[1], m[2])];
  m = s.match(/apr[eè]s\s*(\d{1,2})\s*[h:.]?\s*(\d{2})?/i); if (m) return [f(m[1], m[2]), null];
  return [null, null];
}
const truthy = v => /^(1|oui|yes|y|x|haute|high|urgent|vrai|true)/i.test(String(v || '').trim());
const num = v => { const n = parseFloat(String(v ?? '').replace(',', '.')); return isNaN(n) ? null : n; };
const timeVal = v => { const m = String(v || '').match(/(\d{1,2})\s*[h:.]\s*(\d{2})?/); return m ? `${String(+m[1]).padStart(2, '0')}:${m[2] || '00'}` : null; };

async function addRows(tid, rows, prog) {
  const list = []; let known = 0, missing = 0;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i]; if (!r.label || !r.label.trim()) continue;
    prog && (prog.textContent = `Adresse ${i + 1}/${rows.length}…`);
    const { addr, known: k } = await Api.ensureAddress({ label: r.label, lat: r.lat, lng: r.lng, client: r.client, phone: r.phone });
    if (k) known++;
    if (!hasXY(addr)) {
      const p = IN_CLAUDE ? null : await geocode(r.label);
      if (p) await Api.updateAddress(addr.id, { lat: p.lat, lng: p.lng }); else missing++;
      if (p && i < rows.length - 1) await sleep(1000);
    }
    list.push({ address_id: addr.id, raw: r.label, client: r.client || addr.client || '', phone: r.phone || addr.phone || '', ref: r.ref || '', notes: r.notes || '', driver_note: r.driver_note || '', win_start: r.win_start || null, win_end: r.win_end || null, service_min: r.service_min ?? 4, priority: r.priority ? 1 : 0, weight_kg: r.weight_kg ?? null });
  }
  const stops = list.length ? await Api.addStops(tid, list) : [];
  return { n: list.length, known, missing, stops };
}
function addedToast(res) { toast(`${res.n} arrêt${res.n > 1 ? 's' : ''} ajouté${res.n > 1 ? 's' : ''}${res.known ? ` · ${res.known} adresse${res.known > 1 ? 's' : ''} déjà connue${res.known > 1 ? 's' : ''}` : ''}${res.missing ? ` · ${res.missing} sans position` : ''}`, 4200); }

/* new tour */
function newTourSheet(opts = {}) {
  const last = Object.values(C.tours).filter(t => !t.is_template).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0];
  const depot = last?.depot || { label: 'Dépôt', lat: 50.8618, lng: 4.3779 };
  openSheet('Nouvelle tournée', `
    <div class="field"><label for="nName">Nom</label><input class="input" id="nName" value="Tournée du ${esc(new Date().toLocaleDateString('fr-BE', { day: 'numeric', month: 'long' }))}"></div>
    <div class="grid2"><div class="field"><label for="nDay">Date</label><input class="input" type="date" id="nDay" value="${todayIso()}"></div><div class="field"><label for="nStart">Départ</label><input class="input" type="time" id="nStart" value="${hm(last?.start_time) || '08:00'}"></div></div>
    <div class="field"><label for="nDriver">Livreur</label><select class="input" id="nDriver">${driverOptions('')}</select></div>
    <p class="small muted">Dépôt : ${esc(depot.label)}. Modifiable ensuite dans les réglages de la tournée.</p>
    <button class="btn big primary" id="nGo">Créer la tournée</button>`, sh => {
    $('#nGo', sh).addEventListener('click', async e => {
      e.target.disabled = true; const did = $('#nDriver', sh).value, d = C.drivers[did];
      try {
        const t = await Api.createTour({ name: $('#nName', sh).value.trim() || 'Tournée', day: $('#nDay', sh).value || todayIso(), start_time: $('#nStart', sh).value || '08:00', depot, driver_id: did || null, driver_name: d ? d.name : '', capacity_kg: d ? d.capacity_kg : null });
        closeSheet(); go('dtour', { id: t.id }); addStopsSheet(t.id, opts.tab || 'form');
      } catch (err) { e.target.disabled = false; toast('Création impossible : ' + err.message); }
    });
  });
}

/* add stops: form, paste, file, address book, other tour */
const IMPORT_FIELDS = [
  ['label', 'Adresse', ['adresse', 'address', 'rue', 'street', 'adres', 'destination', 'lieu', 'adresse de livraison']],
  ['num', 'Numéro (colonne séparée)', ['numero', 'n°', 'no', 'num', 'number', 'huisnummer', 'nr']],
  ['pc', 'Code postal', ['code postal', 'cp', 'postal', 'zip', 'postcode', 'code_postal']],
  ['city', 'Ville / commune', ['ville', 'city', 'commune', 'localite', 'gemeente', 'stad']],
  ['client', 'Client', ['client', 'nom', 'name', 'customer', 'destinataire', 'societe', 'entreprise', 'klant']],
  ['phone', 'Téléphone', ['telephone', 'tel', 'gsm', 'phone', 'mobile', 'portable']],
  ['window', 'Créneau (texte « 9h-11h »)', ['creneau', 'plage', 'slot', 'window', 'horaire']],
  ['win_start', 'Début du créneau', ['debut', 'from', 'heure debut', 'start', 'van']],
  ['win_end', 'Fin du créneau', ['fin', 'to', 'heure fin', 'end', 'tot']],
  ['service_min', 'Durée sur place (min)', ['duree', 'service', 'temps sur place']],
  ['weight_kg', 'Poids (kg)', ['poids', 'weight', 'kg', 'gewicht']],
  ['ref', 'Référence', ['reference', 'ref', 'commande', 'order', 'bon', 'n° commande']],
  ['notes', 'Colis / contenu', ['colis', 'contenu', 'articles', 'description', 'package', 'marchandise']],
  ['driver_note', 'Consigne pour le livreur', ['consigne', 'note', 'instructions', 'remarque', 'commentaire', 'comment', 'opmerking']],
  ['priority', 'Priorité', ['priorite', 'priority', 'urgent', 'prio']],
];
const normH = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[_]+/g, ' ').trim();
function guessMapping(headers) {
  const H = headers.map(normH), used = new Set(), map = {};
  for (const pass of ['exact', 'includes']) for (const [f, , syn] of IMPORT_FIELDS) {
    if (map[f] != null) continue;
    const i = H.findIndex((h, k) => !used.has(k) && syn.some(s => pass === 'exact' ? h === s : (h.includes(s) && s.length > 2)));
    if (i >= 0) { map[f] = i; used.add(i); }
  }
  if (map.label == null) { const i = H.findIndex((h, k) => !used.has(k)); if (i >= 0) map.label = i; }
  return map;
}
function parseCSV(text) {
  text = text.replace(/^﻿/, ''); const first = text.split(/\r?\n/)[0] || '';
  const d = [';', '\t', ','].map(c => [c, first.split(c).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
    else if (ch === '"') q = true; else if (ch === d) { row.push(f); f = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(f); f = ''; if (row.some(x => x.trim())) rows.push(row); row = []; }
    else f += ch;
  }
  row.push(f); if (row.some(x => x.trim())) rows.push(row);
  return rows;
}
async function readTable(file) {
  if (file.size > 5 * 1024 * 1024) throw new Error('trop_gros');
  if (/\.xls$/i.test(file.name)) throw new Error('xls');
  if (/\.xlsx$/i.test(file.name) || /spreadsheetml/.test(file.type)) {
    await loadScript(ASSETS.xlsx);
    const f = window.readXlsxFile; const fn = typeof f === 'function' ? f : (f && (f.readSheet || f.default));
    let rows = await fn(file); if (rows && rows.rows) rows = rows.rows; if (Array.isArray(rows) && rows[0] && Array.isArray(rows[0].data)) rows = rows[0].data;
    const cell = v => v instanceof Date ? (v.getUTCFullYear() < 1901 ? `${String(v.getUTCHours()).padStart(2, '0')}:${String(v.getUTCMinutes()).padStart(2, '0')}` : v.toISOString().slice(0, 10)) : v == null ? '' : String(v);
    return rows.map(r => r.map(cell)).filter(r => r.some(x => x.trim())).slice(0, 2001);
  }
  return parseCSV(await file.text()).slice(0, 2001);
}
function rowFromMapping(r, map) {
  const g = f => map[f] != null ? String(r[map[f]] ?? '').trim() : '';
  let label = g('label'); const n = g('num'), pc = g('pc'), city = g('city');
  if (n && !new RegExp('\\b' + n.replace(/[^\w]/g, '') + '\\b').test(label)) label += ' ' + n;
  if ((pc || city) && !/\b[1-9]\d{3}\b/.test(label)) label += ', ' + [pc, city].filter(Boolean).join(' ');
  let [ws, we] = parseWindow(g('window')); ws = timeVal(g('win_start')) || ws; we = timeVal(g('win_end')) || we;
  return { label: label.trim(), client: g('client'), phone: g('phone'), win_start: ws, win_end: we, service_min: Math.round(num(g('service_min')) ?? 4), weight_kg: num(g('weight_kg')), ref: g('ref'), notes: g('notes'), driver_note: g('driver_note'), priority: truthy(g('priority')) };
}
function addStopsSheet(tid, tab = 'form') {
  const tabs = [['form', 'Saisie'], ['scan', 'Photo'], ['paste', 'Coller'], ['file', 'Fichier'], ['book', 'Carnet'], ['tour', 'Autre tournée']];
  const labels = [...new Set(Object.values(C.addresses).map(a => a.label))].slice(0, 500);
  openSheet('Ajouter des arrêts', `<div class="seg" role="tablist">${tabs.map(([k, l]) => `<button type="button" data-tab="${k}" aria-pressed="${k === tab}">${l}</button>`).join('')}</div><div id="addBody" style="display:flex;flex-direction:column;gap:14px"></div>
    <datalist id="addrList">${labels.map(l => `<option value="${esc(l)}"></option>`).join('')}</datalist>`, sh => {
    const body = $('#addBody', sh);
    const show = k => { sh.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-pressed', b.dataset.tab === k)); (ADD_TABS[k] || ADD_TABS.form)(body, tid, sh); };
    sh.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => show(b.dataset.tab)));
    show(tab);
  });
}
const stopFormHtml = (s = {}, withAddr = true) => `
  ${withAddr ? `<div class="field"><label for="fAddr">Adresse</label><input class="input" id="fAddr" list="addrList" placeholder="Rue, numéro, code postal, commune" value="${esc(s.label || '')}" autocomplete="off"><div class="btnrow"><button type="button" class="btn ghost" id="fHere">${ICON.target} Ma position actuelle</button></div></div>` : ''}
  <div class="grid2"><div class="field"><label for="fClient">Client</label><input class="input" id="fClient" value="${esc(s.client || '')}"></div><div class="field"><label for="fPhone">Téléphone</label><input class="input" id="fPhone" type="tel" value="${esc(s.phone || '')}"></div></div>
  <div class="grid2"><div class="field"><label for="fWs">Créneau de</label><input class="input" type="time" id="fWs" value="${esc(hm(s.win_start))}"></div><div class="field"><label for="fWe">à</label><input class="input" type="time" id="fWe" value="${esc(hm(s.win_end))}"></div></div>
  <div class="grid2"><div class="field"><label for="fSvc">Sur place (min)</label><input class="input" type="number" min="0" max="240" id="fSvc" value="${esc(s.service_min ?? 4)}"></div><div class="field"><label for="fKg">Poids (kg)</label><input class="input" type="number" min="0" step="0.1" id="fKg" value="${esc(s.weight_kg ?? '')}"></div></div>
  <div class="grid2"><div class="field"><label for="fRef">Référence</label><input class="input" id="fRef" value="${esc(s.ref || '')}"></div><div class="field"><label for="fPrio">Priorité</label><select class="input" id="fPrio"><option value="0">Normale</option><option value="1" ${+s.priority ? 'selected' : ''}>Haute</option></select></div></div>
  <div class="field"><label for="fNotes">Colis</label><input class="input" id="fNotes" value="${esc(s.notes || '')}" placeholder="Ex. : 2 cartons, fragile"></div>
  <div class="field"><label for="fDn">Consigne pour le livreur</label><input class="input" id="fDn" value="${esc(s.driver_note || '')}" placeholder="Affichée et lue à voix haute à l'arrivée"></div>`;
const readStopForm = sh => ({ client: $('#fClient', sh).value.trim(), phone: $('#fPhone', sh).value.trim(), win_start: $('#fWs', sh).value || null, win_end: $('#fWe', sh).value || null, service_min: Math.round(num($('#fSvc', sh).value) ?? 4), weight_kg: num($('#fKg', sh).value), ref: $('#fRef', sh).value.trim(), priority: +$('#fPrio', sh).value, notes: $('#fNotes', sh).value.trim(), driver_note: $('#fDn', sh).value.trim() });
const ADD_TABS = {
  form(body, tid) {
    let here = null;
    body.innerHTML = `${stopFormHtml()}<p class="small muted" id="fProg"></p><div class="btnrow"><button class="btn" id="fMore">Ajouter et continuer</button><button class="btn primary" id="fDone">Ajouter et fermer</button></div>`;
    const addr = $('#fAddr', body);
    addr.addEventListener('change', () => { const a = Object.values(C.addresses).find(x => x.label === addr.value); if (a) { if (!$('#fClient', body).value) $('#fClient', body).value = a.client || ''; if (!$('#fPhone', body).value) $('#fPhone', body).value = a.phone || ''; } here = null; });
    $('#fHere', body).addEventListener('click', async () => { const p = await currentPos(); if (!p) { toast('Position indisponible ici.'); return; } here = p; addr.value = `Position GPS ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}`; });
    const submit = async close => {
      if (!addr.value.trim()) { addr.focus(); toast('Indiquez une adresse.'); return; }
      const row = { label: addr.value.trim(), ...readStopForm(body), ...(here ? { lat: here.lat, lng: here.lng } : {}) };
      const res = await addRows(tid, [row], $('#fProg', body)); addedToast(res);
      if (close) { closeSheet(); if (res.stops[0]) { go('dstop', { id: res.stops[0].id }); toast('Arrêt ajouté. Complétez la fiche terrain : photos du chemin, vocal, notes.', 4200); } else render(); } else { ADD_TABS.form(body, tid); render(); setTimeout(() => $('#fAddr', body)?.focus(), 50); }
    };
    $('#fMore', body).addEventListener('click', () => submit(false)); $('#fDone', body).addEventListener('click', () => submit(true));
  },
  scan(body, tid) {
    let text = '', found = [], pages = 0, busy = false;
    body.innerHTML = `<p class="note">Photographiez un bon de livraison, une liste d'adresses ou des étiquettes. Le texte est lu sur ce téléphone : l'image n'est envoyée nulle part et n'est pas gardée. Vous vérifiez les adresses avant de les ajouter.</p>
      <div class="scan-btns"><button class="btn big primary" id="sCam">${ICON.camera} Prendre en photo</button><button class="btn big" id="sGal">${ICON.upload} Choisir des images</button></div>
      <input type="file" accept="image/*" capture="environment" id="sCamIn" hidden><input type="file" accept="image/*" multiple id="sGalIn" hidden>
      <p class="small muted" id="sProg" aria-live="polite"></p><div id="sRes" style="display:flex;flex-direction:column;gap:12px"></div>`;
    const prog = $('#sProg', body), res = $('#sRes', body);
    const read = () => { $$('.scan-row', res).forEach((r, n) => { if (!found[n]) return; found[n].on = $('input[type=checkbox]', r).checked; r.querySelectorAll('[data-k]').forEach(i => { found[n][i.dataset.k] = i.value.trim(); }); }); };
    const draw = () => {
      const on = found.filter(f => f.on !== false).length;
      res.innerHTML = `${found.length ? `<span class="label">${found.length} adresse${found.length > 1 ? 's' : ''} trouvée${found.length > 1 ? 's' : ''} sur ${pages} page${pages > 1 ? 's' : ''}</span>
        <div class="mini-list">${found.map((f, n) => `<div class="checkrow scan-row"><input type="checkbox" id="sc_${n}" ${f.on !== false ? 'checked' : ''} aria-label="Garder cette adresse"><div style="flex:1;display:flex;flex-direction:column;gap:6px;min-width:0">
          <input class="input" data-k="label" value="${esc(f.label)}" aria-label="Adresse"><div class="grid2"><input class="input" data-k="client" value="${esc(f.client)}" placeholder="Client" aria-label="Client"><input class="input" data-k="phone" type="tel" value="${esc(f.phone)}" placeholder="Téléphone" aria-label="Téléphone"></div></div></div>`).join('')}</div>`
        : pages ? '<div class="empty">Aucune adresse reconnue. Reprenez la photo bien à plat, de près et avec de la lumière, ou corrigez le texte lu ci-dessous.</div>' : ''}
        ${pages ? `<details${found.length ? '' : ' open'}><summary class="small">Texte lu (vous pouvez le corriger)</summary><textarea class="input" id="sText" style="min-height:160px;margin-top:8px">${esc(text)}</textarea><button class="btn" id="sRe" style="margin-top:8px">Relire les adresses</button></details>` : ''}
        ${found.length ? `<p class="small muted" id="sAddProg"></p><button class="btn big primary" id="sGo" ${on ? '' : 'disabled'}>Ajouter ${on} arrêt${on > 1 ? 's' : ''}</button>` : ''}`;
      res.querySelectorAll('.scan-row input[type=checkbox]').forEach(c => c.addEventListener('change', () => { read(); const k = found.filter(f => f.on !== false).length; const b = $('#sGo', res); b.textContent = `Ajouter ${k} arrêt${k > 1 ? 's' : ''}`; b.disabled = !k; }));
      $('#sRe', res)?.addEventListener('click', () => { text = $('#sText', res).value; found = extractStops(text); draw(); });
      $('#sGo', res)?.addEventListener('click', async e => {
        read(); const rows = found.filter(f => f.on !== false && f.label).map(f => ({ label: f.label, client: f.client, phone: f.phone }));
        if (!rows.length) return; e.target.disabled = true;
        const r = await addRows(tid, rows, $('#sAddProg', res)); closeSheet(); render(); addedToast(r);
      });
    };
    const run = async files => {
      if (!files.length || busy) return; busy = true; read();
      $('#sCam', body).disabled = $('#sGal', body).disabled = true;
      try {
        for (const [n, f] of [...files].entries()) {
          if (f.size > 25e6) { toast('Image trop lourde.'); continue; }
          const lab = files.length > 1 ? `Image ${n + 1}/${files.length} · ` : '';
          prog.textContent = lab + 'Préparation…';
          const t = await ocrImage(f, (st, p) => { if (st) prog.textContent = `${lab}${st}${p ? ' · ' + Math.round(p * 100) + ' %' : ''}`; });
          text = (text ? text + '\n\n' : '') + t.trim(); pages++;
        }
        const keep = found.filter(f => f.on === false).map(f => normH(f.label)), edits = new Map(found.map(f => [normH(f.label), f]));
        found = extractStops(text).map(f => edits.get(normH(f.label)) || { ...f, on: !keep.includes(normH(f.label)) });
        prog.textContent = found.length ? 'Vérifiez les adresses, puis ajoutez-les. Vous pouvez photographier une autre page.' : '';
      } catch (err) {
        console.warn(err); prog.textContent = '';
        toast(IN_CLAUDE ? "La lecture de document est bloquée dans l'aperçu Claude ; elle marche dans la version hébergée." : 'Lecture impossible sur ce téléphone. Réessayez avec une autre photo ou utilisez « Coller ».', 5000);
      } finally { busy = false; $('#sCam', body).disabled = $('#sGal', body).disabled = false; draw(); }
    };
    const pick = id => { const i = $(id, body); i.value = ''; i.onchange = () => run(i.files); i.click(); };
    $('#sCam', body).addEventListener('click', () => pick('#sCamIn')); $('#sGal', body).addEventListener('click', () => pick('#sGalIn'));
  },
  paste(body, tid) {
    body.innerHTML = `<div class="field"><label for="pLines">Une adresse par ligne</label><textarea class="input" id="pLines" style="min-height:170px" placeholder="Rue de la Loi 16, 1000 Bruxelles ; Cabinet Dupont ; 0470 00 00 00 ; 9h-11h ; 2 cartons ; 12&#10;Av. Louise 143/4, 1050 Bruxelles"></textarea>
      <span class="hint">Après l'adresse, facultatif, séparés par « ; » : client, téléphone, créneau, colis, poids. Un copier-coller depuis Excel marche aussi.</span></div>
      <p class="small muted" id="pProg"></p><button class="btn big primary" id="pGo">Ajouter à la tournée</button>`;
    $('#pGo', body).addEventListener('click', async e => {
      const lines = $('#pLines', body).value.split(/\n+/).map(l => l.trim()).filter(Boolean); if (!lines.length) { toast('Collez au moins une adresse.'); return; }
      e.target.disabled = true;
      const rows = lines.map(l => { const p = (l.includes(';') || !l.includes('\t') ? l.split(';') : l.split('\t')).map(x => x.trim()); const [ws, we] = parseWindow(p[3]); return { label: p[0], client: p[1] || '', phone: p[2] || '', win_start: ws, win_end: we, notes: p[4] || '', weight_kg: num(p[5]) }; });
      const res = await addRows(tid, rows, $('#pProg', body)); closeSheet(); render(); addedToast(res);
    });
  },
  file(body, tid) {
    body.innerHTML = `<p class="note">Fichier Excel (.xlsx) ou CSV, une ligne par livraison. La première ligne doit contenir les titres des colonnes. Les colonnes sont reconnues automatiquement, vous pouvez corriger.</p>
      <button class="btn big" id="iPick">${ICON.upload} Choisir un fichier</button><div id="iMap" style="display:flex;flex-direction:column;gap:12px"></div>`;
    $('#iPick', body).addEventListener('click', () => { UI.onData = async f => {
      let rows; try { rows = await readTable(f); } catch (err) { toast(err.message === 'trop_gros' ? 'Fichier trop lourd (5 Mo maximum).' : err.message === 'xls' ? 'Ancien format .xls : enregistrez-le en .xlsx ou .csv.' : 'Fichier illisible. Enregistrez-le en .xlsx ou .csv.', 4500); return; }
      if (rows.length < 2) { toast('Le fichier ne contient pas de lignes à importer.'); return; }
      const head = rows[0].map(String), data = rows.slice(1), map = guessMapping(head);
      const box = $('#iMap', body);
      const preview = () => { const ex = data.slice(0, 3).map(r => rowFromMapping(r, map));
        $('#iPrev', box).innerHTML = `<table><thead><tr><th>Adresse</th><th>Client</th><th>Créneau</th><th>Poids</th></tr></thead><tbody>${ex.map(x => `<tr><td>${esc(x.label)}</td><td>${esc(x.client)}</td><td>${esc(winText(x))}</td><td>${x.weight_kg ?? ''}</td></tr>`).join('')}</tbody></table>`; };
      box.innerHTML = `<p><b>${esc(f.name)}</b> · ${data.length} ligne${data.length > 1 ? 's' : ''}</p>
        ${IMPORT_FIELDS.map(([k, l]) => `<div class="field"><label for="m_${k}">${l}</label><select class="input" id="m_${k}" data-f="${k}"><option value="">Ne pas utiliser</option>${head.map((h, i) => `<option value="${i}" ${map[k] === i ? 'selected' : ''}>${esc(h || 'Colonne ' + (i + 1))}</option>`).join('')}</select></div>`).join('')}
        <span class="label">Aperçu</span><div class="preview-table" id="iPrev"></div><p class="small muted" id="iProg"></p>
        <button class="btn big primary" id="iGo">Importer ${data.length} arrêt${data.length > 1 ? 's' : ''}</button>`;
      box.querySelectorAll('select[data-f]').forEach(s => s.addEventListener('change', () => { if (s.value === '') delete map[s.dataset.f]; else map[s.dataset.f] = +s.value; preview(); }));
      preview();
      $('#iGo', box).addEventListener('click', async e => {
        if (map.label == null) { toast('Choisissez la colonne Adresse.'); return; } e.target.disabled = true;
        const res = await addRows(tid, data.map(r => rowFromMapping(r, map)), $('#iProg', box)); closeSheet(); render(); addedToast(res);
      });
    }; const i = $('#fileData'); i.value = ''; i.click(); });
  },
  book(body, tid) {
    const sel = new Set(); let q = '';
    const inTour = new Set(stopsOf(tid).map(s => s.address_id));
    const draw = () => {
      const nq = normH(q); const list = Object.values(C.addresses).filter(a => !nq || normH(a.label + ' ' + (a.client || '')).includes(nq)).sort((a, b) => (b.visits || 0) - (a.visits || 0)).slice(0, 150);
      $('#bList', body).innerHTML = list.length ? list.map(a => `<div class="checkrow"><input type="checkbox" id="b_${a.id}" data-id="${a.id}" ${sel.has(a.id) ? 'checked' : ''}><label for="b_${a.id}"><b>${street(a)}</b><span class="small muted">${pcCity(a)}${a.client ? ' · ' + esc(a.client) : ''}${inTour.has(a.id) ? ' · déjà dans la tournée' : ''}</span><span class="chips">${ficheChips(a)}</span></label></div>`).join('') : '<div class="empty">Aucune adresse.</div>';
      $('#bList', body).querySelectorAll('input').forEach(i => i.addEventListener('change', () => { i.checked ? sel.add(i.dataset.id) : sel.delete(i.dataset.id); $('#bGo', body).textContent = `Ajouter ${sel.size} adresse${sel.size > 1 ? 's' : ''}`; $('#bGo', body).disabled = !sel.size; }));
    };
    body.innerHTML = `<label class="search">${ICON.search}<input id="bQ" type="search" placeholder="Rechercher dans le carnet" aria-label="Rechercher"></label><div class="mini-list" id="bList"></div><button class="btn big primary" id="bGo" disabled>Ajouter 0 adresse</button>`;
    $('#bQ', body).addEventListener('input', e => { q = e.target.value; draw(); }); draw();
    $('#bGo', body).addEventListener('click', async () => { const list = [...sel].map(id => C.addresses[id]).map(a => ({ address_id: a.id, raw: a.label, client: a.client || '', phone: a.phone || '' })); await Api.addStops(tid, list); closeSheet(); render(); toast(`${list.length} arrêt${list.length > 1 ? 's' : ''} ajouté${list.length > 1 ? 's' : ''} depuis le carnet`); });
  },
  async tour(body, tid) {
    const others = Object.values(C.tours).filter(t => t.id !== tid).sort((a, b) => (b.is_template - a.is_template) || String(b.day).localeCompare(String(a.day)));
    body.innerHTML = `<div class="field"><label for="oT">Reprendre les arrêts de</label><select class="input" id="oT"><option value="">Choisir une tournée ou un modèle</option>${others.map(t => `<option value="${t.id}">${t.is_template ? 'Modèle · ' : esc(fmtShort(t.day)) + ' · '}${esc(t.name)}</option>`).join('')}</select></div><div class="mini-list" id="oList" hidden></div><button class="btn big primary" id="oGo" disabled>Ajouter</button>`;
    const sel = new Set();
    $('#oT', body).addEventListener('change', async e => {
      const id = e.target.value; sel.clear(); const box = $('#oList', body); if (!id) { box.hidden = true; return; }
      if (MODE === 'supabase') await Api.loadTour(id);
      const ss = stopsOf(id); ss.forEach(s => sel.add(s.id)); box.hidden = false;
      box.innerHTML = ss.map(s => `<div class="checkrow"><input type="checkbox" id="o_${s.id}" data-id="${s.id}" checked><label for="o_${s.id}"><b>${street(A(s))}</b><span class="small muted">${esc(s.client || '')}${winText(s) ? ' · ' + esc(winText(s)) : ''}</span></label></div>`).join('') || '<div class="empty">Pas d’arrêts.</div>';
      const upd = () => { $('#oGo', body).textContent = `Ajouter ${sel.size} arrêt${sel.size > 1 ? 's' : ''}`; $('#oGo', body).disabled = !sel.size; };
      box.querySelectorAll('input').forEach(i => i.addEventListener('change', () => { i.checked ? sel.add(i.dataset.id) : sel.delete(i.dataset.id); upd(); })); upd();
    });
    $('#oGo', body).addEventListener('click', async () => { const list = [...sel].map(id => C.stops[id]).sort((a, b) => a.rank - b.rank).map(s => { const o = {}; STOP_FIELDS.forEach(f => { o[f] = s[f]; }); o.locked = false; return o; }); await Api.addStops(tid, list); closeSheet(); render(); toast(`${list.length} arrêt${list.length > 1 ? 's' : ''} repris`); });
  },
};

/* coordinates editor, with a real map on the hosted version */
function coordsHtml(a, id = 'cXY') {
  return `<div class="field"><label for="${id}">Position (latitude, longitude)</label><input class="input num" id="${id}" value="${hasXY(a) ? `${(+a.lat).toFixed(6)}, ${(+a.lng).toFixed(6)}` : ''}" placeholder="50.846, 4.352 (copié depuis Google Maps)">
    <div class="btnrow"><button type="button" class="btn ghost" id="${id}Geo">${ICON.search} Localiser l'adresse</button><button type="button" class="btn ghost" id="${id}Here">${ICON.target} Ma position</button></div>
    ${IN_CLAUDE ? '' : `<div class="mapbox" id="${id}Map" style="height:220px"></div><span class="hint">Touchez la carte pour placer le point exact (entrée, quai, portail).</span>`}</div>`;
}
function bindCoords(sh, a, labelGetter, id = 'cXY') {
  const input = $('#' + id, sh); let marker = null, map = null;
  const setXY = p => { input.value = `${p.lat.toFixed(6)}, ${p.lng.toFixed(6)}`; if (map) { if (marker) marker.setLatLng([p.lat, p.lng]); else marker = window.L.marker([p.lat, p.lng]).addTo(map); map.setView([p.lat, p.lng], Math.max(map.getZoom(), 17)); } };
  $('#' + id + 'Geo', sh).addEventListener('click', async () => { const p = IN_CLAUDE ? null : await geocode(labelGetter()); if (p) setXY(p); else toast(IN_CLAUDE ? "La recherche d'adresse marche sur la version hébergée. Collez les coordonnées depuis Google Maps." : 'Adresse non trouvée. Placez le point sur la carte.'); });
  $('#' + id + 'Here', sh).addEventListener('click', async () => { const p = await currentPos(); if (p) setXY(p); else toast('Position indisponible ici.'); });
  const box = $('#' + id + 'Map', sh);
  if (box) loadLeaflet().then(() => {
    const L = window.L; const c = hasXY(a) ? [a.lat, a.lng] : [50.85, 4.35];
    map = L.map(box).setView(c, hasXY(a) ? 17 : 12); L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
    if (hasXY(a)) marker = L.marker(c).addTo(map);
    map.on('click', e => setXY({ lat: e.latlng.lat, lng: e.latlng.lng }));
    setTimeout(() => map.invalidateSize(), 200);
  }).catch(() => { box.remove(); });
  return () => parseCoords(input.value);
}

/* edit one stop */
function stopEditSheet(id) {
  const s = C.stops[id]; if (!s) return; const a = A(s), t = C.tours[s.tour_id];
  const others = Object.values(C.tours).filter(x => x.id !== t.id && !x.is_template && x.status !== 'done');
  let confirmDel = false;
  openSheet(`Arrêt ${stopsOf(t.id).indexOf(s) + 1}`, `
    ${s.status !== 'todo' ? `<section class="card"><span class="eyebrow">${s.status === 'done' ? 'Livré' : 'Échec'}</span>${proofLine(s)}${proofThumbs(s)}<div><button class="btn ghost" id="eReset">Remettre à faire</button></div></section>` : ''}
    <div class="field"><label for="eAddr">Adresse</label><input class="input" id="eAddr" list="addrList2" value="${esc(a.label)}"><datalist id="addrList2">${Object.values(C.addresses).slice(0, 400).map(x => `<option value="${esc(x.label)}"></option>`).join('')}</datalist></div>
    ${coordsHtml(a)}
    ${stopFormHtml(s, false)}
    <label class="switch" for="eLock"><span>Fixer sa position dans la tournée (l'optimisation ne la bouge pas)</span><input type="checkbox" id="eLock" ${s.locked ? 'checked' : ''}></label>
    ${others.length ? `<div class="field"><label for="eMove">Déplacer vers une autre tournée</label><select class="input" id="eMove"><option value="">Garder dans cette tournée</option>${others.map(x => `<option value="${x.id}">${esc(fmtShort(x.day))} · ${esc(x.name)}</option>`).join('')}</select></div>` : ''}
    <button class="btn big primary" id="eSave">Enregistrer</button>
    <div id="eDelBox"><button class="btn ghost" id="eDel">${ICON.trash} Retirer l'arrêt</button></div>`, sh => {
    const getXY = bindCoords(sh, a, () => $('#eAddr', sh).value);
    $('#eReset', sh)?.addEventListener('click', async () => { await Api.updateStop(id, { status: 'todo', done_at: null, proof: null, fail_reason: null }); closeSheet(); render(); toast('Arrêt remis à faire'); });
    $('#eDel', sh).addEventListener('click', async () => {
      if (!confirmDel) { confirmDel = true; $('#eDelBox', sh).innerHTML = `<div class="inline-confirm"><b>Retirer cet arrêt de la tournée ?</b><span>L'adresse et sa fiche restent dans le carnet.</span><div class="btnrow"><button class="btn bad" id="eDelYes">Retirer</button><button class="btn" id="eDelNo">Annuler</button></div></div>`;
        $('#eDelYes', sh).addEventListener('click', async () => { await Api.deleteStops([id]); closeSheet(); render(); toast('Arrêt retiré'); });
        $('#eDelNo', sh).addEventListener('click', () => { closeSheet(); stopEditSheet(id); }); }
    });
    $('#eSave', sh).addEventListener('click', async e => {
      e.target.disabled = true;
      try {
        const patch = { ...readStopForm(sh), locked: $('#eLock', sh).checked };
        const label = $('#eAddr', sh).value.trim(), xy = getXY();
        if (label && label !== a.label) { const { addr } = await Api.ensureAddress({ label, lat: xy?.lat, lng: xy?.lng }); patch.address_id = addr.id; patch.raw = label; if (xy && !hasXY(addr)) await Api.updateAddress(addr.id, xy); }
        else if (xy && (!hasXY(a) || Math.abs(a.lat - xy.lat) > 1e-6 || Math.abs(a.lng - xy.lng) > 1e-6)) await Api.updateAddress(a.id, xy);
        await Api.updateStop(id, patch);
        const mv = $('#eMove', sh)?.value; if (mv) await Api.moveStops([id], mv);
        closeSheet(); render(); toast(mv ? 'Arrêt déplacé' : 'Arrêt enregistré');
      } catch (err) { e.target.disabled = false; toast('Enregistrement impossible : ' + err.message); }
    });
  });
}

/* tour settings */
function tourSettingsSheet(id) {
  const t = C.tours[id];
  openSheet('Réglages de la tournée', `
    <div class="field"><label for="tName">Nom</label><input class="input" id="tName" value="${esc(t.name)}"></div>
    <div class="grid2">${t.is_template ? '' : `<div class="field"><label for="tDay">Date</label><input class="input" type="date" id="tDay" value="${esc(t.day)}"></div>`}<div class="field"><label for="tStart">Départ</label><input class="input" type="time" id="tStart" value="${esc(hm(t.start_time))}"></div></div>
    <div class="grid2"><div class="field"><label for="tDriver">Livreur</label><select class="input" id="tDriver">${driverOptions(t.driver_id)}</select></div><div class="field"><label for="tCap">Capacité (kg)</label><input class="input" type="number" min="0" id="tCap" value="${esc(t.capacity_kg ?? '')}"></div></div>
    <div class="field"><label for="tDepot">Dépôt (point de départ)</label><input class="input" id="tDepot" value="${esc(t.depot?.label || '')}"></div>
    ${coordsHtml(t.depot || {}, 'dXY')}
    <label class="switch" for="tRet"><span>Retour au dépôt en fin de tournée</span><input type="checkbox" id="tRet" ${t.return_to_depot !== false ? 'checked' : ''}></label>
    <button class="btn big primary" id="tSave">Enregistrer</button>`, sh => {
    const getXY = bindCoords(sh, t.depot || {}, () => $('#tDepot', sh).value, 'dXY');
    $('#tDriver', sh).addEventListener('change', e => { const d = C.drivers[e.target.value]; if (d && d.capacity_kg && !$('#tCap', sh).value) $('#tCap', sh).value = d.capacity_kg; });
    $('#tSave', sh).addEventListener('click', async e => {
      e.target.disabled = true; const did = $('#tDriver', sh).value, d = C.drivers[did], xy = getXY();
      const patch = { name: $('#tName', sh).value.trim() || t.name, start_time: $('#tStart', sh).value || null, driver_id: did || null, driver_name: d ? d.name : (did ? t.driver_name : ''), capacity_kg: num($('#tCap', sh).value), return_to_depot: $('#tRet', sh).checked, depot: { label: $('#tDepot', sh).value.trim() || 'Dépôt', lat: xy ? xy.lat : t.depot?.lat ?? null, lng: xy ? xy.lng : t.depot?.lng ?? null } };
      if (!t.is_template) patch.day = $('#tDay', sh).value || t.day;
      try { await Api.updateTour(id, patch); closeSheet(); render(); toast('Réglages enregistrés'); } catch (err) { e.target.disabled = false; toast('Enregistrement impossible : ' + err.message); }
    });
  });
}

/* more actions */
function tourMoreSheet(id) {
  const t = C.tours[id], k = tourCounts(id); let confirmDel = false;
  const item = (act, icon, title, sub) => `<button class="row" data-act="${act}" data-id="${id}"><div class="row-body"><span class="row-title">${title}</span><span class="small muted">${sub}</span></div>${icon}</button>`;
  openSheet('Plus d’actions', `<div class="list">
    ${!t.is_template && t.status !== 'done' ? item('split', ICON.split, 'Répartir entre plusieurs livreurs', 'Découpe la tournée par secteurs, une tournée et un code par livreur') : ''}
    ${item('duplicate', ICON.copy, 'Dupliquer pour une autre date', 'Mêmes arrêts, mêmes créneaux, statuts remis à zéro')}
    ${!t.is_template ? item('save-template', ICON.stack, 'Enregistrer comme modèle', 'Pour recréer cette tournée chaque semaine en un geste') : ''}
    ${k.n > 1 ? item('order-mode', ICON.list, 'Réordonner à la main', 'Monter ou descendre chaque arrêt') : ''}
    ${t.status === 'published' || t.status === 'active' ? item('reset-code', ICON.key, 'Changer le code', "L'ancien code ne marche plus, les téléphones connectés perdent l'accès") : ''}
    ${t.status === 'published' && !t.started_at ? item('unpublish', ICON.edit, 'Repasser en brouillon', 'Le livreur ne peut plus ouvrir la tournée') : ''}
    ${k.done + k.failed ? item('open-report', ICON.file, 'Rapport et exports', 'CSV, PDF avec les photos de preuve, .zip') : ''}
    </div><div id="delBox"><button class="btn ghost" id="tDel">${ICON.trash} Supprimer ${t.is_template ? 'le modèle' : 'la tournée'}</button></div>`, sh => {
    $('#tDel', sh).addEventListener('click', () => {
      if (confirmDel) return; confirmDel = true;
      $('#delBox', sh).innerHTML = `<div class="inline-confirm"><b>Supprimer « ${esc(t.name)} » ?</b><span>Les arrêts et les preuves de cette tournée seront supprimés. Les adresses et leurs fiches restent dans le carnet.</span><div class="btnrow"><button class="btn bad" id="tDelYes">Supprimer</button><button class="btn" data-act="close-sheet">Annuler</button></div></div>`;
      $('#tDelYes', sh).addEventListener('click', async () => { await Api.deleteTour(id); closeSheet(); resetTo('dtours'); toast('Supprimée'); });
    });
  });
}

/* send to the driver: code, link, QR, WhatsApp */
function waNumber(p) { let d = String(p || '').replace(/[^\d+]/g, ''); if (d.startsWith('+')) return d.slice(1); if (d.startsWith('00')) return d.slice(2); if (d.startsWith('0')) return '32' + d.slice(1); return d; }
function shareCodeSheet(id) {
  const t = C.tours[id], d = C.drivers[t.driver_id], link = tourLink(t), k = tourCounts(id);
  const msg = `Bonjour${t.driver_name ? ' ' + t.driver_name : ''}, voici ta tournée du ${fmtDay(t.day)} : ${k.n} arrêt${k.n > 1 ? 's' : ''}, départ ${hm(t.start_time) || 'à confirmer'}.\n${IN_CLAUDE ? '' : `Ouvre ce lien : ${link}\nOu e`}${IN_CLAUDE ? 'E' : ''}ntre le code ${fmtCode(t.code)} dans l'appli.`;
  const wa = `https://wa.me/${d && d.phone ? waNumber(d.phone) : ''}?text=${encodeURIComponent(msg)}`;
  openSheet('Envoyer au livreur', `
    <div class="code-big">${fmtCode(t.code)}</div>
    ${IN_CLAUDE ? '' : `<div class="qr" id="qrBox" aria-label="QR code de la tournée"></div>
    <span class="label">Lien direct</span><div class="linkline" id="lnk">${esc(link)}</div>`}
    <div class="btnrow"><a class="btn primary" href="${esc(wa)}" target="_blank" rel="noopener">${ICON.chat} WhatsApp${d && d.phone ? ' à ' + esc(d.name) : ''}</a><button class="btn" id="cp">${ICON.copy} Copier le message</button></div>
    ${!IN_CLAUDE && navigator.share ? `<div class="btnrow"><button class="btn" id="sh">${ICON.share} Partager autrement</button></div>` : ''}
    ${MODE === 'local' ? '<p class="note">Mode démo : le code ne marche que sur cet appareil. Avec Supabase branché, il marche sur n’importe quel téléphone.</p>' : '<p class="note">Le livreur n’a pas besoin de compte. Le code reste valable jusqu’à ce que vous le changiez.</p>'}`, sh => {
    if ($('#qrBox', sh)) loadScript(ASSETS.qrcode).then(() => { const q = window.qrcode(0, 'M'); q.addData(link); q.make(); $('#qrBox', sh).innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); }).catch(() => { $('#qrBox', sh).remove(); });
    $('#cp', sh).addEventListener('click', () => { navigator.clipboard ? navigator.clipboard.writeText(msg).then(() => toast('Message copié'), () => toast('Copie refusée : notez le code affiché.')) : toast('Copie indisponible : notez le code affiché.'); });
    $('#sh', sh)?.addEventListener('click', () => navigator.share({ title: 'Tournée ' + fmtCode(t.code), text: msg }).catch(() => {}));
  });
}
function selectText(el) { try { const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); } catch (e) {} }

/* split between drivers */
function splitSheet(id) {
  const t = C.tours[id]; const ds = Object.values(C.drivers).filter(d => d.active !== false);
  const sel = new Set(t.driver_id ? [t.driver_id] : []); let count = 2;
  openSheet('Répartir la tournée', `
    <p class="note">Les arrêts restants sont découpés en secteurs autour du dépôt, équilibrés en nombre et en poids. Chaque livreur reçoit sa tournée, optimisée, avec son propre code.</p>
    ${ds.length ? `<span class="label">Livreurs</span><div class="mini-list">${ds.map(d => `<div class="checkrow"><input type="checkbox" id="sp_${d.id}" data-id="${d.id}" ${sel.has(d.id) ? 'checked' : ''}><label for="sp_${d.id}"><b>${esc(d.name)}</b><span class="small muted">${[d.vehicle, d.capacity_kg ? d.capacity_kg + ' kg' : ''].filter(Boolean).map(esc).join(' · ')}</span></label></div>`).join('')}</div>`
      : `<div class="field"><label for="spN">Nombre de tournées</label><input class="input" type="number" id="spN" min="2" max="8" value="2"></div>`}
    <div id="spPrev" class="list"></div>
    <button class="btn big primary" id="spGo">Créer les tournées</button>`, sh => {
    const k = () => ds.length ? sel.size : count;
    const prev = () => {
      const n = k(), btn = $('#spGo', sh); if (n < 2) { $('#spPrev', sh).innerHTML = '<div class="empty">Choisissez au moins deux livreurs.</div>'; btn.disabled = true; return; }
      btn.disabled = false; const groups = splitGroups(t, n), names = ds.length ? [...sel].map(i => C.drivers[i].name) : groups.map((_, i) => 'Tournée ' + (i + 1));
      $('#spPrev', sh).innerHTML = groups.map((g, i) => `<div class="report-stop"><b>${esc(names[i])}</b><span class="small muted">${g.length} arrêt${g.length > 1 ? 's' : ''} · ${Math.round(g.reduce((m, s) => m + (+s.weight_kg || 0), 0))} kg</span><span class="small">${g.slice(0, 4).map(s => street(A(s))).join(', ')}${g.length > 4 ? '…' : ''}</span></div>`).join('');
      btn.textContent = `Créer ${n} tournées`;
    };
    sh.querySelectorAll('.checkrow input').forEach(i => i.addEventListener('change', () => { i.checked ? sel.add(i.dataset.id) : sel.delete(i.dataset.id); prev(); }));
    $('#spN', sh)?.addEventListener('input', e => { count = Math.max(2, Math.min(8, +e.target.value || 2)); prev(); });
    prev();
    $('#spGo', sh).addEventListener('click', async e => {
      e.target.disabled = true; e.target.textContent = 'Création…';
      const n = k(), groups = splitGroups(t, n), dids = ds.length ? [...sel] : groups.map(() => null);
      try {
        const created = [];
        for (let i = 0; i < n; i++) {
          const d = dids[i] ? C.drivers[dids[i]] : null; let target = t;
          if (i === 0) await Api.updateTour(t.id, { driver_id: d ? d.id : t.driver_id, driver_name: d ? d.name : t.driver_name, capacity_kg: d ? d.capacity_kg : t.capacity_kg });
          else { target = await Api.createTour({ name: `${t.name} · ${d ? d.name : i + 1}`, day: t.day, start_time: t.start_time, depot: t.depot, return_to_depot: t.return_to_depot, driver_id: d ? d.id : null, driver_name: d ? d.name : '', capacity_kg: d ? d.capacity_kg : t.capacity_kg }); await Api.moveStops(groups[i].map(s => s.id), target.id); }
          created.push(target);
        }
        for (const x of created) { const seq = optimizeOrder(C.tours[x.id]); await Api.reorder(x.id, seq.map(s => s.id)); }
        closeSheet(); resetTo('dtours'); toast(`${n} tournées prêtes, à envoyer chacune à son livreur.`, 4200);
      } catch (err) { toast('Répartition interrompue : ' + err.message); e.target.disabled = false; }
    });
  });
}

/* duplicate, template */
function duplicateSheet(id, opts = {}) {
  const t = C.tours[id];
  const asT = !!opts.template, fromT = t.is_template;
  openSheet(asT ? 'Enregistrer comme modèle' : fromT ? 'Créer depuis le modèle' : 'Dupliquer la tournée', `
    <div class="field"><label for="dName">Nom</label><input class="input" id="dName" value="${esc(asT ? t.name.replace(/\s*·.*$/, '') : fromT ? t.name + ' · ' + new Date().toLocaleDateString('fr-BE', { day: 'numeric', month: 'short' }) : t.name)}"></div>
    ${asT ? '' : `<div class="field"><label for="dDay">Date</label><input class="input" type="date" id="dDay" value="${todayIso() > t.day || fromT ? todayIso() : t.day}"></div>
    <div class="field"><label for="dDriver">Livreur</label><select class="input" id="dDriver">${driverOptions(t.driver_id)}</select></div>`}
    <p class="small muted">${stopsOf(id).length} arrêts repris avec leurs créneaux, poids et consignes. Les statuts et preuves ne sont pas copiés.</p>
    <button class="btn big primary" id="dGo">${asT ? 'Enregistrer le modèle' : 'Créer la tournée'}</button>`, sh => {
    $('#dGo', sh).addEventListener('click', async e => {
      e.target.disabled = true;
      try {
        if (MODE === 'supabase') await Api.loadTour(id);
        const did = $('#dDriver', sh)?.value, d = C.drivers[did];
        const nt = await Api.createTour({ name: $('#dName', sh).value.trim() || t.name, day: asT ? todayIso() : ($('#dDay', sh).value || todayIso()), is_template: asT, start_time: t.start_time, depot: t.depot, return_to_depot: t.return_to_depot, capacity_kg: d ? d.capacity_kg : t.capacity_kg, driver_id: asT ? null : (did || null), driver_name: asT ? '' : (d ? d.name : '') });
        const list = stopsOf(id).map(s => { const o = {}; STOP_FIELDS.forEach(f => { o[f] = s[f]; }); return o; });
        if (list.length) await Api.addStops(nt.id, list);
        closeSheet(); resetTo('dtours'); go('dtour', { id: nt.id }); toast(asT ? 'Modèle enregistré' : 'Tournée créée');
      } catch (err) { e.target.disabled = false; toast('Impossible : ' + err.message); }
    });
  });
}
function pickTourSheet(kind) {
  const list = Object.values(C.tours).filter(t => kind === 'template' ? t.is_template : !t.is_template).sort((a, b) => String(b.day).localeCompare(String(a.day))).slice(0, 40);
  openSheet(kind === 'template' ? 'Choisir un modèle' : 'Dupliquer une tournée', list.length ? `<div class="list">${list.map(t => `<button class="row" data-act="pick-dup" data-id="${t.id}"><div class="row-body"><span class="row-title">${esc(t.name)}</span><span class="small muted">${t.is_template ? 'Modèle' : esc(fmtDay(t.day))} · ${tourCounts(t.id).n} arrêts</span></div>${ICON.chev}</button>`).join('')}</div>`
    : `<div class="empty">${kind === 'template' ? 'Aucun modèle. Ouvrez une tournée, puis Plus › Enregistrer comme modèle.' : 'Aucune tournée à dupliquer.'}</div>`);
}

/* drivers roster */
function driverSheet(id) {
  const d = C.drivers[id] || { name: '', phone: '', vehicle: '', capacity_kg: null, active: true }; let confirmDel = false;
  openSheet(id ? d.name : 'Nouveau livreur', `
    <div class="field"><label for="vName">Prénom et nom</label><input class="input" id="vName" value="${esc(d.name)}" autocomplete="off"></div>
    <div class="field"><label for="vPhone">Téléphone (WhatsApp)</label><input class="input" id="vPhone" type="tel" value="${esc(d.phone || '')}" placeholder="0470 12 34 56"></div>
    <div class="grid2"><div class="field"><label for="vVeh">Véhicule</label><input class="input" id="vVeh" value="${esc(d.vehicle || '')}" placeholder="Ex. : Kangoo"></div><div class="field"><label for="vCap">Capacité (kg)</label><input class="input" type="number" min="0" id="vCap" value="${esc(d.capacity_kg ?? '')}"></div></div>
    <label class="switch" for="vAct"><span>Actif</span><input type="checkbox" id="vAct" ${d.active !== false ? 'checked' : ''}></label>
    <button class="btn big primary" id="vSave">Enregistrer</button>
    ${id ? `<div id="vDelBox"><button class="btn ghost" id="vDel">${ICON.trash} Supprimer ce livreur</button></div>` : ''}`, sh => {
    $('#vSave', sh).addEventListener('click', async e => {
      const name = $('#vName', sh).value.trim(); if (!name) { toast('Indiquez un nom.'); return; } e.target.disabled = true;
      try { await Api.saveDriver({ id: id || undefined, name, phone: $('#vPhone', sh).value.trim(), vehicle: $('#vVeh', sh).value.trim(), capacity_kg: num($('#vCap', sh).value), active: $('#vAct', sh).checked }); closeSheet(); render(); toast('Livreur enregistré'); } catch (err) { e.target.disabled = false; toast('Impossible : ' + err.message); }
    });
    $('#vDel', sh)?.addEventListener('click', () => { if (confirmDel) return; confirmDel = true; $('#vDelBox', sh).innerHTML = `<div class="inline-confirm"><b>Supprimer ${esc(d.name)} ?</b><span>Ses tournées passées restent, sans livreur attribué.</span><div class="btnrow"><button class="btn bad" id="vDelYes">Supprimer</button><button class="btn" data-act="close-sheet">Annuler</button></div></div>`; $('#vDelYes', sh).addEventListener('click', async () => { await Api.deleteDriver(id); closeSheet(); render(); toast('Livreur supprimé'); }); });
  });
}
function addressEditSheet(id) {
  const a = C.addresses[id];
  openSheet('Modifier l’adresse', `
    <div class="field"><label for="aLabel">Adresse</label><input class="input" id="aLabel" value="${esc(a.label)}"></div>
    <div class="grid2"><div class="field"><label for="aClient">Client habituel</label><input class="input" id="aClient" value="${esc(a.client || '')}"></div><div class="field"><label for="aPhone">Téléphone</label><input class="input" id="aPhone" type="tel" value="${esc(a.phone || '')}"></div></div>
    ${coordsHtml(a)}
    <button class="btn big primary" id="aSave">Enregistrer</button>`, sh => {
    const getXY = bindCoords(sh, a, () => $('#aLabel', sh).value);
    $('#aSave', sh).addEventListener('click', async e => {
      e.target.disabled = true; const xy = getXY(); const label = $('#aLabel', sh).value.trim() || a.label;
      const pp = parseAddr(label); try { await Api.updateAddress(id, { label, key: pp.key, pc: pp.pc, city: cityOf(label), client: $('#aClient', sh).value.trim(), phone: $('#aPhone', sh).value.trim(), ...(xy || {}) }); closeSheet(); render(); toast('Adresse enregistrée'); } catch (err) { e.target.disabled = false; toast('Impossible : ' + err.message); }
    });
  });
}

/* edit one element of a fiche (dispatcher) */
function elementEditSheet(id) {
  const e = C.elements[id]; if (!e) return; const a = C.addresses[e.address_id]; const pending = !isOk(e); let confirmDel = false;
  const media = e.type === 'photo' ? `<div class="photo"><img alt="Photo" ${e.media && e.media.startsWith('data:') ? `src="${e.media}"` : `data-media="${esc(e.media)}"`}></div>`
    : e.type === 'voice' ? `<div class="voice">${e.media ? `<audio controls preload="metadata" data-media="${esc(e.media)}"></audio>` : '<p class="hint">Exemple sans audio (voix de synthèse).</p>'}</div>` : '';
  openSheet(pending ? 'Proposition à valider' : 'Modifier l’élément', `
    ${pending ? `<p class="note">Proposé par <b>${esc(e.author || 'un livreur')}</b> ${ago(e.created_at)}. Corrigez si besoin, puis validez : les autres livreurs le verront.</p>` : ''}
    ${media}
    ${e.type === 'photo' ? `<div class="btnrow"><button type="button" class="btn" id="xRe">${ICON.edit} Réannoter</button><button type="button" class="btn" id="xCam">${ICON.camera} Reprendre</button><button type="button" class="btn" id="xGal">${ICON.upload} Galerie</button></div>` : ''}
    ${e.type === 'voice' ? `<div class="btnrow"><button type="button" class="btn" id="xRec">${ICON.mic} Réenregistrer</button></div>` : ''}
    <div class="field"><label for="xText">${e.type === 'photo' ? 'Légende' : e.type === 'voice' ? 'Transcription' : 'Note'}</label><textarea class="input" id="xText" style="min-height:${e.type === 'photo' ? 70 : 110}px">${esc(e.type === 'voice' ? e.transcript || '' : e.body || '')}</textarea></div>
    ${tagField(e.tag || 'Autre')}
    <label class="switch" for="xPin"><span>Consigne officielle (affichée en premier, lue en premier)</span><input type="checkbox" id="xPin" ${e.pinned ? 'checked' : ''}></label>
    <button class="btn big primary" id="xSave">${pending ? 'Valider et publier' : 'Enregistrer'}</button>
    <div id="xDelBox"><button class="btn ghost" id="xDel">${ICON.trash} ${pending ? 'Refuser la proposition' : 'Supprimer de la fiche'}</button></div>`, sh => {
    const fields = () => ({ [e.type === 'voice' ? 'transcript' : 'body']: $('#xText', sh).value.trim(), tag: getPick(sh, 'tag') || 'Autre', pinned: $('#xPin', sh).checked, ...(pending ? { status: 'ok' } : {}) });
    $('#xSave', sh).addEventListener('click', async ev => { ev.target.disabled = true; try { await Api.updateElement(id, fields()); closeSheet(); render(); toast(pending ? 'Validé : visible par tous les livreurs' : 'Élément enregistré'); } catch (err) { ev.target.disabled = false; toast('Impossible : ' + err.message); } });
    const reAnnotate = async blob => { const f = fields(); await Api.updateElement(id, f); closeSheet(); annotateSheet(blob, a.id, '', { editId: id, el: { ...e, ...f } }); };
    $('#xRe', sh)?.addEventListener('click', async () => { const b = await Api.mediaBlob(e.media); if (b) reAnnotate(b); else toast("Photo introuvable."); });
    $('#xCam', sh)?.addEventListener('click', () => pickPhoto(f => reAnnotate(f)));
    $('#xGal', sh)?.addEventListener('click', () => pickGallery(fs => fs[0] && reAnnotate(fs[0])));
    $('#xRec', sh)?.addEventListener('click', async () => { const f = fields(); await Api.updateElement(id, f); closeSheet(); voiceSheet(a.id, '', { editId: id }); });
    $('#xDel', sh).addEventListener('click', () => {
      if (confirmDel) return; confirmDel = true;
      $('#xDelBox', sh).innerHTML = `<div class="inline-confirm"><b>${pending ? 'Refuser cette proposition ?' : 'Supprimer cet élément ?'}</b><span>${pending ? 'Elle est effacée et ne sera vue par personne.' : 'Il disparaît de la fiche pour tous les livreurs.'}</span><div class="btnrow"><button class="btn bad" id="xDelYes">${pending ? 'Refuser' : 'Supprimer'}</button><button class="btn" data-act="close-sheet">Annuler</button></div></div>`;
      $('#xDelYes', sh).addEventListener('click', async () => { await Api.deleteElement(id); closeSheet(); render(); toast(pending ? 'Proposition refusée' : 'Élément supprimé'); });
    });
  });
}
