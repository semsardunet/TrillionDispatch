#!/usr/bin/env python3
"""Builds every flavour of TrillionDispatch from the same sources.
   - dernier-metre.html : Claude preview (public CDNs, demo mode)
   - scratch test copies (demo mode / local Supabase stand-in)
   - hosted package     : site/ with its own libraries and fonts, CSP and security headers
"""
import os, re, shutil, subprocess, sys, glob
SRC = '/home/claude/dm2'; SP = '/tmp/claude-0/-home-claude/d3ec0fa3-7b57-5a91-8b6d-58cc313c5d1c/scratchpad'
OUT = '/mnt/user-data/outputs/trilliondispatch'; VB = SP + '/vendorbuild'
FILES = ['3-core.js', '3b-domain.js', '4-api.js', '4b-seed.js', '5b-legal.js', '5-app.js', '6-driver.js', '7-dispatch.js', '8-sheets.js', '9-main.js']
os.chdir(SRC)
subprocess.run([sys.executable, 'build_legal.py'], check=True, stdout=subprocess.DEVNULL)
head, body = open('1-head.html').read(), open('2-body.html').read()
script = ''.join(open(f).read() for f in FILES)
open(SP + '/app2.js', 'w').write(script)
r = subprocess.run(['node', '--check', SP + '/app2.js']); assert r.returncode == 0, 'syntax'
SB_URL = 'https://nwlteniesfckhhwxoihb.supabase.co'; SB_KEY = 'sb_publishable_8P9SynrEKpNwBkLXglClNg_Z6EKuM8p'
page = head + body + '<script>\n' + script + '</script>\n'
open('dernier-metre.html', 'w').write(page)
shutil.copy('dernier-metre.html', '/home/claude/dm/dernier-metre.html')
wrap = lambda h: '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>' + h + '</body></html>'
open(SP + '/test2.html', 'w').write(wrap(page.replace(SB_URL, '').replace(SB_KEY, '')))
os.makedirs(SP + '/sbstack', exist_ok=True)
open(SP + '/sbstack/app.html', 'w').write(wrap(page.replace(SB_URL, 'http://localhost:54321').replace(SB_KEY, 'sb_publishable_testkey')))

# ---------- hosted package ----------
if '--hosted' in sys.argv:
    site = OUT + '/site'
    for p in [OUT + '/index.html', OUT + '/schema.sql']:
        if os.path.exists(p): os.remove(p)
    if os.path.exists(site): shutil.rmtree(site)
    os.makedirs(site + '/vendor/leaflet/images'); os.makedirs(site + '/fonts'); os.makedirs(OUT + '/supabase', exist_ok=True)
    pk = lambda n: glob.glob(f'{VB}/x_{n}*/package')[0]
    shutil.copy(pk('supabase-supabase-js') + '/dist/umd/supabase.js', site + '/vendor/supabase.js')
    shutil.copy(pk('jspdf') + '/dist/jspdf.umd.min.js', site + '/vendor/jspdf.umd.min.js')
    shutil.copy(pk('jszip') + '/dist/jszip.min.js', site + '/vendor/jszip.min.js')
    shutil.copy(pk('qrcode-generator') + '/qrcode.js', site + '/vendor/qrcode.js')
    shutil.copy(f'{VB}/x_ref/package/bundle/read-excel-file.min.js', site + '/vendor/read-excel-file.min.js')
    shutil.copy(pk('leaflet') + '/dist/leaflet.js', site + '/vendor/leaflet/leaflet.js')
    shutil.copy(pk('leaflet') + '/dist/leaflet.css', site + '/vendor/leaflet/leaflet.css')
    for img in glob.glob(pk('leaflet') + '/dist/images/*.png'): shutil.copy(img, site + '/vendor/leaflet/images/')
    tdir = site + '/vendor/tesseract'; os.makedirs(tdir + '/core'); os.makedirs(tdir + '/lang')
    for f in ('tesseract.min.js', 'worker.min.js'): shutil.copy(pk('tesseract.js-7') + '/dist/' + f, tdir + '/' + f)
    for v in ('', 'simd-', 'relaxedsimd-'): shutil.copy(pk('tesseract.js-core') + f'/tesseract-core-{v}lstm.wasm.js', tdir + '/core/')
    shutil.copy(pk('tesseract.js-data-fra') + '/4.0.0_best_int/fra.traineddata.gz', tdir + '/lang/')
    css = []
    for fam, weights in [('barlow', [400, 500, 600, 700]), ('barlow-condensed', [600, 700, 800]), ('jetbrains-mono', [500, 700])]:
        base = pk('fontsource-' + fam)
        for w in weights:
            for block in re.findall(r'/\* [^*]+\*/\s*@font-face \{.*?\}', open(f'{base}/{w}.css').read(), re.S):
                if not re.search(r'-(latin|latin-ext)-\d+-normal \*/', block): continue
                woff2 = re.search(r'url\(\./files/([^)]+\.woff2)\)', block).group(1)
                shutil.copy(f'{base}/files/{woff2}', site + '/fonts/' + woff2)
                css.append(re.sub(r'src: [^;]+;', f"src: url({woff2}) format('woff2');", block))
    open(site + '/fonts/fonts.css', 'w').write('/* Barlow, Barlow Condensed (SIL OFL 1.1), JetBrains Mono (SIL OFL 1.1), hébergées avec l’application */\n' + '\n'.join(css) + '\n')
    csp = ("default-src 'self'; script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; "
           f"img-src 'self' data: blob: https://tile.openstreetmap.org {SB_URL}; media-src 'self' blob: {SB_URL}; "
           f"connect-src 'self' data: {SB_URL} {SB_URL.replace('https', 'wss')} https://nominatim.openstreetmap.org; "
           "font-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; worker-src 'self' blob:; frame-src 'none'")
    hosted_head = '\n'.join(l for l in head.split('\n') if 'fonts.googleapis' not in l and 'fonts.gstatic' not in l)
    index = ('<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n'
             '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
             f'<meta http-equiv="Content-Security-Policy" content="{csp}">\n'
             '<meta name="referrer" content="strict-origin-when-cross-origin">\n<meta name="theme-color" content="#1747C9">\n'
             '<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="TrillionDispatch">\n<meta name="application-name" content="TrillionDispatch">\n'
             '<link rel="stylesheet" href="fonts/fonts.css">\n'
             '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22%3E%3Crect width=%2232%22 height=%2232%22 rx=%227%22 fill=%22%231747C9%22/%3E%3Ctext x=%2216%22 y=%2222%22 font-family=%22Arial%22 font-weight=%22700%22 font-size=%2215%22 fill=%22white%22 text-anchor=%22middle%22%3ETD%3C/text%3E%3C/svg%3E">\n'
             '<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}</style>\n'
             + hosted_head + '\n</head>\n<body>\n' + body + "<script>window.DM_VENDOR = 'vendor/';</script>\n<script>\n" + script + '</script>\n</body>\n</html>\n')
    open(site + '/index.html', 'w').write(index)
    open(site + '/.htaccess', 'w').write(f"""# TrillionDispatch : HTTPS obligatoire et en-têtes de sécurité (Apache / LiteSpeed, ex. Hostinger)
Options -Indexes
RewriteEngine On
RewriteCond %{{HTTPS}} !=on
RewriteRule ^ https://%{{HTTP_HOST}}%{{REQUEST_URI}} [L,R=301]
<IfModule mod_headers.c>
  Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
  Header always set X-Content-Type-Options "nosniff"
  Header always set X-Frame-Options "DENY"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
  Header always set Permissions-Policy "geolocation=(self), microphone=(self), camera=(self), payment=(), usb=(), interest-cohort=()"
  Header always set Cross-Origin-Opener-Policy "same-origin"
  Header always set Content-Security-Policy "{csp}; frame-ancestors 'none'"
  <FilesMatch "\\.(html)$">
    Header set Cache-Control "no-cache"
  </FilesMatch>
</IfModule>
<IfModule mod_mime.c>
  RemoveEncoding .gz
  AddType application/octet-stream .gz
</IfModule>
""")
    shutil.copy('schema.sql', OUT + '/supabase/schema-reference.sql')
    shutil.copy('hardening_b.sql', OUT + '/supabase/A-COLLER-dans-Supabase.sql')
    print('hosted package ready')
print('built', len(page))
