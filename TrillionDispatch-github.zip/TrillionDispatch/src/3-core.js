'use strict';
/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-5);
const nowIso = () => new Date().toISOString();
const fmtTime = iso => iso ? new Date(iso).toLocaleTimeString('fr-BE', { hour: '2-digit', minute: '2-digit' }) : '';
const fmtDay = d => { const s = String(d); const x = /^\d{4}-\d{2}-\d{2}$/.test(s) ? new Date(s + "T12:00:00") : new Date(s); return x.toLocaleDateString("fr-BE", { weekday: "long", day: "numeric", month: "long" }); };
const fmtShort = iso => new Date(iso).toLocaleDateString('fr-BE', { day: '2-digit', month: '2-digit', year: 'numeric' });
const isoDay = iso => { const d = new Date(iso); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
function ago(iso) {
  const d = (Date.now() - new Date(iso).getTime()) / 86400000;
  if (d < 1) return "aujourd'hui"; if (d < 2) return 'hier';
  if (d < 31) return `il y a ${Math.floor(d)} j`; if (d < 365) return `il y a ${Math.floor(d / 30)} mois`;
  return `il y a ${Math.floor(d / 365)} an${d >= 730 ? 's' : ''}`;
}
const daysOld = iso => (Date.now() - new Date(iso).getTime()) / 86400000;
const slug = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
const IN_CLAUDE = !!(window.claude && typeof window.claude.use === "function");
const newId = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : uid() + uid();
const todayIso = () => isoDay(new Date().toISOString());
const hm = t => t ? String(t).slice(0, 5) : "";
const toMin = t => { if (!t) return null; const [h, m] = String(t).split(":").map(Number); return h * 60 + (m || 0); };
const fromMin = m => `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(Math.round(m % 60)).padStart(2, "0")}`;

const ICON = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  camera: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
  note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="M13.5 6.5l4 4"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>',
  nav: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l18-8-8 18-2-8z"/></svg>',
  pin: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 3l5 5-3 1-4 4 1 5-2 2-4-4-5 5-1-1 5-5-4-4 2-2 5 1 4-4z"/></svg>',
  up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
  chev: '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" width="20" height="20"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19L19 5M10 5h9v9"/></svg>',
  circle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="12" r="8"/></svg>',
  cross: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>',
  share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.5M8.2 13.2l7.6 4.5"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
  flag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></svg>',
  truck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 6h11v10H2zM13 9h4l4 4v3h-8"/><circle cx="6.5" cy="17.5" r="2"/><circle cx="17.5" cy="17.5" r="2"/></svg>',
  board: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h6M7 13h10M7 17h4"/><circle cx="17" cy="9" r="1.5"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/></svg>',
  upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 6h12M9 12h12M9 18h12"/><circle cx="4" cy="6" r="1.2" fill="currentColor"/><circle cx="4" cy="12" r="1.2" fill="currentColor"/><circle cx="4" cy="18" r="1.2" fill="currentColor"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.6-5.2A8.5 8.5 0 1 1 21 12z"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>',
  split: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21v-7l-6-6M12 14l6-6M3 3h5v5M21 3h-5v5"/></svg>',
  stack: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></svg>',
  qr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM18 18h3v3h-3z"/></svg>',
  map: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/></svg>',
  target: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></svg>',
  key: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/></svg>',
  logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/></svg>',
};
const ICON_BLANK = 0;
/* ---------- address normalisation: same place, same key, whatever the spelling ---------- */
const ABBR = [
  [/\bav(e|enue)?\b/g, 'avenue'], [/\b(bd|boul|blvd|boulevard)\b/g, 'boulevard'], [/\b(ch|chee|chss|chaussee)\b/g, 'chaussee'],
  [/\b(r|rue)\b/g, 'rue'], [/\b(pl|place)\b/g, 'place'], [/\b(sq|square)\b/g, 'square'], [/\b(st)\b/g, 'saint'], [/\b(ste)\b/g, 'sainte'],
  [/\b(gen|gal)\b/g, 'general'], [/\b(de la|de l|du|des|de|d)\b/g, ' '],
];
function parseAddr(raw) {
  let s = String(raw).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’'`]/g, ' ');
  const parts = s.split(',');
  let street = parts[0], rest = parts.slice(1).join(' '), pc = '', box = '', num = '';
  let m = rest.match(/\b([1-9]\d{3})\b/);
  if (m) pc = m[1];
  else if (parts.length === 1) { m = s.match(/\s([1-9]\d{3})\s+[a-z]/); if (m) { pc = m[1]; street = s.slice(0, m.index); } }
  const bm = street.match(/\b(?:bte|boite|bus|bt|b)\b\.?\s*([0-9a-z]{1,4})\b|\/\s*([0-9a-z]{1,4})\b/);
  if (bm) { box = bm[1] || bm[2]; street = street.slice(0, bm.index) + ' ' + street.slice(bm.index + bm[0].length); }
  street = street.replace(/[.\-;:]/g, ' ');
  const nm = [...street.matchAll(/\b(\d{1,4}[a-z]?)\b/g)];
  if (nm.length) { const last = nm[nm.length - 1]; num = last[1]; street = street.slice(0, last.index) + ' ' + street.slice(last.index + last[0].length); }
  street = ' ' + street + ' ';
  for (const [re, rep] of ABBR) street = street.replace(re, rep);
  street = street.replace(/\s+/g, ' ').trim();
  return { street, num, box, pc, key: [street, num, box, pc].join('|') };
}
function cityOf(label) { const m = String(label).match(/\b[1-9]\d{3}\s+(.+)$/); return m ? m[1].trim() : ''; }

/* ---------- geometry and route optimisation ---------- */
function dist(a, b) {
  const R = 6371000, r = x => x * Math.PI / 180;
  const dLat = r(b.lat - a.lat), dLng = r(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
const hasXY = a => a && a.lat != null && a.lng != null;
const ROAD = 1.35, KMH = 22;
/* ---------- spoken French: always a French voice, read the way a Brussels driver would say it ---------- */
let frVoices = [];
function loadVoices() { try { frVoices = speechSynthesis.getVoices().filter(v => /^fr([-_]|$)/i.test(v.lang)); } catch (e) { frVoices = []; } return frVoices; }
try { speechSynthesis.addEventListener('voiceschanged', loadVoices); loadVoices(); } catch (e) {}
function voiceScore(v) {
  let s = 0; const n = v.name.toLowerCase();
  if (/^fr[-_]be/i.test(v.lang)) s += 30; else if (/^fr[-_]fr/i.test(v.lang)) s += 20; else s += 10;
  if (/google|natural|neural|premium|enhanced|amélie|amelie|thomas|audrey|aurélie|aurelie|denise|henri|eloise|vivienne|remy/.test(n)) s += 15;
  if (v.localService) s += 2;
  return s;
}
function pickVoice() {
  const vs = frVoices.length ? frVoices : loadVoices(); if (!vs.length) return null;
  let chosen = null; try { chosen = localStorage.getItem('dm-voice-name'); } catch (e) {}
  return vs.find(v => v.name === chosen) || [...vs].sort((a, b) => voiceScore(b) - voiceScore(a))[0];
}
function frText(t) {
  return String(t || '')
    .replace(/\bn°\s*/gi, 'numéro ').replace(/\bbte\b\.?/gi, 'boîte').replace(/\bav\.?(?=\s)/gi, 'avenue').replace(/\bbd\.?(?=\s)/gi, 'boulevard')
    .replace(/\bch(é|e)e\.?(?=\s)/gi, 'chaussée').replace(/\bsq\.?(?=\s)/gi, 'square').replace(/\bpl\.?(?=\s)/gi, 'place').replace(/\bst\.?(?=\s)/gi, 'saint')
    .replace(/(\d{1,2})h(\d{2})?\b/g, (m, h, mm) => `${+h} heure${+h > 1 ? 's' : ''}${mm ? ' ' + mm : ''}`)
    .replace(/\b(code|digicode|cadenas)\s*:?\s*([0-9A-Z#*]{3,})/gi, (m, w, c) => `${w} ${c.split('').join(' ')}`)
    .replace(/\b\d{5,}\b/g, m => m.split('').join(' '))
    .replace(/([.!?])\s*\./g, '$1').replace(/\s{2,}/g, ' ');
}
let noFrWarned = false;
function speak(text) {
  try {
    if (!('speechSynthesis' in window)) return false;
    speechSynthesis.cancel();
    const go = () => {
      const u = new SpeechSynthesisUtterance(frText(text)); const v = pickVoice();
      u.lang = v ? v.lang : 'fr-FR'; if (v) u.voice = v; u.rate = 1; u.pitch = 1;
      if (!v && !noFrWarned) { noFrWarned = true; try { toast("Aucune voix française installée sur ce téléphone. Ajoutez-la dans les réglages de synthèse vocale du téléphone.", 5000); } catch (e) {} }
      speechSynthesis.speak(u);
    };
    if (loadVoices().length || !('onvoiceschanged' in speechSynthesis)) go();
    else { let done = false; const once = () => { if (done) return; done = true; go(); }; speechSynthesis.addEventListener('voiceschanged', once, { once: true }); setTimeout(once, 1200); }
    return true;
  } catch (e) { return false; }
}

/* ---------- toast ---------- */
function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { t.hidden = true; }, ms); }
/* ---------- images ---------- */
function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
async function fileToImage(file) { const u = URL.createObjectURL(file); try { return await loadImage(u); } finally { setTimeout(() => URL.revokeObjectURL(u), 1000); } }
function canvasBlob(c, type = 'image/jpeg', q = 0.78) { return new Promise(res => c.toBlob(b => res(b), type, q)); }
async function shrink(file, max = 1600) {
  const img = await fileToImage(file); const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return canvasBlob(c);
}
