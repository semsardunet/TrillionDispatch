# Converts the legal markdown files into a JS module for the in-app legal pages.
import re, json, html
DOCS = [('mentions', 'mentions.md'), ('cgu', 'cgu.md'), ('confidentialite', 'confidentialite.md'), ('sous-traitance', 'sous-traitance.md'), ('geolocalisation', 'geolocalisation.md')]
def inline(t):
    t = html.escape(t, quote=False)
    return re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
def md2html(src):
    out, lines, i, title = [], src.split('\n'), 0, ''
    while i < len(lines):
        l = lines[i]
        if l.startswith('# '): title = l[2:].strip(); i += 1; continue
        if l.startswith('## '): out.append(f'<h3 class="h3">{inline(l[3:])}</h3>'); i += 1; continue
        if l.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(set(c) <= set('-: ') for c in cells): rows.append(cells)
                i += 1
            head, body = rows[0], rows[1:]
            out.append('<div class="preview-table"><table><thead><tr>' + ''.join(f'<th>{inline(c)}</th>' for c in head) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join(f'<td style="white-space:normal">{inline(c)}</td>' for c in r) + '</tr>' for r in body) + '</tbody></table></div>')
            continue
        m = re.match(r'^(\s*)(- |\d+\. )(.*)$', l)
        if m:
            ordered = m.group(2).strip().endswith('.'); items = []
            while i < len(lines):
                mm = re.match(r'^(\s*)(- |\d+\. )(.*)$', lines[i])
                if not mm: break
                items.append(inline(mm.group(3))); i += 1
            tag = 'ol' if ordered else 'ul'
            out.append(f'<{tag} class="legal-list">' + ''.join(f'<li>{x}</li>' for x in items) + f'</{tag}>')
            continue
        if l.strip(): out.append(f'<p>{inline(l.strip())}</p>')
        i += 1
    return title, '\n'.join(out)
legal = {}
for key, f in DOCS:
    t, h = md2html(open('legal/' + f, encoding='utf-8').read())
    legal[key] = {'title': t, 'html': h}
open('5b-legal.js', 'w', encoding='utf-8').write('/* ---------- legal texts (generated from legal/*.md) ---------- */\nconst TERMS_VERSION = "2026-10-10";\nconst LEGAL = ' + json.dumps(legal, ensure_ascii=False) + ';\n')
print({k: len(v['html']) for k, v in legal.items()})
