/* ---------- configuration ---------- */
const CONFIG = {
  SUPABASE_URL: 'https://nwlteniesfckhhwxoihb.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_8P9SynrEKpNwBkLXglClNg_Z6EKuM8p',   // clé publique : jamais la clé secrète ou service_role ici
};
const MODE = (!IN_CLAUDE && CONFIG.SUPABASE_URL && CONFIG.SUPABASE_ANON_KEY) ? 'supabase' : 'local';
const VENDOR = window.DM_VENDOR || '';   // the hosted build sets 'vendor/': no third-party script at runtime
const ASSETS = VENDOR ? {
  supabase: VENDOR + 'supabase.js', jspdf: VENDOR + 'jspdf.umd.min.js', jszip: VENDOR + 'jszip.min.js', qrcode: VENDOR + 'qrcode.js',
  xlsx: VENDOR + 'read-excel-file.min.js', leafletJs: VENDOR + 'leaflet/leaflet.js', leafletCss: VENDOR + 'leaflet/leaflet.css',
} : {
  supabase: 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.116.0/dist/umd/supabase.js',
  jspdf: 'https://cdn.jsdelivr.net/npm/jspdf@4.2.1/dist/jspdf.umd.min.js',
  jszip: 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  qrcode: 'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js',
  xlsx: 'https://cdn.jsdelivr.net/npm/read-excel-file@9.3.10/bundle/read-excel-file.min.js',
  leafletJs: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js', leafletCss: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
};
/* lecture de documents (OCR) : tout tourne sur le téléphone, l'image n'est envoyée nulle part */
const OCR_ASSETS = VENDOR ? { js: VENDOR + 'tesseract/tesseract.min.js', worker: VENDOR + 'tesseract/worker.min.js', core: VENDOR + 'tesseract/core', lang: VENDOR + 'tesseract/lang' } : {
  js: 'https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/tesseract.min.js', worker: 'https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/worker.min.js',
  core: 'https://cdn.jsdelivr.net/npm/tesseract.js-core@7.0.0', lang: 'https://cdn.jsdelivr.net/npm/@tesseract.js-data/fra@1.0.0/4.0.0_best_int',
};

/* ---------- cache shared by every screen (filled by Api) ---------- */
const C = { tours: {}, stops: {}, addresses: {}, elements: {}, drivers: {} };
const stopsOf = tid => Object.values(C.stops).filter(s => s.tour_id === tid).sort((a, b) => a.rank - b.rank);
const A = s => C.addresses[s.address_id] || { id: '', key: '', label: s.raw || 'Adresse inconnue' };
const elsOf = aid => Object.values(C.elements).filter(e => e.address_id === aid);
const winText = s => (s.win_start || s.win_end) ? `${hm(s.win_start) || '…'}–${hm(s.win_end) || '…'}` : '';
const fmtCode = c => c ? `${c.slice(0, 3)}-${c.slice(3)}` : '';
const normCode = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const CODE_ALPHA = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
const genCode = () => Array.from({ length: 6 }, () => CODE_ALPHA[Math.floor(Math.random() * CODE_ALPHA.length)]).join('');
const tourLink = t => `${location.origin}${location.pathname}#t-${t.code}`;
const tourCounts = tid => { const ss = stopsOf(tid); return { n: ss.length, done: ss.filter(s => s.status === 'done').length, failed: ss.filter(s => s.status === 'failed').length, todo: ss.filter(s => s.status === 'todo').length, kg: ss.reduce((m, s) => m + (+s.weight_kg || 0), 0) }; };
const STATUS_LABEL = { draft: 'Brouillon', published: 'Envoyée', active: 'En cours', done: 'Terminée' };

/* ---------- field notes ---------- */
const TAGS = ['Accès', 'Stationnement', 'Interphone', 'Clé', 'Dépôt', 'Animal', 'Danger', 'Horaires', 'Autre'];
const elScore = e => (e.up || 0) - (e.down || 0);
const isOk = e => (e.status || 'ok') === 'ok';
const byStep = (a, b) => (a.position ?? 0) - (b.position ?? 0) || String(a.created_at).localeCompare(String(b.created_at));
const visibleEls = aid => elsOf(aid).filter(e => isOk(e) && elScore(e) > -2).sort(byStep);
const pendingEls = aid => elsOf(aid).filter(e => !isOk(e)).sort(byStep);
const trunc = (t, n = 140) => t.length > n ? t.slice(0, n - 3).replace(/\s+\S*$/, '') + '…' : t;
function ficheCount(aid) {
  const els = visibleEls(aid);
  return { photo: els.filter(e => e.type === 'photo').length, voice: els.filter(e => e.type === 'voice').length, text: els.filter(e => e.type === 'text').length, all: els.length };
}
function summary(aid) {
  const els = visibleEls(aid); if (!els.length) return '';
  const pinned = els.find(e => e.pinned && (e.body || e.transcript)); if (pinned) return trunc(pinned.body || pinned.transcript);
  return trunc(els.filter(e => e.body || e.transcript).map(e => e.body || e.transcript).join(' · '));
}
function nearbyFiche(a) {
  if (!hasXY(a)) return null; let best = null, bd = 30;
  for (const b of Object.values(C.addresses)) { if (b.id === a.id || !hasXY(b) || !visibleEls(b.id).length) continue; const d = dist(a, b); if (d < bd) { bd = d; best = b; } }
  return best;
}
function briefingText(s) {
  const a = A(s); const rank = stopsOf(s.tour_id).findIndex(x => x.id === s.id) + 1; const els = visibleEls(a.id);
  const pin = els.find(e => e.pinned && (e.body || e.transcript));
  const clean = t => String(t).trim().replace(/[.!?…]+$/, '');
  const steps = els.filter(e => !e.pinned && (e.body || e.transcript)).map((e, i) => `Étape ${i + 1} : ${clean(e.body || e.transcript)}.`).join(' ');
  return `Arrêt ${rank}. ${a.label.split(',')[0]}. ${s.client ? s.client + '. ' : ''}${s.driver_note ? 'Consigne du jour : ' + clean(s.driver_note) + '. ' : ''}${pin ? 'Consigne : ' + clean(pin.body || pin.transcript) + '. ' : ''}${steps || (pin ? '' : 'Pas encore de fiche pour cette adresse.')}`;
}

/* ---------- route planning: travel time, time windows, priorities, locked stops ---------- */
const fmtDur = min => min >= 60 ? `${Math.floor(min / 60)} h ${String(min % 60).padStart(2, "0")}` : `${min} min`;
const nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
function startContext(t, done) {
  const live = t.status === 'active' || done.length;
  let pos = t.depot;
  if (live) { for (const s of done) if (hasXY(A(s))) pos = A(s); if (t.last_pos && hasXY(t.last_pos)) pos = t.last_pos; if (UI.pos && UI.role === 'driver') pos = UI.pos; }
  const min = live ? nowMin() : (toMin(hm(t.start_time)) ?? 8 * 60);
  return { pos, min };
}
function simulate(t, seq, pos, time) {
  let km = 0, cost = 0, lateCount = 0; const etas = {};
  seq.forEach((s, i) => {
    const a = A(s); let tr = 0;
    if (hasXY(a) && hasXY(pos)) { const d = dist(pos, a) * ROAD; km += d / 1000; tr = d / 1000 / KMH * 60; pos = a; }
    time += tr; let wait = 0;
    const ws = toMin(hm(s.win_start)), we = toMin(hm(s.win_end));
    if (ws != null && time < ws) { wait = ws - time; time = ws; }
    const late = we != null && time > we ? time - we : 0; if (late > 0.5) lateCount++;
    etas[s.id] = { eta: time, late, wait };
    cost += tr + wait * 0.3 + late * 25 + (+s.priority ? i * 2 : 0);
    time += (s.service_min ?? 4);
  });
  if (t.return_to_depot !== false && hasXY(pos) && hasXY(t.depot)) { const d = dist(pos, t.depot) * ROAD; km += d / 1000; const tr = d / 1000 / KMH * 60; time += tr; cost += tr; }
  return { cost, km, end: time, etas, lateCount };
}
function planInfo(t) {
  const ss = stopsOf(t.id), done = ss.filter(s => s.status !== 'todo'), todo = ss.filter(s => s.status === 'todo');
  const ctx = startContext(t, done); const sim = simulate(t, todo, ctx.pos, ctx.min);
  let doneKm = 0, p = t.depot; for (const s of done) { const a = A(s); if (hasXY(a) && hasXY(p)) { doneKm += dist(p, a) * ROAD / 1000; p = a; } }
  const live = done.length > 0 || t.status === 'active';
  const elapsed = live && t.started_at ? (Date.now() - new Date(t.started_at)) / 60000 : 0;
  return { etas: sim.etas, km: sim.km + doneKm, end: sim.end, lateCount: sim.lateCount, durMin: Math.max(0, Math.round(elapsed + sim.end - ctx.min)) };
}
function optimizeOrder(t) {
  const ss = stopsOf(t.id), done = ss.filter(s => s.status !== 'todo'), todo = ss.filter(s => s.status === 'todo');
  const lockedAt = {}; todo.forEach((s, i) => { if (s.locked) lockedAt[i] = s; });
  const free = todo.filter(s => !s.locked && hasXY(A(s))), noXY = todo.filter(s => !s.locked && !hasXY(A(s)));
  const { pos, min } = startContext(t, done);
  const compose = order => { const fill = [...order, ...noXY]; const out = []; let k = 0; for (let i = 0; i < todo.length; i++) out.push(lockedAt[i] || fill[k++]); return out.filter(Boolean); };
  const cost = order => simulate(t, compose(order), pos, min).cost;
  let order = [];
  const deadline = s => toMin(hm(s.win_end)) ?? 99999;
  const queue = [...free].sort((a, b) => (+b.priority - +a.priority) || deadline(a) - deadline(b) || dist(t.depot || pos, A(a)) - dist(t.depot || pos, A(b)));
  if (free.length <= 70) {
    for (const s of queue) { let best = null, bc = Infinity; for (let i = 0; i <= order.length; i++) { const c = cost([...order.slice(0, i), s, ...order.slice(i)]); if (c < bc) { bc = c; best = i; } } order.splice(best, 0, s); }
  } else {
    const left = [...free]; let cur = pos; while (left.length) { let bi = 0, bd = Infinity; left.forEach((s, i) => { const d = dist(cur, A(s)); if (d < bd) { bd = d; bi = i; } }); const [n] = left.splice(bi, 1); order.push(n); cur = A(n); }
  }
  const t0 = performance.now(); let base = cost(order), improved = true;
  while (improved && performance.now() - t0 < 600) {
    improved = false;
    for (let i = 0; i < order.length - 1 && !improved; i++) for (let k = i + 1; k < order.length && !improved; k++) {
      const cand = [...order.slice(0, i), ...order.slice(i, k + 1).reverse(), ...order.slice(k + 1)]; const c = cost(cand);
      if (c < base - 0.01) { order = cand; base = c; improved = true; }
    }
    for (let i = 0; i < order.length && !improved; i++) for (let j = 0; j < order.length && !improved; j++) {
      if (i === j) continue; const cand = [...order]; const [x] = cand.splice(i, 1); cand.splice(j, 0, x); const c = cost(cand);
      if (c < base - 0.01) { order = cand; base = c; improved = true; }
    }
  }
  return [...done, ...compose(order)];
}
function splitGroups(t, k) {
  const todo = stopsOf(t.id).filter(s => s.status === 'todo');
  const c = hasXY(t.depot) ? t.depot : (todo.map(A).find(hasXY) || { lat: 50.85, lng: 4.35 });
  const xy = todo.filter(s => hasXY(A(s))).map(s => ({ s, ang: Math.atan2(A(s).lat - c.lat, (A(s).lng - c.lng) * Math.cos(c.lat * Math.PI / 180)) })).sort((a, b) => a.ang - b.ang);
  if (xy.length > 1) { let gi = 0, g = -1; xy.forEach((p, i) => { const nx = xy[(i + 1) % xy.length]; const gap = ((nx.ang - p.ang) + 2 * Math.PI) % (2 * Math.PI); if (gap > g) { g = gap; gi = (i + 1) % xy.length; } }); xy.push(...xy.splice(0, gi)); }
  const w = s => (+s.weight_kg || 0) + 1; const total = xy.reduce((m, p) => m + w(p.s), 0);
  const groups = Array.from({ length: k }, () => []); let acc = 0, gi = 0;
  for (const p of xy) { if (gi < k - 1 && acc >= total * (gi + 1) / k) gi++; groups[gi].push(p.s); acc += w(p.s); }
  todo.filter(s => !hasXY(A(s))).forEach((s, i) => groups[i % k].push(s));
  return groups;
}

/* ---------- GPS ---------- */
let watchId = null;
function startGeo(onPos) {
  if (!navigator.geolocation || watchId != null) return;
  try {
    watchId = navigator.geolocation.watchPosition(p => {
      UI.pos = { lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy), at: Date.now() }; onPos && onPos(UI.pos);
    }, () => { UI.geoDenied = true; }, { enableHighAccuracy: true, maximumAge: 10000, timeout: 20000 });
  } catch (e) { UI.geoDenied = true; }
}
function stopGeo() { if (watchId != null) { try { navigator.geolocation.clearWatch(watchId); } catch (e) {} watchId = null; } UI.pos = null; }
function currentPos() {
  return new Promise(res => {
    if (UI.pos && Date.now() - UI.pos.at < 30000) return res(UI.pos);
    if (!navigator.geolocation) return res(null);
    try { navigator.geolocation.getCurrentPosition(p => res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy), at: Date.now() }), () => res(null), { enableHighAccuracy: true, timeout: 7000, maximumAge: 15000 }); } catch (e) { res(null); }
  });
}
let wakeLock = null;
async function keepAwake(on) {
  try {
    if (on && 'wakeLock' in navigator && !wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
    if (!on && wakeLock) { await wakeLock.release(); wakeLock = null; }
  } catch (e) { wakeLock = null; }
}
async function geocode(q) {
  try {
    const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 7000);
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=be&q=' + encodeURIComponent(q), { signal: ctl.signal, headers: { 'Accept-Language': 'fr' } });
    clearTimeout(tm); if (!r.ok) return null; const j = await r.json(); return j[0] ? { lat: +j[0].lat, lng: +j[0].lon } : null;
  } catch (e) { return null; }
}
function loadScript(src) {
  return new Promise((res, rej) => {
    const ex = document.querySelector(`script[src="${src}"]`); if (ex && ex.dataset.loaded) return res();
    const s = ex || document.createElement('script'); s.src = src;
    s.addEventListener('load', () => { s.dataset.loaded = 1; res(); }); s.addEventListener('error', () => rej(new Error('load')));
    if (!ex) document.head.appendChild(s);
  });
}


/* ---------- lecture d'un document photographié ---------- */
const SCAN_STREET_FR = /\b(rue|r\.|avenue|av\.?|boulevard|bd|bld|chauss[ée]e|ch[ée]e|place|pl\.|square|sq\.|chemin|all[ée]e|quai|dr[èe]ve|impasse|clos|sentier|route|rond-point|galerie|parvis|cours|venelle|cit[ée]|r[ée]sidence|zoning|parc)\b/i;
const SCAN_STREET_NL = /(straat|str\.|laan|lei|weg|steenweg|plein|dreef|kaai|markt|plaats|hof|pad|dijk|vest|singel|berg|baan)\b/i;
const SCAN_PC = /(?:^|[\s,;:(])(?:B[-\s]?)?([1-9]\d{3})\s+([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’.-]*(?:[ -](?:[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’.-]*))*)/;
const SCAN_PHONE = /(?:\+|00)32[\s./-]?\(?0?\)?[\s./-]?[1-9](?:[\s./-]?\d){7,8}|\b0[1-9](?:[\s./-]?\d){7,8}\b/;
const SCAN_LABEL = /^(?:adresse(?: de livraison)?|address|adres|leveringsadres|livraison|destinataire|ontvanger|client|klant|nom|naam|name|t[ée]l[ée]?(?:phone)?|gsm|tel|mobile)\s*[:.]\s*/i;
const SCAN_STOPWORDS = /\b(belgique|belgium|belgi[ëe]|t[ée]l|tel|gsm|fax|e-?mail|tva|btw|bce|iban|date|r[ée]f|colis|poids|kg|commande|cr[ée]neau|heure|livraison|qt[ée]|quantit[ée])\b.*$/i;
const SCAN_TAIL = /\s+(?:t[ée]l[ée]?(?:phone)?|tel|gsm|mobile|fax|e-?mail|colis|poids|r[ée]f|commande|cr[ée]neau|heure)\b.*$/i;
const scanTidy = s => s.replace(SCAN_TAIL, '').replace(/\b(de|à) l[àa](?=[\s,]|$)/gi, (x, p) => p + ' la').replace(/[\s,;:-]+$/, '').trim();
function scanCity(s) { return s.replace(SCAN_STOPWORDS, '').replace(/[\s,;.:-]+$/, '').split(/\s+/).slice(0, 4).join(' ').trim(); }
function scanLooksStreet(s) { return /\d/.test(s) && (SCAN_STREET_FR.test(s) || SCAN_STREET_NL.test(s) || /^[\p{L}'’. -]{3,}\s\d{1,4}\s?[a-zA-Z]?\b/u.test(s)); }
function scanName(s) { s = scanTidy((s || '').replace(/^\s*(?:#|n°|no\.?)?\s*\d{1,3}\s*[.)\-:]\s+/i, '').replace(SCAN_LABEL, '').trim()); return s && !/\d{3}/.test(s) && s.length >= 3 && s.length <= 60 && !SCAN_PC.test(s) && !scanLooksStreet(s) ? s : ''; }
function extractStops(text) {
  const lines = String(text || '').split(/\r?\n/).map(l => l.replace(/[|_~«»•*]+/g, ' ').replace(/\s+/g, ' ').trim()).filter(l => l.length > 2);
  const out = [], seen = new Set();
  lines.forEach((l, i) => {
    const m = l.match(SCAN_PC); if (!m) return;
    const pcAt = l.indexOf(m[1], m.index);
    let before = l.slice(0, pcAt).replace(/\bB[-\s]?$/, '').replace(/[\s,;:-]+$/, '').replace(SCAN_LABEL, '').trim();
    let street = '', streetLine = i, client = '';
    if (before && /\d/.test(before) && before.length > 4) street = before;
    else if (i > 0 && scanLooksStreet(lines[i - 1].replace(SCAN_LABEL, ''))) { street = lines[i - 1].replace(SCAN_LABEL, '').trim(); streetLine = i - 1; if (before) client = scanName(before); }
    else if (before.length > 4) street = before;
    street = scanTidy(street); if (!street) return;
    const k = street.search(SCAN_STREET_FR);
    if (k > 0) { const pre = street.slice(0, k).replace(/[\s,;:-]+$/, ''); if (!/\d/.test(pre)) { client = client || scanName(pre); street = street.slice(k); } }
    const city = scanCity(m[2]); if (!city) return;
    const label = `${street.replace(/[\s,;:-]+$/, '')}, ${m[1]} ${city}`;
    const key = normH(label); if (seen.has(key)) return; seen.add(key);
    if (!client) for (let j = streetLine - 1; j >= Math.max(0, streetLine - 2); j--) { const n = scanName(lines[j]); if (n) { client = n; break; } }
    out.push({ label, client, phone: '', _s: streetLine, _e: i });
  });
  const ph = j => { const p = lines[j] && !/\b(tva|btw|bce|kbo|iban|bic|vat|BE ?0\d{3})/i.test(lines[j]) && lines[j].match(SCAN_PHONE); return p ? p[0].replace(/[^\d+]/g, '') : ''; };
  out.forEach((o, n) => {
    const lo = Math.max(n ? out[n - 1]._e + 2 : 0, o._s - 2), hi = Math.min(n < out.length - 1 ? out[n + 1]._s - 1 : lines.length - 1, o._e + 2);
    for (let j = o._s; j <= hi && !o.phone; j++) o.phone = ph(j);
    for (let j = o._s - 1; j >= lo && !o.phone; j--) o.phone = ph(j);
  });
  return out.map(({ label, client, phone }) => ({ label, client, phone }));
}
let OCR_WORKER = null;
async function ocrImage(file, onProgress) {
  if (!OCR_WORKER) {
    await loadScript(OCR_ASSETS.js);
    const steps = { 'loading tesseract core': 'Chargement du lecteur', 'loading language traineddata': 'Chargement du français', 'initializing api': 'Préparation', 'recognizing text': 'Lecture du document' };
    OCR_WORKER = window.Tesseract.createWorker('fra', 1, { workerPath: OCR_ASSETS.worker, corePath: OCR_ASSETS.core, langPath: OCR_ASSETS.lang, workerBlobURL: !VENDOR,
      logger: m => onProgress && onProgress(steps[m.status] || '', m.progress || 0) }).catch(e => { OCR_WORKER = null; throw e; });
  }
  const w = await OCR_WORKER;
  const bmp = await createImageBitmap(file);
  const long = Math.max(bmp.width, bmp.height), sc = Math.min(2.5, Math.max(1, 1800 / long), 2600 / long);
  const cv = document.createElement('canvas'); cv.width = Math.round(bmp.width * sc); cv.height = Math.round(bmp.height * sc);
  const cx = cv.getContext('2d'); cx.filter = 'grayscale(1) contrast(1.25)'; cx.drawImage(bmp, 0, 0, cv.width, cv.height); bmp.close && bmp.close();
  const r = await w.recognize(cv);
  return r.data.text || '';
}
