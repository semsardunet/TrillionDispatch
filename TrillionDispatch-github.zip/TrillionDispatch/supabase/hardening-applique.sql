-- ---------- sécurité : limites de saisie (refuse les textes géants et les valeurs absurdes) ----------
do $$
declare c record;
begin
  for c in select * from (values
    ('addresses', 'addresses_len_chk', 'check (char_length(label) <= 300 and char_length(coalesce(client, '''')) <= 200 and char_length(coalesce(phone, '''')) <= 40 and char_length(key) <= 400)'),
    ('elements',  'elements_len_chk',  'check (char_length(coalesce(body, '''')) <= 2000 and char_length(coalesce(transcript, '''')) <= 4000 and char_length(tag) <= 40 and char_length(coalesce(author, '''')) <= 120 and char_length(coalesce(media, '''')) <= 300)'),
    ('stops',     'stops_len_chk',     'check (char_length(coalesce(raw, '''')) <= 300 and char_length(coalesce(client, '''')) <= 200 and char_length(coalesce(phone, '''')) <= 40 and char_length(coalesce(ref, '''')) <= 80 and char_length(coalesce(notes, '''')) <= 1000 and char_length(coalesce(driver_note, '''')) <= 1000 and char_length(coalesce(fail_reason, '''')) <= 120 and service_min between 0 and 480 and priority in (0, 1) and coalesce(weight_kg, 0) between 0 and 100000 and pg_column_size(proof) < 20000)'),
    ('tours',     'tours_len_chk',     'check (char_length(name) <= 120 and char_length(coalesce(driver_name, '''')) <= 120 and pg_column_size(depot) < 2000)'),
    ('drivers',   'drivers_len_chk',   'check (char_length(name) <= 120 and char_length(coalesce(phone, '''')) <= 40 and char_length(coalesce(vehicle, '''')) <= 80 and coalesce(capacity_kg, 0) between 0 and 100000)'),
    ('profiles',  'profiles_len_chk',  'check (char_length(coalesce(display_name, '''')) <= 120 and char_length(coalesce(phone, '''')) <= 40)'),
    ('tour_members', 'tour_members_len_chk', 'check (char_length(coalesce(driver_name, '''')) <= 120)')
  ) as v(tbl, name, ddl)
  loop
    if not exists (select 1 from pg_constraint where conname = c.name) then
      execute format('alter table public.%I add constraint %I %s', c.tbl, c.name, c.ddl);
    end if;
  end loop;
end $$;

-- ---------- acceptation des conditions (version + date, preuve RGPD) ----------
alter table public.profiles add column if not exists terms_version text;
alter table public.profiles add column if not exists terms_accepted_at timestamptz;

-- ---------- anti force brute sur les codes : 10 essais ratés par heure et par compte ----------
create table if not exists public.join_attempts (
  user_id uuid not null references auth.users(id) on delete cascade,
  at timestamptz not null default now(),
  ok boolean not null
);
create index if not exists join_attempts_user_at_idx on public.join_attempts(user_id, at desc);
alter table public.join_attempts enable row level security;   -- aucune règle : personne n'y accède directement

create or replace function public.join_tour(p_code text, p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tours;
begin
  if auth.uid() is null or not public.is_dispatcher() then raise exception 'non_connecte'; end if;
  if (select count(*) from join_attempts where user_id = auth.uid() and not ok and at > now() - interval '1 hour') >= 10 then
    raise exception 'trop_de_tentatives';
  end if;
  select * into t from tours
   where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'))
     and status in ('published','active','done') and not is_template;
  if not found then
    insert into join_attempts (user_id, ok) values (auth.uid(), false);
    return null;                                  -- l'essai raté reste compté
  end if;
  insert into join_attempts (user_id, ok) values (auth.uid(), true);
  insert into tour_members (tour_id, user_id, driver_name, code)
       values (t.id, auth.uid(), left(nullif(trim(p_name), ''), 120), t.code)
  on conflict (tour_id, user_id) do update set driver_name = coalesce(excluded.driver_name, tour_members.driver_name), code = excluded.code;
  return t.id;
end $$;

-- ---------- preuves : seulement des fichiers du dossier de l'entreprise, 6 photos max ----------
create or replace function public.driver_update_stop(p_stop uuid, p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare s stops; st text; own text;
begin
  select * into s from stops where id = p_stop;
  if not found then raise exception 'arret_inconnu'; end if;
  if not public.is_member(s.tour_id) then raise exception 'acces_refuse'; end if;
  if not exists (select 1 from tours where id = s.tour_id and status in ('published','active')) then raise exception 'tournee_fermee'; end if;
  own := s.owner::text || '/';
  if p ? 'proof' and jsonb_typeof(p -> 'proof') = 'object' then
    if jsonb_array_length(coalesce(p -> 'proof' -> 'photos', '[]'::jsonb)) > 6
       or exists (select 1 from jsonb_array_elements_text(coalesce(p -> 'proof' -> 'photos', '[]'::jsonb)) x where left(x, length(own)) <> own or x like '%..%')
       or (p -> 'proof' ->> 'signature' is not null and (left(p -> 'proof' ->> 'signature', length(own)) <> own or p -> 'proof' ->> 'signature' like '%..%'))
    then raise exception 'preuve_invalide'; end if;
  end if;
  st := coalesce(p ->> 'status', s.status);
  update stops set
    status      = st,
    fail_reason = case when p ? 'fail_reason' then left(p ->> 'fail_reason', 120) else fail_reason end,
    reschedule  = case when p ? 'reschedule'  then (p ->> 'reschedule')::boolean else reschedule end,
    arrived_at  = case when p ? 'arrived_at'  then (p ->> 'arrived_at')::timestamptz else arrived_at end,
    done_at     = case when p ? 'done_at'     then (p ->> 'done_at')::timestamptz else done_at end,
    proof       = case when p ? 'proof'       then p -> 'proof' else proof end,
    updated_at  = now()
  where id = p_stop;
  if st = 'done' and s.status <> 'done' then
    update addresses set visits = visits + 1, last_visit = now() where id = s.address_id;
  elsif st <> 'done' and s.status = 'done' then
    update addresses set visits = greatest(0, visits - 1) where id = s.address_id;
  end if;
end $$;

-- ---------- propositions de fiche : 100 par jour et par livreur, fichiers de l'entreprise seulement ----------
create or replace function public.driver_add_element(p_address uuid, p_stop uuid, p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare a addresses; new_id uuid;
begin
  if not public.can_see_address(p_address) then raise exception 'acces_refuse'; end if;
  if (select count(*) from elements where created_by = auth.uid() and created_at > now() - interval '1 day') >= 100 then raise exception 'trop_de_propositions'; end if;
  if coalesce(p ->> 'type', '') not in ('photo', 'voice', 'text') then raise exception 'type_invalide'; end if;
  select * into a from addresses where id = p_address;
  if p ->> 'media' is not null and (left(p ->> 'media', length(a.owner::text) + 1) <> a.owner::text || '/' or p ->> 'media' like '%..%') then raise exception 'media_invalide'; end if;
  insert into elements (owner, address_id, type, tag, body, transcript, media, author, status, created_by, position)
  values (a.owner, a.id, p ->> 'type', left(coalesce(p ->> 'tag', 'Autre'), 40), left(p ->> 'body', 2000), left(p ->> 'transcript', 4000), p ->> 'media', left(p ->> 'author', 120),
          'pending', auth.uid(), coalesce((select max(position) + 1 from elements where address_id = a.id), 1))
  returning id into new_id;
  if p_stop is not null then
    update stops set fiche_added = fiche_added + 1
     where id = p_stop and address_id = p_address and public.is_member(tour_id);
  end if;
  return new_id;
end $$;

-- ---------- position du livreur : effacée dès la fin de la tournée (minimisation RGPD) ----------
create or replace function public.driver_finish(p_tour uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member(p_tour) then raise exception 'acces_refuse'; end if;
  if exists (select 1 from stops where tour_id = p_tour and status = 'todo') then raise exception 'arrets_restants'; end if;
  update tours set status = 'done', ended_at = now(), updated_at = now(), last_pos = null where id = p_tour and status in ('published','active');
end $$;

-- ---------- fichiers : 10 Mo max, seulement photos et sons ----------
update storage.buckets set file_size_limit = 10485760, allowed_mime_types = array['image/*', 'audio/*'] where id = 'media';

-- ---------- droits d'exécution ----------
revoke execute on function public.join_tour(text, text), public.driver_update_stop(uuid, jsonb), public.driver_add_element(uuid, uuid, jsonb), public.driver_finish(uuid) from public, anon;
grant execute on function public.join_tour(text, text), public.driver_update_stop(uuid, jsonb), public.driver_add_element(uuid, uuid, jsonb), public.driver_finish(uuid) to authenticated;
