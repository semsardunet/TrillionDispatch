-- =====================================================================
-- TrillionDispatch · schéma Supabase (version comptes : Google ou e-mail)
-- Déjà installé sur le projet nwlteniesfckhhwxoihb. Ce fichier sert de
-- copie de référence : on peut le relancer, il ne casse rien.
-- =====================================================================

-- ---------- tables ----------
create table if not exists public.addresses (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references auth.users(id) on delete cascade,
  key text not null, label text not null, pc text, city text,
  lat double precision, lng double precision, client text, phone text,
  visits int not null default 0, last_visit timestamptz,
  created_at timestamptz not null default now(),
  unique (owner, key)
);
create table if not exists public.elements (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references auth.users(id) on delete cascade,
  address_id uuid not null references public.addresses(id) on delete cascade,
  type text not null check (type in ('photo','voice','text')),
  tag text not null default 'Autre', body text, transcript text, media text, author text,
  pinned boolean not null default false, up int not null default 0, down int not null default 0,
  status text not null default 'ok' check (status in ('ok','pending')),
  position int not null default 0, created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists elements_address_idx on public.elements(address_id);
create table if not exists public.drivers (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references auth.users(id) on delete cascade,
  name text not null, phone text, vehicle text, capacity_kg numeric,
  skills text[] not null default '{}', active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.tours (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references auth.users(id) on delete cascade,
  code text not null unique, name text not null,
  day date not null default current_date,
  status text not null default 'draft' check (status in ('draft','published','active','done')),
  is_template boolean not null default false,
  driver_id uuid references public.drivers(id) on delete set null, driver_name text,
  depot jsonb not null default '{}'::jsonb, start_time time,
  return_to_depot boolean not null default true, capacity_kg numeric,
  options jsonb not null default '{}'::jsonb,
  started_at timestamptz, ended_at timestamptz, last_pos jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists tours_owner_day_idx on public.tours(owner, day desc);
create table if not exists public.stops (
  id uuid primary key default gen_random_uuid(),
  tour_id uuid not null references public.tours(id) on delete cascade,
  owner uuid not null references auth.users(id) on delete cascade,
  address_id uuid not null references public.addresses(id),
  rank int not null default 0, raw text, client text, phone text, ref text, notes text, driver_note text,
  win_start time, win_end time, service_min int not null default 4, priority int not null default 0,
  weight_kg numeric, locked boolean not null default false,
  status text not null default 'todo' check (status in ('todo','done','failed')),
  fail_reason text, reschedule boolean, arrived_at timestamptz, done_at timestamptz,
  proof jsonb, fiche_added int not null default 0,
  updated_at timestamptz not null default now()
);
create index if not exists stops_tour_rank_idx on public.stops(tour_id, rank);
create index if not exists stops_address_idx on public.stops(address_id);
-- un livreur rejoint une tournée avec son code ; l'accès tient tant que le code ne change pas
create table if not exists public.tour_members (
  tour_id uuid not null references public.tours(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  driver_name text, code text, joined_at timestamptz not null default now(),
  primary key (tour_id, user_id)
);
alter table public.tour_members add column if not exists code text;
create index if not exists tour_members_user_idx on public.tour_members(user_id);
-- un compte par personne (Google ou e-mail), dispatcher comme livreur
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text, phone text, avatar_url text,
  created_at timestamptz not null default now()
);
alter table public.addresses enable row level security;
alter table public.elements enable row level security;
alter table public.drivers enable row level security;
alter table public.tours enable row level security;
alter table public.stops enable row level security;
alter table public.tour_members enable row level security;
alter table public.profiles enable row level security;

-- ---------- fonctions ----------
create or replace function public.gen_code() returns text
language plpgsql volatile set search_path = public as $$
declare a text := '23456789ABCDEFGHJKMNPQRSTUVWXYZ'; c text;
begin
  loop
    c := '';
    for i in 1..6 loop c := c || substr(a, 1 + floor(random() * length(a))::int, 1); end loop;
    exit when not exists (select 1 from public.tours where code = c);
  end loop;
  return c;
end $$;
alter table public.tours alter column code set default public.gen_code();

create or replace function public.is_dispatcher() returns boolean
language sql stable set search_path = public as $$
  select auth.uid() is not null and not coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false)
$$;
create or replace function public.is_member(p_tour uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from tour_members m join tours t on t.id = m.tour_id
                 where m.tour_id = p_tour and m.user_id = auth.uid() and m.code = t.code)
$$;
create or replace function public.can_see_address(p_address uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from stops s join tour_members m on m.tour_id = s.tour_id join tours t on t.id = s.tour_id
                 where s.address_id = p_address and m.user_id = auth.uid() and m.code = t.code)
$$;
create or replace function public.member_of_open_tour_of(p_owner text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from tour_members m join tours t on t.id = m.tour_id
                 where m.user_id = auth.uid() and m.code = t.code and t.owner::text = p_owner and t.status in ('published','active'))
$$;
create or replace function public.can_read_media(p_name text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from elements e where e.media = p_name and public.can_see_address(e.address_id)
                 and (e.status = 'ok' or e.created_by = auth.uid()))
      or exists (select 1 from stops s join tour_members m on m.tour_id = s.tour_id join tours t on t.id = s.tour_id
                 where m.user_id = auth.uid() and m.code = t.code
                   and (coalesce(s.proof -> 'photos', '[]'::jsonb) ? p_name or s.proof ->> 'signature' = p_name))
$$;
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (new.id,
          coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', nullif(split_part(coalesce(new.email, ''), '@', 1), '')),
          new.raw_user_meta_data ->> 'avatar_url')
  on conflict (id) do nothing;
  return new;
end $$;
create or replace trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- règles d'accès (créées si absentes) ----------
do $$
declare p record;
begin
  for p in select * from (values
    ('addresses','own_all',     'create policy own_all on public.addresses for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid() and public.is_dispatcher())'),
    ('addresses','member_read', 'create policy member_read on public.addresses for select to authenticated using (public.can_see_address(id))'),
    ('elements','own_all',      'create policy own_all on public.elements for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid() and public.is_dispatcher())'),
    ('elements','member_read',  'create policy member_read on public.elements for select to authenticated using (public.can_see_address(address_id) and (status = ''ok'' or created_by = auth.uid()))'),
    ('drivers','own_all',       'create policy own_all on public.drivers for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid() and public.is_dispatcher())'),
    ('tours','own_all',         'create policy own_all on public.tours for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid() and public.is_dispatcher())'),
    ('tours','member_read',     'create policy member_read on public.tours for select to authenticated using (public.is_member(id))'),
    ('stops','own_all',         'create policy own_all on public.stops for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid() and public.is_dispatcher())'),
    ('stops','member_read',     'create policy member_read on public.stops for select to authenticated using (public.is_member(tour_id))'),
    ('tour_members','owner_read',   'create policy owner_read on public.tour_members for select to authenticated using (exists (select 1 from public.tours t where t.id = tour_id and t.owner = auth.uid()))'),
    ('tour_members','owner_delete', 'create policy owner_delete on public.tour_members for delete to authenticated using (exists (select 1 from public.tours t where t.id = tour_id and t.owner = auth.uid()))'),
    ('tour_members','self_read',    'create policy self_read on public.tour_members for select to authenticated using (user_id = auth.uid())'),
    ('profiles','self_all',     'create policy self_all on public.profiles for all to authenticated using (id = auth.uid()) with check (id = auth.uid())'),
    ('profiles','team_read',    'create policy team_read on public.profiles for select to authenticated using (exists (select 1 from public.tour_members m join public.tours t on t.id = m.tour_id where m.user_id = profiles.id and t.owner = auth.uid()))')
  ) as v(tbl, name, ddl)
  loop
    if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = p.tbl and policyname = p.name) then execute p.ddl; end if;
  end loop;
end $$;

-- ---------- fonctions du livreur (jamais d'écriture directe dans les tables) ----------
create or replace function public.join_tour(p_code text, p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tours;
begin
  if auth.uid() is null then raise exception 'non_connecte'; end if;
  select * into t from tours
   where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'))
     and status in ('published','active','done') and not is_template;
  if not found then raise exception 'code_inconnu'; end if;
  insert into tour_members (tour_id, user_id, driver_name, code)
       values (t.id, auth.uid(), nullif(trim(p_name), ''), t.code)
  on conflict (tour_id, user_id) do update set driver_name = coalesce(excluded.driver_name, tour_members.driver_name), code = excluded.code;
  return t.id;
end $$;
create or replace function public.driver_start(p_tour uuid, p_name text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member(p_tour) then raise exception 'acces_refuse'; end if;
  update tours set status = 'active', started_at = coalesce(started_at, now()),
         driver_name = coalesce(nullif(trim(p_name), ''), driver_name), updated_at = now()
   where id = p_tour and status in ('published','active');
end $$;
create or replace function public.driver_update_stop(p_stop uuid, p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare s stops; st text;
begin
  select * into s from stops where id = p_stop;
  if not found then raise exception 'arret_inconnu'; end if;
  if not public.is_member(s.tour_id) then raise exception 'acces_refuse'; end if;
  if not exists (select 1 from tours where id = s.tour_id and status in ('published','active')) then raise exception 'tournee_fermee'; end if;
  st := coalesce(p ->> 'status', s.status);
  update stops set
    status      = st,
    fail_reason = case when p ? 'fail_reason' then p ->> 'fail_reason' else fail_reason end,
    reschedule  = case when p ? 'reschedule'  then (p ->> 'reschedule')::boolean else reschedule end,
    arrived_at  = case when p ? 'arrived_at'  then (p ->> 'arrived_at')::timestamptz else arrived_at end,
    done_at     = case when p ? 'done_at'     then (p ->> 'done_at')::timestamptz else done_at end,
    proof       = case when p ? 'proof'       then p -> 'proof' else proof end,
    updated_at  = now()
  where id = p_stop;
  if st = 'done' and s.status <> 'done' then
    update addresses set visits = visits + 1, last_visit = now() where id = s.address_id;
  elsif st <> 'done' and s.status = 'done' then
    update addresses set visits = greatest(0, visits - 1) where id = s.address_id;
  end if;
end $$;
create or replace function public.driver_add_element(p_address uuid, p_stop uuid, p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare a addresses; new_id uuid;
begin
  if not public.can_see_address(p_address) then raise exception 'acces_refuse'; end if;
  select * into a from addresses where id = p_address;
  insert into elements (owner, address_id, type, tag, body, transcript, media, author, status, created_by, position)
  values (a.owner, a.id, p ->> 'type', coalesce(p ->> 'tag', 'Autre'), p ->> 'body', p ->> 'transcript', p ->> 'media', p ->> 'author',
          'pending', auth.uid(), coalesce((select max(position) + 1 from elements where address_id = a.id), 1))
  returning id into new_id;
  if p_stop is not null then
    update stops set fiche_added = fiche_added + 1
     where id = p_stop and address_id = p_address and public.is_member(tour_id);
  end if;
  return new_id;
end $$;
create or replace function public.driver_vote(p_element uuid, d_up int, d_down int) returns void
language plpgsql security definer set search_path = public as $$
declare e elements;
begin
  select * into e from elements where id = p_element;
  if not found or not public.can_see_address(e.address_id) or e.status <> 'ok' then raise exception 'acces_refuse'; end if;
  update elements set up   = greatest(0, up   + greatest(-1, least(1, d_up))),
                      down = greatest(0, down + greatest(-1, least(1, d_down)))
   where id = p_element;
end $$;
create or replace function public.driver_ping(p_tour uuid, p_lat double precision, p_lng double precision, p_acc int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member(p_tour) then raise exception 'acces_refuse'; end if;
  update tours set last_pos = jsonb_build_object('lat', p_lat, 'lng', p_lng, 'acc', p_acc, 'at', now())
   where id = p_tour and status = 'active';
end $$;
create or replace function public.driver_finish(p_tour uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_member(p_tour) then raise exception 'acces_refuse'; end if;
  if exists (select 1 from stops where tour_id = p_tour and status = 'todo') then raise exception 'arrets_restants'; end if;
  update tours set status = 'done', ended_at = now(), updated_at = now() where id = p_tour and status in ('published','active');
end $$;
-- ---------- fonctions du dispatcher ----------
create or replace function public.reorder_stops(p_tour uuid, p_ids uuid[]) returns void
language plpgsql security invoker set search_path = public as $$
begin
  update stops s set rank = x.i, updated_at = now()
    from unnest(p_ids) with ordinality as x(id, i)
   where s.id = x.id and s.tour_id = p_tour and s.owner = auth.uid();
end $$;
create or replace function public.reset_tour_access(p_tour uuid) returns text
language plpgsql security definer set search_path = public as $$
declare c text;
begin
  if not exists (select 1 from tours where id = p_tour and owner = auth.uid()) then raise exception 'acces_refuse'; end if;
  c := public.gen_code();
  update tours set code = c, updated_at = now() where id = p_tour;
  return c;
end $$;

revoke execute on function public.join_tour(text, text), public.driver_start(uuid, text), public.driver_update_stop(uuid, jsonb),
  public.driver_add_element(uuid, uuid, jsonb), public.driver_vote(uuid, int, int), public.driver_ping(uuid, double precision, double precision, int),
  public.driver_finish(uuid), public.reorder_stops(uuid, uuid[]), public.reset_tour_access(uuid),
  public.is_member(uuid), public.can_see_address(uuid), public.member_of_open_tour_of(text), public.can_read_media(text), public.handle_new_user()
  from public, anon;
revoke execute on function public.handle_new_user() from authenticated;
grant execute on function public.join_tour(text, text), public.driver_start(uuid, text), public.driver_update_stop(uuid, jsonb),
  public.driver_add_element(uuid, uuid, jsonb), public.driver_vote(uuid, int, int), public.driver_ping(uuid, double precision, double precision, int),
  public.driver_finish(uuid), public.reorder_stops(uuid, uuid[]), public.reset_tour_access(uuid),
  public.is_member(uuid), public.can_see_address(uuid), public.member_of_open_tour_of(text), public.can_read_media(text)
  to authenticated;
do $$ begin if exists (select 1 from pg_roles where rolname = 'supabase_auth_admin') then grant execute on function public.handle_new_user() to supabase_auth_admin; end if; end $$;

-- ---------- photos, vocaux, signatures : bucket privé ----------
insert into storage.buckets (id, name, public) values ('media', 'media', false) on conflict (id) do nothing;
do $$
begin
  if not exists (select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'media: dispatcher') then
    create policy "media: dispatcher" on storage.objects for all to authenticated
      using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text)
      with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text and public.is_dispatcher());
  end if;
  if not exists (select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'media: livreur envoie') then
    create policy "media: livreur envoie" on storage.objects for insert to authenticated
      with check (bucket_id = 'media' and public.member_of_open_tour_of((storage.foldername(name))[1]));
  end if;
  if not exists (select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'media: livreur lit') then
    create policy "media: livreur lit" on storage.objects for select to authenticated
      using (bucket_id = 'media' and public.can_read_media(name));
  end if;
end $$;

-- ---------- temps réel ----------
do $$ begin
  begin alter publication supabase_realtime add table public.tours;    exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.stops;    exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.elements; exception when duplicate_object then null; end;
end $$;

-- ---------- administration (dm_08_admin) ----------
-- Les administrateurs sont listés dans public.admins, illisible depuis l'appli.
-- Ajouter un admin : insert into public.admins (user_id) select id from auth.users where email = '...';
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;
revoke all on table public.admins from public, anon, authenticated;
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.admins a where a.user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;
-- public.admin_overview() : comptes et volumes, refuse tout non-admin (voir migration dm_08_admin).
