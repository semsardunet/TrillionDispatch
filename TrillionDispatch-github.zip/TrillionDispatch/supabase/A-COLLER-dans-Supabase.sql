-- =====================================================================
-- À COLLER UNE FOIS dans Supabase > SQL Editor > New query > Run.
-- (La connexion de Claude ne peut pas lancer ces commandes : elles
--  contiennent des suppressions et demandent ton accord.)
-- =====================================================================

-- Droit à l'effacement (RGPD art. 17) : chacun supprime lui-même son compte depuis l'appli.
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'non_connecte'; end if;
  update public.elements set author = 'Ancien utilisateur', created_by = null where created_by = auth.uid();
  delete from auth.users where id = auth.uid();
end $$;
revoke execute on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- Durées de conservation : essais de code 2 jours, position effacée en fin de tournée, GPS des preuves 13 mois.
create or replace function public.purge_old_data() returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from public.join_attempts where at < now() - interval '2 days';
  update public.tours set last_pos = null where status = 'done' and last_pos is not null;
  update public.stops set proof = proof - 'gps' where done_at < now() - interval '13 months' and proof ? 'gps';
end $$;
revoke execute on function public.purge_old_data() from public, anon, authenticated;

-- Nettoyage automatique chaque nuit à 3h17.
create extension if not exists pg_cron;
select cron.schedule('dm-purge-old-data', '17 3 * * *', 'select public.purge_old_data()');
