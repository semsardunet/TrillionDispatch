# TrillionDispatch

Application web (téléphone d'abord) de tournées de livraison : le dispatcher prépare les tournées, le livreur les ouvre avec un lien ou un code, chaque adresse garde sa fiche terrain (photos annotées du chemin, vocaux, notes), et la tournée terminée s'exporte avec ses preuves.

## Contenu

| Dossier | Rôle |
|---|---|
| `site/` | Version prête à héberger : `index.html`, `.htaccess` (HTTPS et en-têtes de sécurité), bibliothèques et polices hébergées avec l'appli. Aucun appel à un site tiers pour charger l'appli. |
| `src/` | Sources : interface (`*.html`, `*.js`), textes juridiques (`legal/*.md`), scripts de build. |
| `supabase/` | Schéma de la base (référence), sécurité déjà appliquée, et `A-COLLER-dans-Supabase.sql` à lancer une fois. |

## Mise en ligne

1. Supabase › SQL Editor : coller et lancer `supabase/A-COLLER-dans-Supabase.sql`.
2. Envoyer le contenu de `site/` chez un hébergeur en HTTPS, avec `.htaccess`.
3. Supabase › Authentication › URL Configuration : indiquer l'adresse du site.
4. Compléter les champs entre crochets des textes juridiques (`src/legal/*.md`) : société, BCE, TVA, e-mail.

## Fonctions principales

- Rôles Dispatcher et Livreur, comptes Google ou e-mail.
- Création de tournées : saisie, photo d'un document (lecture sur le téléphone), copier-coller, Excel/CSV, carnet d'adresses, autre tournée, modèles.
- Optimisation avec créneaux, priorités, arrêts verrouillés, découpage en plusieurs livreurs.
- Fiches terrain par adresse, propositions des livreurs validées par le dispatcher, lecture vocale en français.
- Preuves (photo, signature, nom), exports CSV, PDF et ZIP.
- Thèmes bleu, rouge, or, vert ; clair et sombre.

## Sécurité

- Seule la clé publique Supabase est dans l'appli. Ne jamais y mettre la clé `service_role` ou secrète.
- Cloisonnement par entreprise (RLS), actions des livreurs via fonctions contrôlées, fichiers privés à liens temporaires.

## Build

`src/build.py` assemble `src/` en un seul fichier. Les chemins en tête du script sont ceux de l'environnement de développement : à adapter avant de relancer.
